<?php
    class Freemius_ArgumentNotExistException extends Freemius_InvalidArgumentException { }