<?php
    class Freemius_EmptyArgumentException extends Freemius_InvalidArgumentException { }