<?php
    class Freemius_InvalidArgumentException extends Freemius_Exception { }