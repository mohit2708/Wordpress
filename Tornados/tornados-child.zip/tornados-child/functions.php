<?php
/**
 * Child-Theme functions and definitions
 */
 
function tornados_enqueue_styles() {
    wp_enqueue_style( 'tornados-parent-style', get_template_directory_uri() . '/style.css' );
}
add_action( 'wp_enqueue_scripts', 'tornados_enqueue_styles' );