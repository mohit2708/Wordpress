<?php
/**
 * The Sticky template to display the sticky posts
 *
 * Used for index/archive
 *
 * @package WordPress
 * @subpackage SAVE_LIFE
 * @since SAVE_LIFE 1.0
 */

$save_life_columns = max(1, min(3, count(get_option( 'sticky_posts' ))));
$save_life_post_format = get_post_format();
$save_life_post_format = empty($save_life_post_format) ? 'standard' : str_replace('post-format-', '', $save_life_post_format);
$save_life_animation = save_life_get_theme_option('blog_animation');

?><div class="column-1_<?php echo esc_attr($save_life_columns); ?>"><article id="post-<?php the_ID(); ?>" 
	<?php post_class( 'post_item post_layout_sticky post_format_'.esc_attr($save_life_post_format) ); ?>
	<?php echo (!save_life_is_off($save_life_animation) ? ' data-animation="'.esc_attr(save_life_get_animation_classes($save_life_animation)).'"' : ''); ?>
	>

	<?php
	if ( is_sticky() && is_home() && !is_paged() ) {
		?><span class="post_label label_sticky"></span><?php
	}

	// Featured image
	save_life_show_post_featured(array(
		'thumb_size' => save_life_get_thumb_size($save_life_columns==1 ? 'big' : ($save_life_columns==2 ? 'med' : 'avatar'))
	));

	if ( !in_array($save_life_post_format, array('link', 'aside', 'status', 'quote')) ) {
		?>
		<div class="post_header entry-header">
			<?php
			// Post title
			the_title( sprintf( '<h2 class="post_title entry-title"><a href="%s" rel="bookmark">', esc_url( get_permalink() ) ), '</a></h2>' );
			// Post meta
			save_life_show_post_meta();
			?>
		</div><!-- .entry-header -->
		<?php
	}
	?>
</article></div>