<?php
/**
 * The Header: Logo and main menu
 *
 * @package WordPress
 * @subpackage SAVE_LIFE
 * @since SAVE_LIFE 1.0
 */
?><!DOCTYPE html>
<html <?php language_attributes(); ?> class="no-js scheme_<?php
										 // Class scheme_xxx need in the <html> as context for the <body>!
										 echo esc_attr(save_life_get_theme_option('color_scheme'));
										 ?>">
<head>
	<?php wp_head(); ?>
</head>

<body <?php	body_class(); ?>>

	<?php do_action( 'save_life_action_before' ); ?>

	<div class="body_wrap">

		<?php
		// Desktop header
		$save_life_header_style = save_life_get_theme_option("header_style");
		if (strpos($save_life_header_style, 'header-custom-')===0) $save_life_header_style = 'header-custom';
		get_template_part( "templates/{$save_life_header_style}");
		?>

		<div class="page_wrap">

			<?php
			// Page title and breadcrumbs area
			if(!is_single()) {
				get_template_part('templates/header-title');
			} else { // you cen del this - for single ?>
				<div class="top_panel_title sc_layouts_row sc_layouts_row_type_normal">
					<div class="sc_layouts_breadcrumbs">
						<div class="content_wrap"><?php
							// Breadcrumbs
							?><div class="sc_layouts_title_breadcrumbs"><?php
								do_action( 'save_life_action_breadcrumbs');
								?></div>
						</div>
					</div>
				</div>
			<?php }

			// Side menu
			if (in_array(save_life_get_theme_option('menu_style'), array('left', 'right'))) {
				get_template_part( 'templates/header-navi-side' );
			}

			// Mobile header
			get_template_part( 'templates/header-mobile');
			?>

			<div class="page_content_wrap scheme_<?php echo esc_attr(save_life_get_theme_option('color_scheme')); ?>">

				<?php if (save_life_get_theme_option('body_style') != 'fullscreen') { ?>
				<div class="content_wrap">
				<?php } ?>

					<?php
					// Widgets area above page content
					save_life_create_widgets_area('widgets_above_page');
					?>				

					<div class="content">
						<?php
						// Widgets area inside page content
						save_life_create_widgets_area('widgets_above_content');
						?>				
