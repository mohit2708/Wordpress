<article <?php post_class( 'post_item_single post_item_404' ); ?>>
	<div class="post_content">
		<div class="page_404_bg"><img alt="404" src="<?php echo save_life_get_file_url('/images/404.png'); ?>"></div>
		<div class="page_info info_404">
			<h1 class="page_subtitle"><?php esc_html_e('Oops...', 'save-life'); ?></h1>
			<p class="page_description"><?php echo wp_kses_post(esc_html__("We're sorry, but <br>something went wrong.", 'save-life')); ?></p>
			<a href="<?php echo esc_url(home_url('/')); ?>" class="go_home theme_button"><?php esc_html_e('Homepage', 'save-life'); ?></a>
		</div>
	</div>
</article>
