<?php
/**
 * The Portfolio template to display the content
 *
 * Used for index/archive/search.
 *
 * @package WordPress
 * @subpackage SAVE_LIFE
 * @since SAVE_LIFE 1.0
 */

$save_life_blog_style = explode('_', save_life_get_theme_option('blog_style'));
$save_life_columns = empty($save_life_blog_style[1]) ? 2 : max(2, $save_life_blog_style[1]);
$save_life_post_format = get_post_format();
$save_life_post_format = empty($save_life_post_format) ? 'standard' : str_replace('post-format-', '', $save_life_post_format);
$save_life_animation = save_life_get_theme_option('blog_animation');

?><article id="post-<?php the_ID(); ?>" 
	<?php post_class( 'post_item post_layout_portfolio post_layout_portfolio_'.esc_attr($save_life_columns).' post_format_'.esc_attr($save_life_post_format) ); ?>
	<?php echo (!save_life_is_off($save_life_animation) ? ' data-animation="'.esc_attr(save_life_get_animation_classes($save_life_animation)).'"' : ''); ?>
	>

	<?php
	$save_life_image_hover = save_life_get_theme_option('image_hover');
	// Featured image
	save_life_show_post_featured(array(
		'thumb_size' => save_life_get_thumb_size(strpos(save_life_get_theme_option('body_style'), 'full')!==false || $save_life_columns < 3 ? 'masonry-big' : 'masonry'),
		'show_no_image' => true,
		'class' => $save_life_image_hover == 'dots' ? 'hover_with_info' : '',
		'post_info' => $save_life_image_hover == 'dots' ? '<div class="post_info">'.esc_html(get_the_title()).'</div>' : ''
	));
	?>
</article>