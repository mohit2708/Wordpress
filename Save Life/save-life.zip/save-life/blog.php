<?php
/**
 * The template to display blog archive
 *
 * @package WordPress
 * @subpackage SAVE_LIFE
 * @since SAVE_LIFE 1.0
 */

/*
Template Name: Blog archive
*/

/**
 * Make page with this template and put it into menu
 * to display posts as blog archive
 * You can setup output parameters (blog style, posts per page, parent category, etc.)
 * in the Theme Options section (under the page content)
 * You can build this page in the Visual Composer to make custom page layout:
 * just insert %%CONTENT%% in the desired place of content
 */

// Get template page's content
$save_life_content = '';
$save_life_blog_archive_mask = '%%CONTENT%%';
$save_life_blog_archive_subst = sprintf('<div class="blog_archive">%s</div>', $save_life_blog_archive_mask);
if ( have_posts() ) {
	the_post(); 
	if (($save_life_content = apply_filters('the_content', get_the_content())) != '') {
		if (($save_life_pos = strpos($save_life_content, $save_life_blog_archive_mask)) !== false) {
			$save_life_content = preg_replace('/(\<p\>\s*)?'.$save_life_blog_archive_mask.'(\s*\<\/p\>)/i', $save_life_blog_archive_subst, $save_life_content);
		} else
			$save_life_content .= $save_life_blog_archive_subst;
		$save_life_content = explode($save_life_blog_archive_mask, $save_life_content);
	}
}

// Prepare args for a new query
$save_life_args = array(
	'post_status' => current_user_can('read_private_pages') && current_user_can('read_private_posts') ? array('publish', 'private') : 'publish'
);
$save_life_args = save_life_query_add_posts_and_cats($save_life_args, '', save_life_get_theme_option('post_type'), save_life_get_theme_option('parent_cat'));
$save_life_page_number = get_query_var('paged') ? get_query_var('paged') : (get_query_var('page') ? get_query_var('page') : 1);
if ($save_life_page_number > 1) {
	$save_life_args['paged'] = $save_life_page_number;
	$save_life_args['ignore_sticky_posts'] = true;
}
$save_life_ppp = save_life_get_theme_option('posts_per_page');
if ((int) $save_life_ppp != 0)
	$save_life_args['posts_per_page'] = (int) $save_life_ppp;
// Make a new query
query_posts( $save_life_args );
// Set a new query as main WP Query
$GLOBALS['wp_the_query'] = $GLOBALS['wp_query'];

// Set query vars in the new query!
if (is_array($save_life_content) && count($save_life_content) == 2) {
	set_query_var('blog_archive_start', $save_life_content[0]);
	set_query_var('blog_archive_end', $save_life_content[1]);
}

get_template_part('index');
?>