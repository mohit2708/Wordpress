<?php
/**
 * Default Theme Options and Internal Theme Settings
 *
 * @package WordPress
 * @subpackage SAVE_LIFE
 * @since SAVE_LIFE 1.0
 */

// Theme init priorities:
// 1 - register filters to add/remove lists items in the Theme Options
// 2 - create Theme Options
// 3 - add/remove Theme Options elements
// 5 - load Theme Options
// 9 - register other filters (for installer, etc.)
//10 - standard Theme init procedures (not ordered)

if ( !function_exists('save_life_options_theme_setup1') ) {
	add_action( 'after_setup_theme', 'save_life_options_theme_setup1', 1 );
	function save_life_options_theme_setup1() {
		
		// -----------------------------------------------------------------
		// -- ONLY FOR PROGRAMMERS, NOT FOR CUSTOMER
		// -- Internal theme settings
		// -----------------------------------------------------------------
		save_life_storage_set('settings', array(
			
			'ajax_views_counter'		=> true,						// Use AJAX for increment posts counter (if cache plugins used) 
																		// or increment posts counter then loading page (without cache plugin)
			'disable_jquery_ui'			=> false,						// Prevent loading custom jQuery UI libraries in the third-party plugins
		
			'max_load_fonts'			=> 3,							// Max fonts number to load from Google fonts or from uploaded fonts
		
			'use_mediaelements'			=> true,						// Load script "Media Elements" to play video and audio
		
			'max_excerpt_length'		=> 39,							// Max words number for the excerpt in the blog style 'Excerpt'.
																		// For style 'Classic' - get half from this value
			'message_maxlength'			=> 1000							// Max length of the message from contact form
			
		));
		
		
		
		// -----------------------------------------------------------------
		// -- Theme fonts (Google and/or custom fonts)
		// -----------------------------------------------------------------
		
		// Fonts to load when theme start
		// It can be Google fonts or uploaded fonts, placed in the folder /css/font-face/font-name inside the theme folder
		// Attention! Font's folder must have name equal to the font's name, with spaces replaced on the dash '-'
		// For example: font name 'TeX Gyre Termes', folder 'TeX-Gyre-Termes'
		save_life_storage_set('load_fonts', array(
			// Google font
			array(
				'name'	 => 'Open Sans',
				'family' => 'sans-serif',
				'styles' => '300,300i,400,400i,600,600i,700,700i,800,800i'		// Parameter 'style' used only for the Google fonts
				),
			array(
				'name'	 => 'Oswald',
				'family' => 'sans-serif',
				'styles' => '300,400,700'		// Parameter 'style' used only for the Google fonts
				),
			// Font-face packed with theme
			array(
				'name'   => 'GoodDog',
				'family' => 'sans-serif'
				)
		));
		
		// Characters subset for the Google fonts. Available values are: latin,latin-ext,cyrillic,cyrillic-ext,greek,greek-ext,vietnamese
		save_life_storage_set('load_fonts_subset', 'latin,latin-ext');
		
		// Settings of the main tags
		save_life_storage_set('theme_fonts', array(
			'p' => array(
				'title'				=> esc_html__('Main text', 'save-life'),
				'description'		=> esc_html__('Font settings of the main text of the site', 'save-life'),
				'font-family'		=> 'Open Sans, sans-serif',
				'font-size' 		=> '1rem',
				'font-weight'		=> '400',
				'font-style'		=> 'normal',
				'line-height'		=> '1.625em',
				'text-decoration'	=> 'none',
				'text-transform'	=> 'none',
				'letter-spacing'	=> '',
				'margin-top'		=> '0em',
				'margin-bottom'		=> '1.55em'
				),
			'h1' => array(
				'title'				=> esc_html__('Heading 1', 'save-life'),
				'font-family'		=> 'Open Sans, sans-serif',
				'font-size' 		=> '4.500em',
				'font-weight'		=> '400',
				'font-style'		=> 'normal',
				'line-height'		=> '1.1em',
				'text-decoration'	=> 'none',
				'text-transform'	=> 'none',
				'letter-spacing'	=> '0px',
				'margin-top'		=> '0.85em',
				'margin-bottom'		=> '0.66em'
				),
			'h2' => array(
				'title'				=> esc_html__('Heading 2', 'save-life'),
				'font-family'		=> 'Open Sans, sans-serif',
				'font-size' 		=> '1.875em',
				'font-weight'		=> '800',
				'font-style'		=> 'normal',
				'line-height'		=> '1.2em',
				'text-decoration'	=> 'none',
				'text-transform'	=> 'uppercase',
				'letter-spacing'	=> '0px',
				'margin-top'		=> '1.3em',
				'margin-bottom'		=> '0.68em'
				),
			'h3' => array(
				'title'				=> esc_html__('Heading 3', 'save-life'),
				'font-family'		=> 'Open Sans, sans-serif',
				'font-size' 		=> '1.875em',
				'font-weight'		=> '700',
				'font-style'		=> 'normal',
				'line-height'		=> '1.2em',
				'text-decoration'	=> 'none',
				'text-transform'	=> 'none',
				'letter-spacing'	=> '-0.75px',
				'margin-top'		=> '1.3em',
				'margin-bottom'		=> '0.825em'
				),
			'h4' => array(
				'title'				=> esc_html__('Heading 4', 'save-life'),
				'font-family'		=> 'Open Sans, sans-serif',
				'font-size' 		=> '1.500em',
				'font-weight'		=> '700',
				'font-style'		=> 'normal',
				'line-height'		=> '1.25em',
				'text-decoration'	=> 'none',
				'text-transform'	=> 'none',
				'letter-spacing'	=> '-0.6px',
				'margin-top'		=> '1.6em',
				'margin-bottom'		=> '0.7em'
				),
			'h5' => array(
				'title'				=> esc_html__('Heading 5', 'save-life'),
				'font-family'		=> 'Open Sans, sans-serif',
				'font-size' 		=> '1.125em',
				'font-weight'		=> '800',
				'font-style'		=> 'normal',
				'line-height'		=> '1.33em',
				'text-decoration'	=> 'none',
				'text-transform'	=> 'uppercase',
				'letter-spacing'	=> '0px',
				'margin-top'		=> '1.85em',
				'margin-bottom'		=> '0.9em'
				),
			'h6' => array(
				'title'				=> esc_html__('Heading 6', 'save-life'),
				'font-family'		=> 'Open Sans, sans-serif',
				'font-size' 		=> '1em',
				'font-weight'		=> '700',
				'font-style'		=> 'normal',
				'line-height'		=> '1.4em',
				'text-decoration'	=> 'none',
				'text-transform'	=> 'none',
				'letter-spacing'	=> '-0.4px',
				'margin-top'		=> '1.8em',
				'margin-bottom'		=> '0.75em'
				),
			'logo' => array(
				'title'				=> esc_html__('Logo text', 'save-life'),
				'description'		=> esc_html__('Font settings of the text case of the logo', 'save-life'),
				'font-family'		=> 'GoodDog, sans-serif',
				'font-size' 		=> '1.9em',
				'font-weight'		=> '400',
				'font-style'		=> 'normal',
				'line-height'		=> '1.25em',
				'text-decoration'	=> 'none',
				'text-transform'	=> 'uppercase',
				'letter-spacing'	=> '1px'
				),
			'button' => array(
				'title'				=> esc_html__('Buttons', 'save-life'),
				'font-family'		=> 'Open Sans, sans-serif',
				'font-size' 		=> '14px',
				'font-weight'		=> '700',
				'font-style'		=> 'normal',
				'line-height'		=> '1.2em',
				'text-decoration'	=> 'none',
				'text-transform'	=> '',
				'letter-spacing'	=> '0'
				),
			'input' => array(
				'title'				=> esc_html__('Input fields', 'save-life'),
				'description'		=> esc_html__('Font settings of the input fields, dropdowns and textareas', 'save-life'),
				'font-family'		=> 'Open Sans, sans-serif',
				'font-size' 		=> '0.875em',
				'font-weight'		=> '600',
				'font-style'		=> 'normal',
				'line-height'		=> '1.2em',
				'text-decoration'	=> 'none',
				'text-transform'	=> 'none',
				'letter-spacing'	=> '0px'
				),
			'info' => array(
				'title'				=> esc_html__('Post meta', 'save-life'),
				'description'		=> esc_html__('Font settings of the post meta: date, counters, share, etc.', 'save-life'),
				'font-family'		=> 'Open Sans, sans-serif',
				'font-size' 		=> '10px',
				'font-weight'		=> '700',
				'font-style'		=> 'normal',
				'line-height'		=> '1.5em',
				'text-decoration'	=> 'none',
				'text-transform'	=> 'uppercase',
				'letter-spacing'	=> '-0.25px',
				'margin-top'		=> '0.8em',
				'margin-bottom'		=> ''
				),
			'menu' => array(
				'title'				=> esc_html__('Main menu', 'save-life'),
				'description'		=> esc_html__('Font settings of the main menu items', 'save-life'),
				'font-family'		=> 'Open Sans, sans-serif',
				'font-size' 		=> '16px',
				'font-weight'		=> '700',
				'font-style'		=> 'normal',
				'line-height'		=> '1.5em',
				'text-decoration'	=> 'none',
				'text-transform'	=> 'uppercase',
				'letter-spacing'	=> '0px'
				),
			'submenu' => array(
				'title'				=> esc_html__('Dropdown menu', 'save-life'),
				'description'		=> esc_html__('Font settings of the dropdown menu items', 'save-life'),
				'font-family'		=> 'Open Sans, sans-serif',
				'font-size' 		=> '14px',
				'font-weight'		=> '400',
				'font-style'		=> 'normal',
				'line-height'		=> '1.4em',
				'text-decoration'	=> 'none',
				'text-transform'	=> 'none',
				'letter-spacing'	=> '0px'
				),
			'other' => array(
				'title'				=> esc_html__('Other', 'save-life'),
				'font-family'		=> 'GoodDog, sans-serif'
				),
			'accent' => array(
				'title'				=> esc_html__('Accent', 'save-life'),
				'font-family'		=> 'Oswald, sans-serif'
			)
		));
		
		
		// -----------------------------------------------------------------
		// -- Theme colors for customizer
		// -- Attention! Inner scheme must be last in the array below
		// -----------------------------------------------------------------
		save_life_storage_set('schemes', array(
		
			// Color scheme: 'default'
			'default' => array(
				'title'	 => esc_html__('Default', 'save-life'),
				'colors' => array(
					
					// Whole block border and background
					'bg_color'				=> '#ffffff',
					'bd_color'				=> '#d8d8d8',
		
					// Text and links colors
					'text'					=> '#7c7b7b',
					'text_light'			=> '#a7a7a7',
					'text_dark'				=> '#333333',
					'text_link'				=> '#9cd650',
					'text_hover'			=> '#41966f',
		
					// Alternative blocks (submenu, buttons, tabs, etc.)
					'alter_bg_color'		=> '#f2f2f2',
					'alter_bg_hover'		=> '#e6e8eb',
					'alter_bd_color'		=> '#e5e5e5',
					'alter_bd_hover'		=> '#dadada',
					'alter_text'			=> '#8a8a8a',
					'alter_light'			=> '#b7b7b7',
					'alter_dark'			=> '#323232',
					'alter_link'			=> '#41966f',
					'alter_hover'			=> '#9cd650',
		
					// Input fields (form's fields and textarea)
					'input_bg_color'		=> '#f2f2f2',
					'input_bg_hover'		=> 'rgba(242,242,242,0.9)',
					'input_bd_color'		=> '#f2f2f2',
					'input_bd_hover'		=> '#d7d8d8',
					'input_text'			=> '#7c7b7b',
					'input_light'			=> '#e5e5e5',
					'input_dark'			=> '#333333',
					
					// Inverse blocks (text and links on accented bg)
					'inverse_text'			=> '#1d1d1d',
					'inverse_light'			=> '#333333',
					'inverse_dark'			=> '#000000',
					'inverse_link'			=> '#ffffff',
					'inverse_hover'			=> '#1d1d1d',
		
					// Additional accented colors (if used in the current theme)
					// For example:
					'accent2'				=> '#39b0ce',
					'accent3'				=> '#fac506'

				)
			),
		
			// Color scheme: 'dark'
			'dark' => array(
				'title'  => esc_html__('Dark', 'save-life'),
				'colors' => array(
					
					// Whole block border and background
					'bg_color'				=> '#0e0d12',
					'bd_color'				=> '#1c1b1f',
		
					// Text and links colors
					'text'					=> '#b7b7b7',
					'text_light'			=> '#d2d1d1',
					'text_dark'				=> '#ffffff',
					'text_link'				=> '#9cd650',
					'text_hover'			=> '#41966f',
		
					// Alternative blocks (submenu, buttons, tabs, etc.)
					'alter_bg_color'		=> '#f2f2f2',
					'alter_bg_hover'		=> '#323232',
					'alter_bd_color'		=> '#313131',
					'alter_bd_hover'		=> '#3d3d3d',
					'alter_text'			=> '#8a8a8a',
					'alter_light'			=> '#5f5f5f',
					'alter_dark'			=> '#ffffff',
					'alter_link'			=> '#41966f',
					'alter_hover'			=> '#9cd650',
		
					// Input fields (form's fields and textarea)
					'input_bg_color'		=> '#2e2d32',	//'rgba(62,61,66,0.5)',
					'input_bg_hover'		=> '#2e2d32',	//'rgba(62,61,66,0.5)',
					'input_bd_color'		=> '#2e2d32',	//'rgba(62,61,66,0.5)',
					'input_bd_hover'		=> '#353535',
					'input_text'			=> '#b7b7b7',
					'input_light'			=> '#5f5f5f',
					'input_dark'			=> '#ffffff',
					
					// Inverse blocks (text and links on accented bg)
					'inverse_text'			=> '#1d1d1d',
					'inverse_light'			=> '#5f5f5f',
					'inverse_dark'			=> '#000000',
					'inverse_link'			=> '#ffffff',
					'inverse_hover'			=> '#1d1d1d',
				
					// Additional accented colors (if used in the current theme)
					'accent2'				=> '#39b0ce',
					'accent3'				=> '#fac506'
		
				)
			),

			'black' => array(
				'title'  => esc_html__('Black', 'save-life'),
				'colors' => array(

					// Whole block border and background
					'bg_color'				=> '#191919',
					'bd_color'				=> '#323232',

					// Text and links colors
					'text'					=> '#b7b7b7',
					'text_light'			=> '#d2d1d1',
					'text_dark'				=> '#ffffff',
					'text_link'				=> '#9cd650',
					'text_hover'			=> '#41966f',

					// Alternative blocks (submenu, buttons, tabs, etc.)
					'alter_bg_color'		=> '#f2f2f2',
					'alter_bg_hover'		=> '#28272e',
					'alter_bd_color'		=> '#313131',
					'alter_bd_hover'		=> '#3d3d3d',
					'alter_text'			=> '#8a8a8a',
					'alter_light'			=> '#5f5f5f',
					'alter_dark'			=> '#ffffff',
					'alter_link'			=> '#41966f',
					'alter_hover'			=> '#9cd650',

					// Input fields (form's fields and textarea)
					'input_bg_color'		=> '#2e2d32',
					'input_bg_hover'		=> '#2e2d32',
					'input_bd_color'		=> '#2e2d32',
					'input_bd_hover'		=> '#353535',
					'input_text'			=> '#b7b7b7',
					'input_light'			=> '#5f5f5f',
					'input_dark'			=> '#ffffff',

					// Inverse blocks (text and links on accented bg)
					'inverse_text'			=> '#1d1d1d',
					'inverse_light'			=> '#5f5f5f',
					'inverse_dark'			=> '#000000',
					'inverse_link'			=> '#ffffff',
					'inverse_hover'			=> '#1d1d1d',

					// Additional accented colors (if used in the current theme)
					'accent2'				=> '#39b0ce',
					'accent3'				=> '#fac506'

				)
			),

			'extra' => array(
				'title'	 => esc_html__('Extra', 'save-life'),
				'colors' => array(

					// Whole block border and background
					'bg_color'				=> '#ffffff',
					'bd_color'				=> '#d8d8d8',

					// Text and links colors
					'text'					=> '#b7b7b7',
					'text_light'			=> '#a7a7a7',
					'text_dark'				=> '#ffffff',
					'text_link'				=> '#9cd650',
					'text_hover'			=> '#41966f',

					// Alternative blocks (submenu, buttons, tabs, etc.)
					'alter_bg_color'		=> '#9cd650',
					'alter_bg_hover'		=> '#e6e8eb',
					'alter_bd_color'		=> '#e5e5e5',
					'alter_bd_hover'		=> '#dadada',
					'alter_text'			=> '#ffffff',
					'alter_light'			=> '#b7b7b7',
					'alter_dark'			=> '#41966f',
					'alter_link'			=> '#41966f',
					'alter_hover'			=> '#ffffff',

					// Input fields (form's fields and textarea)
					'input_bg_color'		=> '#f2f2f2',
					'input_bg_hover'		=> 'rgba(242,242,242,0.9)',
					'input_bd_color'		=> '#f2f2f2',
					'input_bd_hover'		=> '#d7d8d8',
					'input_text'			=> '#b7b7b7',
					'input_light'			=> '#e5e5e5',
					'input_dark'			=> '#333333',

					// Inverse blocks (text and links on accented bg)
					'inverse_text'			=> '#1d1d1d',
					'inverse_light'			=> '#333333',
					'inverse_dark'			=> '#000000',
					'inverse_link'			=> '#ffffff',
					'inverse_hover'			=> '#1d1d1d',

					// Additional accented colors (if used in the current theme)
					// For example:
					'accent2'				=> '#39b0ce',
					'accent3'				=> '#fac506'
				)
			),
		
		));
	}
}


// -----------------------------------------------------------------
// -- Theme options for customizer
// -----------------------------------------------------------------
if (!function_exists('save_life_options_create')) {

	function save_life_options_create() {

		save_life_storage_set('options', array(
		
			// Section 'Title & Tagline' - add theme options in the standard WP section
			'title_tagline' => array(
				"title" => esc_html__('Title, Tagline & Site icon', 'save-life'),
				"desc" => wp_kses_data( __('Specify site title and tagline (if need) and upload the site icon', 'save-life') ),
				"type" => "section"
				),
		
		
			// Section 'Header' - add theme options in the standard WP section
			'header_image' => array(
				"title" => esc_html__('Header', 'save-life'),
				"desc" => wp_kses_data( __('Select or upload logo images, select header type and widgets set for the header', 'save-life') ),
				"type" => "section"
				),
			'header_image_override' => array(
				"title" => esc_html__('Header image override', 'save-life'),
				"desc" => wp_kses_data( __("Allow override the header image with the page's/post's/product's/etc. featured image", 'save-life') ),
				"override" => array(
					'mode' => 'page',
					'section' => esc_html__('Header', 'save-life')
				),
				"std" => 0,
				"type" => "checkbox"
				),
			'header_fullheight' => array(
				"title" => esc_html__('Header fullheight', 'save-life'),
				"desc" => wp_kses_data( __("Enlarge header area to fill whole screen. Used only if header have a background image", 'save-life') ),
				"override" => array(
					'mode' => 'page',
					'section' => esc_html__('Header', 'save-life')
				),
				"std" => 0,
				"type" => "checkbox"
				),
			'header_wide' => array(
				"title" => esc_html__('Header fullwide', 'save-life'),
				"desc" => wp_kses_data( __('Do you want to stretch the header widgets area to the entire window width?', 'save-life') ),
				"override" => array(
					'mode' => 'page',
					'section' => esc_html__('Header', 'save-life')
				),
				"std" => 1,
				"type" => "checkbox"
				),
			'header_style' => array(
				"title" => esc_html__('Header style', 'save-life'),
				"desc" => wp_kses_data( __('Select style to display the site header', 'save-life') ),
				"override" => array(
					'mode' => 'page',
					'section' => esc_html__('Header', 'save-life')
				),
				"std" => 'header-default',
				"options" => save_life_get_list_header_styles(),
				"type" => "select"
				),
			'header_position' => array(
				"title" => esc_html__('Header position', 'save-life'),
				"desc" => wp_kses_data( __('Select position to display the site header', 'save-life') ),
				"override" => array(
					'mode' => 'page',
					'section' => esc_html__('Header', 'save-life')
				),
				"std" => 'default',
				"options" => save_life_get_list_header_positions(),
				"type" => "select"
				),
			'header_widgets' => array(
				"title" => esc_html__('Header widgets', 'save-life'),
				"desc" => wp_kses_data( __('Select set of widgets to show in the header on each page', 'save-life') ),
				"override" => array(
					'mode' => 'page',
					'section' => esc_html__('Header', 'save-life'),
					"desc" => wp_kses_data( __('Select set of widgets to show in the header on this page', 'save-life') ),
				),
				"std" => 'hide',
				"options" => save_life_get_list_sidebars(false, true),
				"type" => "select"
				),
			'header_columns' => array(
				"title" => esc_html__('Header columns', 'save-life'),
				"desc" => wp_kses_data( __('Select number columns to show widgets in the Header. If 0 - autodetect by the widgets count', 'save-life') ),
				"override" => array(
					'mode' => 'page',
					'section' => esc_html__('Header', 'save-life')
				),
				"dependency" => array(
					'header_widgets' => array('^hide')
				),
				"std" => 0,
				"options" => save_life_get_list_range(0,6),
				"type" => "select"
				),
			'header_scheme' => array(
				"title" => esc_html__('Header Color Scheme', 'save-life'),
				"desc" => wp_kses_data( __('Select color scheme to decorate header area', 'save-life') ),
				"override" => array(
					'mode' => 'page',
					'section' => esc_html__('Header', 'save-life')
				),
				"std" => 'inherit',
				"options" => save_life_get_list_schemes(true),
				"refresh" => false,
				"type" => "select"
				),
			'menu_info' => array(
				"title" => esc_html__('Menu settings', 'save-life'),
				"desc" => wp_kses_data( __('Select main menu style, position, color scheme and other parameters', 'save-life') ),
				"type" => "info"
				),
			'menu_style' => array(
				"title" => esc_html__('Menu position', 'save-life'),
				"desc" => wp_kses_data( __('Select position of the main menu', 'save-life') ),
				"override" => array(
					'mode' => 'page',
					'section' => esc_html__('Header', 'save-life')
				),
				"std" => 'top',
				"options" => array(
					'top'	=> esc_html__('Top',	'save-life'),
					'left'	=> esc_html__('Left',	'save-life'),
					'right'	=> esc_html__('Right',	'save-life')
				),
				"type" => "switch"
				),
			'menu_scheme' => array(
				"title" => esc_html__('Menu Color Scheme', 'save-life'),
				"desc" => wp_kses_data( __('Select color scheme to decorate main menu area', 'save-life') ),
				"override" => array(
					'mode' => 'page',
					'section' => esc_html__('Header', 'save-life')
				),
				"std" => 'inherit',
				"options" => save_life_get_list_schemes(true),
				"refresh" => false,
				"type" => "select"
				),

			'show_page_title' => array(
				"title" => esc_html__('Show Page Title', 'save-life'),
				"desc" => wp_kses_data( __('Show Page Title', 'save-life') ),
				"override" => array(
					'mode' => 'page',
					'section' => esc_html__('Header', 'save-life')
				),
				"std" => 1,
				"type" => "checkbox"
			),

			'menu_side_stretch' => array(
				"title" => esc_html__('Stretch sidemenu', 'save-life'),
				"desc" => wp_kses_data( __('Stretch sidemenu to window height (if menu items number >= 5)', 'save-life') ),
				"dependency" => array(
					'menu_style' => array('left', 'right')
				),
				"std" => 1,
				"type" => "checkbox"
				),
			'menu_side_icons' => array(
				"title" => esc_html__('Iconed sidemenu', 'save-life'),
				"desc" => wp_kses_data( __('Get icons from anchors and display it in the sidemenu or mark sidemenu items with simple dots', 'save-life') ),
				"dependency" => array(
					'menu_style' => array('left', 'right')
				),
				"std" => 1,
				"type" => "checkbox"
				),
			'menu_mobile_fullscreen' => array(
				"title" => esc_html__('Mobile menu fullscreen', 'save-life'),
				"desc" => wp_kses_data( __('Display mobile and side menus on full screen (if checked) or slide narrow menu from the left or from the right side (if not checked)', 'save-life') ),
				"dependency" => array(
					'menu_style' => array('left', 'right')
				),
				"std" => 1,
				"type" => "checkbox"
				),
			'logo_info' => array(
				"title" => esc_html__('Logo settings', 'save-life'),
				"desc" => wp_kses_data( __('Select logo images for the normal and Retina displays', 'save-life') ),
				"type" => "info"
				),
			'logo' => array(
				"title" => esc_html__('Logo', 'save-life'),
				"desc" => wp_kses_data( __('Select or upload site logo', 'save-life') ),
				"std" => '',
				"type" => "image"
				),
			'logo_retina' => array(
				"title" => esc_html__('Logo for Retina', 'save-life'),
				"desc" => wp_kses_data( __('Select or upload site logo used on Retina displays (if empty - use default logo from the field above)', 'save-life') ),
				"std" => '',
				"type" => "image"
				),
			'logo_inverse' => array(
				"title" => esc_html__('Logo inverse', 'save-life'),
				"desc" => wp_kses_data( __('Select or upload site logo to display it on the dark background', 'save-life') ),
				"std" => '',
				"type" => "image"
				),
			'logo_inverse_retina' => array(
				"title" => esc_html__('Logo inverse for Retina', 'save-life'),
				"desc" => wp_kses_data( __('Select or upload site logo used on Retina displays (if empty - use default logo from the field above)', 'save-life') ),
				"std" => '',
				"type" => "image"
				),
			'logo_side' => array(
				"title" => esc_html__('Logo side', 'save-life'),
				"desc" => wp_kses_data( __('Select or upload site logo (with vertical orientation) to display it in the side menu', 'save-life') ),
				"std" => '',
				"type" => "image"
				),
			'logo_side_retina' => array(
				"title" => esc_html__('Logo side for Retina', 'save-life'),
				"desc" => wp_kses_data( __('Select or upload site logo (with vertical orientation) to display it in the side menu on Retina displays (if empty - use default logo from the field above)', 'save-life') ),
				"std" => '',
				"type" => "image"
				),
			'logo_text' => array(
				"title" => esc_html__('Logo from Site name', 'save-life'),
				"desc" => wp_kses_data( __('Do you want use Site name and description as Logo if images above are not selected?', 'save-life') ),
				"std" => 1,
				"type" => "checkbox"
				),
			
		
		
			// Section 'Content'
			'content' => array(
				"title" => esc_html__('Content', 'save-life'),
				"desc" => wp_kses_data( __('Options for the content area', 'save-life') ),
				"type" => "section",
				),
			'body_style' => array(
				"title" => esc_html__('Body style', 'save-life'),
				"desc" => wp_kses_data( __('Select width of the body content', 'save-life') ),
				"override" => array(
					'mode' => 'page',
					'section' => esc_html__('Content', 'save-life')
				),
				"refresh" => false,
				"std" => 'boxed',
				"options" => array(
					'boxed'		=> esc_html__('Boxed',		'save-life'),
					'wide'		=> esc_html__('Wide',		'save-life'),
					'fullwide'	=> esc_html__('Fullwide',	'save-life'),
					'fullscreen'=> esc_html__('Fullscreen',	'save-life')
				),
				"type" => "select"
				),
			'color_scheme' => array(
				"title" => esc_html__('Site Color Scheme', 'save-life'),
				"desc" => wp_kses_data( __('Select color scheme to decorate whole site. Attention! Case "Inherit" can be used only for custom pages, not for root site content in the Appearance - Customize', 'save-life') ),
				"override" => array(
					'mode' => 'page',
					'section' => esc_html__('Content', 'save-life')
				),
				"std" => 'default',
				"options" => save_life_get_list_schemes(true),
				"refresh" => false,
				"type" => "select"
				),
			'expand_content' => array(
				"title" => esc_html__('Expand content', 'save-life'),
				"desc" => wp_kses_data( __('Expand the content width if the sidebar is hidden', 'save-life') ),
				"override" => array(
					'mode' => 'page,cpt_team,cpt_services,cpt_courses,cpt_portfolio',
					'section' => esc_html__('Content', 'save-life')
				),
				"refresh" => false,
				"std" => 1,
				"type" => "checkbox"
				),
			'remove_margins' => array(
				"title" => esc_html__('Remove margins', 'save-life'),
				"desc" => wp_kses_data( __('Remove margins above and below the content area', 'save-life') ),
				"override" => array(
					'mode' => 'page,cpt_team,cpt_services,cpt_courses,cpt_portfolio',
					'section' => esc_html__('Content', 'save-life')
				),
				"refresh" => false,
				"std" => 0,
				"type" => "checkbox"
				),
			'seo_snippets' => array(
				"title" => esc_html__('SEO snippets', 'save-life'),
				"desc" => wp_kses_data( __('Add structured data markup to the single posts and pages', 'save-life') ),
				"std" => 0,
				"type" => "checkbox"
				),
            'privacy_text' => array(
                "title" => esc_html__("Text with Privacy Policy link", 'save-life'),
                "desc"  => wp_kses_data( __("Specify text with Privacy Policy link for the checkbox 'I agree ...'", 'save-life') ),
                "std"   => wp_kses_post( __( 'I agree that my submitted data is being collected and stored.', 'save-life') ),
                "type"  => "text"
            ),
			'border_radius' => array(
				"title" => esc_html__('Border radius', 'save-life'),
				"desc" => wp_kses_data( __('Specify the border radius of the form fields and buttons in pixels or other valid CSS units', 'save-life') ),
				"std" => '5px',
				"type" => "text"
				),
			'boxed_bg_image' => array(
				"title" => esc_html__('Boxed bg image', 'save-life'),
				"desc" => wp_kses_data( __('Select or upload image, used as background in the boxed body', 'save-life') ),
				"dependency" => array(
					'body_style' => array('boxed')
				),
				"override" => array(
					'mode' => 'page',
					'section' => esc_html__('Content', 'save-life')
				),
				"std" => '',
				"type" => "image"
				),
			'no_image' => array(
				"title" => esc_html__('No image placeholder', 'save-life'),
				"desc" => wp_kses_data( __('Select or upload image, used as placeholder for the posts without featured image', 'save-life') ),
				"std" => '',
				"type" => "image"
				),
			'sidebar_widgets' => array(
				"title" => esc_html__('Sidebar widgets', 'save-life'),
				"desc" => wp_kses_data( __('Select default widgets to show in the sidebar', 'save-life') ),
				"override" => array(
					'mode' => 'page,cpt_team,cpt_services,cpt_courses,cpt_portfolio',
					'section' => esc_html__('Widgets', 'save-life')
				),
				"std" => 'hide',
				"options" => save_life_get_list_sidebars(false, true),
				"type" => "select"
				),
			'sidebar_scheme' => array(
				"title" => esc_html__('Sidebar Color Scheme', 'save-life'),
				"desc" => wp_kses_data( __('Select color scheme to decorate sidebar', 'save-life') ),
				"override" => array(
					'mode' => 'page,cpt_team,cpt_services,cpt_courses,cpt_portfolio',
					'section' => esc_html__('Widgets', 'save-life')
				),
				"std" => 'inherit',
				"options" => save_life_get_list_schemes(true),
				"refresh" => false,
				"type" => "select"
				),
			'sidebar_position' => array(
				"title" => esc_html__('Sidebar position', 'save-life'),
				"desc" => wp_kses_data( __('Select position to show sidebar', 'save-life') ),
				"override" => array(
					'mode' => 'page,cpt_team,cpt_services,cpt_courses,cpt_portfolio',
					'section' => esc_html__('Widgets', 'save-life')
				),
				"refresh" => false,
				"std" => 'right',
				"options" => save_life_get_list_sidebars_positions(),
				"type" => "select"
				),
			'hide_sidebar_on_single' => array(
				"title" => esc_html__('Hide sidebar on the single post', 'save-life'),
				"desc" => wp_kses_data( __("Hide sidebar on the single post's pages", 'save-life') ),
				"std" => 0,
				"type" => "checkbox"
				),
			'widgets_above_page' => array(
				"title" => esc_html__('Widgets above the page', 'save-life'),
				"desc" => wp_kses_data( __('Select widgets to show above page (content and sidebar)', 'save-life') ),
				"override" => array(
					'mode' => 'page',
					'section' => esc_html__('Widgets', 'save-life')
				),
				"std" => 'hide',
				"options" => save_life_get_list_sidebars(false, true),
				"type" => "select"
				),
			'widgets_above_content' => array(
				"title" => esc_html__('Widgets above the content', 'save-life'),
				"desc" => wp_kses_data( __('Select widgets to show at the beginning of the content area', 'save-life') ),
				"override" => array(
					'mode' => 'page',
					'section' => esc_html__('Widgets', 'save-life')
				),
				"std" => 'hide',
				"options" => save_life_get_list_sidebars(false, true),
				"type" => "select"
				),
			'widgets_below_content' => array(
				"title" => esc_html__('Widgets below the content', 'save-life'),
				"desc" => wp_kses_data( __('Select widgets to show at the ending of the content area', 'save-life') ),
				"override" => array(
					'mode' => 'page',
					'section' => esc_html__('Widgets', 'save-life')
				),
				"std" => 'hide',
				"options" => save_life_get_list_sidebars(false, true),
				"type" => "select"
				),
			'widgets_below_page' => array(
				"title" => esc_html__('Widgets below the page', 'save-life'),
				"desc" => wp_kses_data( __('Select widgets to show below the page (content and sidebar)', 'save-life') ),
				"override" => array(
					'mode' => 'page',
					'section' => esc_html__('Widgets', 'save-life')
				),
				"std" => 'hide',
				"options" => save_life_get_list_sidebars(false, true),
				"type" => "select"
				),
		
		
		
			// Section 'Footer'
			'footer' => array(
				"title" => esc_html__('Footer', 'save-life'),
				"desc" => wp_kses_data( __('Select set of widgets and columns number for the site footer', 'save-life') ),
				"type" => "section"
				),
			'footer_style' => array(
				"title" => esc_html__('Footer style', 'save-life'),
				"desc" => wp_kses_data( __('Select style to display the site footer', 'save-life') ),
				"override" => array(
					'mode' => 'page',
					'section' => esc_html__('Footer', 'save-life')
				),
				"std" => 'footer-default',
				"options" => apply_filters('save_life_filter_list_footer_styles', array(
					'footer-default' => esc_html__('Default Footer',	'save-life')
				)),
				"type" => "select"
				),
			'footer_scheme' => array(
				"title" => esc_html__('Footer Color Scheme', 'save-life'),
				"desc" => wp_kses_data( __('Select color scheme to decorate footer area', 'save-life') ),
				"override" => array(
					'mode' => 'page,cpt_team,cpt_services,cpt_courses,cpt_portfolio',
					'section' => esc_html__('Footer', 'save-life')
				),
				"std" => 'dark',
				"options" => save_life_get_list_schemes(true),
				"refresh" => false,
				"type" => "select"
				),
			'footer_widgets' => array(
				"title" => esc_html__('Footer widgets', 'save-life'),
				"desc" => wp_kses_data( __('Select set of widgets to show in the footer', 'save-life') ),
				"override" => array(
					'mode' => 'page,cpt_team,cpt_services,cpt_courses,cpt_portfolio',
					'section' => esc_html__('Footer', 'save-life')
				),
				"std" => 'footer_widgets',
				"options" => save_life_get_list_sidebars(false, true),
				"type" => "select"
				),
			'footer_columns' => array(
				"title" => esc_html__('Footer columns', 'save-life'),
				"desc" => wp_kses_data( __('Select number columns to show widgets in the footer. If 0 - autodetect by the widgets count', 'save-life') ),
				"override" => array(
					'mode' => 'page,cpt_team,cpt_services,cpt_courses,cpt_portfolio',
					'section' => esc_html__('Footer', 'save-life')
				),
				"dependency" => array(
					'footer_widgets' => array('^hide')
				),
				"std" => 0,
				"options" => save_life_get_list_range(0,6),
				"type" => "select"
				),
			'footer_wide' => array(
				"title" => esc_html__('Footer fullwide', 'save-life'),
				"desc" => wp_kses_data( __('Do you want to stretch the footer to the entire window width?', 'save-life') ),
				"override" => array(
					'mode' => 'page,cpt_team,cpt_services,cpt_courses,cpt_portfolio',
					'section' => esc_html__('Footer', 'save-life')
				),
				"std" => 0,
				"type" => "checkbox"
				),
			'logo_in_footer' => array(
				"title" => esc_html__('Show logo', 'save-life'),
				"desc" => wp_kses_data( __('Show logo in the footer', 'save-life') ),
				'refresh' => false,
				"std" => 0,
				"type" => "checkbox"
				),
			'logo_footer' => array(
				"title" => esc_html__('Logo for footer', 'save-life'),
				"desc" => wp_kses_data( __('Select or upload site logo to display it in the footer', 'save-life') ),
				"dependency" => array(
					'logo_in_footer' => array('1')
				),
				"std" => '',
				"type" => "image"
				),
			'logo_footer_retina' => array(
				"title" => esc_html__('Logo for footer (Retina)', 'save-life'),
				"desc" => wp_kses_data( __('Select or upload logo for the footer area used on Retina displays (if empty - use default logo from the field above)', 'save-life') ),
				"dependency" => array(
					'logo_in_footer' => array('1')
				),
				"std" => '',
				"type" => "image"
				),
			'socials_in_footer' => array(
				"title" => esc_html__('Show social icons', 'save-life'),
				"desc" => wp_kses_data( __('Show social icons in the footer (under logo or footer widgets)', 'save-life') ),
				"std" => 0,
				"type" => "checkbox"
				),
			'copyright' => array(
				"title" => esc_html__('Copyright', 'save-life'),
				"desc" => wp_kses_data( __('Copyright text in the footer. Use {Y} to insert current year and press "Enter" to create a new line', 'save-life') ),
				"std" => esc_html__('ThemeREX &copy; {Y}. All rights reserved. Terms of use and Privacy Policy', 'save-life'),
				"refresh" => false,
				"type" => "textarea"
				),
		
		
		
			// Section 'Homepage' - settings for home page
			'homepage' => array(
				"title" => esc_html__('Homepage', 'save-life'),
				"desc" => wp_kses_data( __('Select blog style and widgets to display on the homepage', 'save-life') ),
				"type" => "section"
				),
			'expand_content_home' => array(
				"title" => esc_html__('Expand content', 'save-life'),
				"desc" => wp_kses_data( __('Expand the content width if the sidebar is hidden on the Homepage', 'save-life') ),
				"refresh" => false,
				"std" => 1,
				"type" => "checkbox"
				),
			'blog_style_home' => array(
				"title" => esc_html__('Blog style', 'save-life'),
				"desc" => wp_kses_data( __('Select posts style for the homepage', 'save-life') ),
				"std" => 'excerpt',
				"options" => save_life_get_list_blog_styles(),
				"type" => "select"
				),
			'first_post_large_home' => array(
				"title" => esc_html__('First post large', 'save-life'),
				"desc" => wp_kses_data( __('Make first post large (with Excerpt layout) on the Classic layout of the Homepage', 'save-life') ),
				"dependency" => array(
					'blog_style_home' => array('classic')
				),
				"std" => 0,
				"type" => "checkbox"
				),
			'header_style_home' => array(
				"title" => esc_html__('Header style', 'save-life'),
				"desc" => wp_kses_data( __('Select style to display the site header on the homepage', 'save-life') ),
				"std" => 'inherit',
				"options" => save_life_get_list_header_styles(true),
				"type" => "select"
				),
			'header_position_home' => array(
				"title" => esc_html__('Header position', 'save-life'),
				"desc" => wp_kses_data( __('Select position to display the site header on the homepage', 'save-life') ),
				"std" => 'inherit',
				"options" => save_life_get_list_header_positions(true),
				"type" => "select"
				),
			'header_widgets_home' => array(
				"title" => esc_html__('Header widgets', 'save-life'),
				"desc" => wp_kses_data( __('Select set of widgets to show in the header on the homepage', 'save-life') ),
				"std" => 'header_widgets',
				"options" => save_life_get_list_sidebars(true, true),
				"type" => "select"
				),
			'sidebar_widgets_home' => array(
				"title" => esc_html__('Sidebar widgets', 'save-life'),
				"desc" => wp_kses_data( __('Select sidebar to show on the homepage', 'save-life') ),
				"std" => 'inherit',
				"options" => save_life_get_list_sidebars(true, true),
				"type" => "select"
				),
			'sidebar_position_home' => array(
				"title" => esc_html__('Sidebar position', 'save-life'),
				"desc" => wp_kses_data( __('Select position to show sidebar on the homepage', 'save-life') ),
				"refresh" => false,
				"std" => 'inherit',
				"options" => save_life_get_list_sidebars_positions(true),
				"type" => "select"
				),
			'widgets_above_page_home' => array(
				"title" => esc_html__('Widgets above the page', 'save-life'),
				"desc" => wp_kses_data( __('Select widgets to show above page (content and sidebar)', 'save-life') ),
				"std" => 'hide',
				"options" => save_life_get_list_sidebars(true, true),
				"type" => "select"
				),
			'widgets_above_content_home' => array(
				"title" => esc_html__('Widgets above the content', 'save-life'),
				"desc" => wp_kses_data( __('Select widgets to show at the beginning of the content area', 'save-life') ),
				"std" => 'hide',
				"options" => save_life_get_list_sidebars(true, true),
				"type" => "select"
				),
			'widgets_below_content_home' => array(
				"title" => esc_html__('Widgets below the content', 'save-life'),
				"desc" => wp_kses_data( __('Select widgets to show at the ending of the content area', 'save-life') ),
				"std" => 'hide',
				"options" => save_life_get_list_sidebars(true, true),
				"type" => "select"
				),
			'widgets_below_page_home' => array(
				"title" => esc_html__('Widgets below the page', 'save-life'),
				"desc" => wp_kses_data( __('Select widgets to show below the page (content and sidebar)', 'save-life') ),
				"std" => 'hide',
				"options" => save_life_get_list_sidebars(true, true),
				"type" => "select"
				),
			
		
		
			// Section 'Blog archive'
			'blog' => array(
				"title" => esc_html__('Blog archive', 'save-life'),
				"desc" => wp_kses_data( __('Options for the blog archive', 'save-life') ),
				"type" => "section",
				),
			'expand_content_blog' => array(
				"title" => esc_html__('Expand content', 'save-life'),
				"desc" => wp_kses_data( __('Expand the content width if the sidebar is hidden on the blog archive', 'save-life') ),
				"refresh" => false,
				"std" => 1,
				"type" => "checkbox"
				),
			'blog_style' => array(
				"title" => esc_html__('Blog style', 'save-life'),
				"desc" => wp_kses_data( __('Select posts style for the blog archive', 'save-life') ),
				"override" => array(
					'mode' => 'page',
					'section' => esc_html__('Content', 'save-life')
				),
				"dependency" => array(
                    '#page_template' => array( 'blog.php' ),
                    '.editor-page-attributes__template select' => array( 'blog.php' ),
				),
				"std" => 'excerpt',
				"options" => save_life_get_list_blog_styles(),
				"type" => "select"
				),
			'blog_columns' => array(
				"title" => esc_html__('Blog columns', 'save-life'),
				"desc" => wp_kses_data( __('How many columns should be used in the blog archive (from 2 to 4)?', 'save-life') ),
				"std" => 2,
				"options" => save_life_get_list_range(2,4),
				"type" => "hidden"
				),
			'post_type' => array(
				"title" => esc_html__('Post type', 'save-life'),
				"desc" => wp_kses_data( __('Select post type to show in the blog archive', 'save-life') ),
				"override" => array(
					'mode' => 'page',
					'section' => esc_html__('Content', 'save-life')
				),
				"dependency" => array(
                    '#page_template' => array( 'blog.php' ),
                    '.editor-page-attributes__template select' => array( 'blog.php' ),
				),
				"linked" => 'parent_cat',
				"refresh" => false,
				"hidden" => true,
				"std" => 'post',
				"options" => save_life_get_list_posts_types(),
				"type" => "select"
				),
			'parent_cat' => array(
				"title" => esc_html__('Category to show', 'save-life'),
				"desc" => wp_kses_data( __('Select category to show in the blog archive', 'save-life') ),
				"override" => array(
					'mode' => 'page',
					'section' => esc_html__('Content', 'save-life')
				),
				"dependency" => array(
                    '#page_template' => array( 'blog.php' ),
                    '.editor-page-attributes__template select' => array( 'blog.php' ),
				),
				"refresh" => false,
				"hidden" => true,
				"std" => '0',
				"options" => save_life_array_merge(array(0 => esc_html__('- Select category -', 'save-life')), save_life_get_list_categories()),
				"type" => "select"
				),
			'posts_per_page' => array(
				"title" => esc_html__('Posts per page', 'save-life'),
				"desc" => wp_kses_data( __('How many posts will be displayed on this page', 'save-life') ),
				"override" => array(
					'mode' => 'page',
					'section' => esc_html__('Content', 'save-life')
				),
				"dependency" => array(
                    '#page_template' => array( 'blog.php' ),
                    '.editor-page-attributes__template select' => array( 'blog.php' ),
				),
				"hidden" => true,
				"std" => '10',
				"type" => "text"
				),
			"blog_pagination" => array( 
				"title" => esc_html__('Pagination style', 'save-life'),
				"desc" => wp_kses_data( __('Show Older/Newest posts or Page numbers below the posts list', 'save-life') ),
				"override" => array(
					'mode' => 'page',
					'section' => esc_html__('Content', 'save-life')
				),
				"std" => "links",
				"options" => array(
					'pages'	=> esc_html__("Page numbers", 'save-life'),
					'links'	=> esc_html__("Older/Newest", 'save-life'),
					'more'	=> esc_html__("Load more", 'save-life'),
					'infinite' => esc_html__("Infinite scroll", 'save-life')
				),
				"type" => "select"
				),
			'show_filters' => array(
				"title" => esc_html__('Show filters', 'save-life'),
				"desc" => wp_kses_data( __('Show categories as tabs to filter posts', 'save-life') ),
				"override" => array(
					'mode' => 'page',
					'section' => esc_html__('Content', 'save-life')
				),
				"dependency" => array(
                    '#page_template' => array( 'blog.php' ),
                    '.editor-page-attributes__template select' => array( 'blog.php' ),
					'blog_style' => array('portfolio', 'gallery')
				),
				"hidden" => true,
				"std" => 0,
				"type" => "checkbox"
				),
			'first_post_large' => array(
				"title" => esc_html__('First post large', 'save-life'),
				"desc" => wp_kses_data( __('Make first post large (with Excerpt layout) on the Classic layout of blog archive', 'save-life') ),
				"dependency" => array(
					'blog_style' => array('classic')
				),
				"std" => 0,
				"type" => "checkbox"
				),
			"blog_content" => array( 
				"title" => esc_html__('Posts content', 'save-life'),
				"desc" => wp_kses_data( __("Show full post's content in the blog or only post's excerpt", 'save-life') ),
				"std" => "excerpt",
				"options" => array(
					'excerpt'	=> esc_html__('Excerpt',	'save-life'),
					'fullpost'	=> esc_html__('Full post',	'save-life')
				),
				"type" => "select"
				),
			'time_diff_before' => array(
				"title" => esc_html__('Time difference', 'save-life'),
				"desc" => wp_kses_data( __("How many days show time difference instead post's date", 'save-life') ),
				"std" => 5,
				"type" => "text"
				),
			'related_posts' => array(
				"title" => esc_html__('Related posts', 'save-life'),
				"desc" => wp_kses_data( __('How many related posts should be displayed in the single post?', 'save-life') ),
				"std" => 2,
				"options" => save_life_get_list_range(2,4),
				"type" => "select"
				),
			'related_style' => array(
				"title" => esc_html__('Related posts style', 'save-life'),
				"desc" => wp_kses_data( __('Select style of the related posts output', 'save-life') ),
				"std" => 2,
				"options" => save_life_get_list_styles(1,2),
				"type" => "select"
				),
			"blog_animation" => array( 
				"title" => esc_html__('Animation for the posts', 'save-life'),
				"desc" => wp_kses_data( __('Select animation to show posts in the blog. Attention! Do not use any animation on pages with the "wheel to the anchor" behaviour (like a "Chess 2 columns")!', 'save-life') ),
				"override" => array(
					'mode' => 'page',
					'section' => esc_html__('Content', 'save-life')
				),
				"dependency" => array(
                    '#page_template' => array( 'blog.php' ),
                    '.editor-page-attributes__template select' => array( 'blog.php' ),
				),
				"std" => "none",
				"options" => save_life_get_list_animations_in(),
				"type" => "select"
				),
			'header_style_blog' => array(
				"title" => esc_html__('Header style', 'save-life'),
				"desc" => wp_kses_data( __('Select style to display the site header on the blog archive', 'save-life') ),
				"std" => 'inherit',
				"options" => save_life_get_list_header_styles(true),
				"type" => "select"
				),
			'header_position_blog' => array(
				"title" => esc_html__('Header position', 'save-life'),
				"desc" => wp_kses_data( __('Select position to display the site header on the blog archive', 'save-life') ),
				"std" => 'inherit',
				"options" => save_life_get_list_header_positions(true),
				"type" => "select"
				),
			'header_widgets_blog' => array(
				"title" => esc_html__('Header widgets', 'save-life'),
				"desc" => wp_kses_data( __('Select set of widgets to show in the header on the blog archive', 'save-life') ),
				"std" => 'inherit',
				"options" => save_life_get_list_sidebars(true, true),
				"type" => "select"
				),
			'sidebar_widgets_blog' => array(
				"title" => esc_html__('Sidebar widgets', 'save-life'),
				"desc" => wp_kses_data( __('Select sidebar to show on the blog archive', 'save-life') ),
				"std" => 'inherit',
				"options" => save_life_get_list_sidebars(true, true),
				"type" => "select"
				),
			'sidebar_position_blog' => array(
				"title" => esc_html__('Sidebar position', 'save-life'),
				"desc" => wp_kses_data( __('Select position to show sidebar on the blog archive', 'save-life') ),
				"refresh" => false,
				"std" => 'inherit',
				"options" => save_life_get_list_sidebars_positions(true),
				"type" => "select"
				),
			'hide_sidebar_on_single_blog' => array(
				"title" => esc_html__('Hide sidebar on the single post', 'save-life'),
				"desc" => wp_kses_data( __("Hide sidebar on the single post", 'save-life') ),
				"std" => 0,
				"type" => "checkbox"
				),
			'widgets_above_page_blog' => array(
				"title" => esc_html__('Widgets above the page', 'save-life'),
				"desc" => wp_kses_data( __('Select widgets to show above page (content and sidebar)', 'save-life') ),
				"std" => 'inherit',
				"options" => save_life_get_list_sidebars(true, true),
				"type" => "select"
				),
			'widgets_above_content_blog' => array(
				"title" => esc_html__('Widgets above the content', 'save-life'),
				"desc" => wp_kses_data( __('Select widgets to show at the beginning of the content area', 'save-life') ),
				"std" => 'inherit',
				"options" => save_life_get_list_sidebars(true, true),
				"type" => "select"
				),
			'widgets_below_content_blog' => array(
				"title" => esc_html__('Widgets below the content', 'save-life'),
				"desc" => wp_kses_data( __('Select widgets to show at the ending of the content area', 'save-life') ),
				"std" => 'inherit',
				"options" => save_life_get_list_sidebars(true, true),
				"type" => "select"
				),
			'widgets_below_page_blog' => array(
				"title" => esc_html__('Widgets below the page', 'save-life'),
				"desc" => wp_kses_data( __('Select widgets to show below the page (content and sidebar)', 'save-life') ),
				"std" => 'inherit',
				"options" => save_life_get_list_sidebars(true, true),
				"type" => "select"
				),
			
		
		
		
			// Section 'Colors' - choose color scheme and customize separate colors from it
			'scheme' => array(
				"title" => esc_html__('* Color scheme editor', 'save-life'),
				"desc" => wp_kses_data( __("<b>Simple settings</b> - you can change only accented color, used for links, buttons and some accented areas.", 'save-life') )
						. '<br>'
						. wp_kses_data( __("<b>Advanced settings</b> - change all scheme's colors and get full control over the appearance of your site!", 'save-life') ),
				"priority" => 1000,
				"type" => "section"
				),
		
			'color_settings' => array(
				"title" => esc_html__('Color settings', 'save-life'),
				"desc" => '',
				"std" => 'simple',
				"options" => array(
					"simple"  => esc_html__("Simple", 'save-life'),
					"advanced" => esc_html__("Advanced", 'save-life')
				),
				"refresh" => false,
				"type" => "switch"
				),
		
			'color_scheme_editor' => array(
				"title" => esc_html__('Color Scheme', 'save-life'),
				"desc" => wp_kses_data( __('Select color scheme to edit colors', 'save-life') ),
				"std" => 'default',
				"options" => save_life_get_list_schemes(),
				"refresh" => false,
				"type" => "select"
				),
		
			'scheme_storage' => array(
				"title" => esc_html__('Colors storage', 'save-life'),
				"desc" => esc_html__('Hidden storage of the all color from the all color shemes (only for internal usage)', 'save-life'),
				"std" => '',
				"refresh" => false,
				"type" => "hidden"
				),
		
			'scheme_info_single' => array(
				"title" => esc_html__('Colors for single post/page', 'save-life'),
				"desc" => wp_kses_data( __('Specify colors for single post/page (not for alter blocks)', 'save-life') ),
				"dependency" => array(
					'color_settings' => array('^simple')
				),
				"type" => "info"
				),
				
			'bg_color' => array(
				"title" => esc_html__('Background color', 'save-life'),
				"desc" => wp_kses_data( __('Background color of the whole page', 'save-life') ),
				"dependency" => array(
					'color_settings' => array('^simple')
				),
				"std" => '$save_life_get_scheme_color',
				"refresh" => false,
				"type" => "color"
				),
			'bd_color' => array(
				"title" => esc_html__('Border color', 'save-life'),
				"desc" => wp_kses_data( __('Color of the bordered elements, separators, etc.', 'save-life') ),
				"dependency" => array(
					'color_settings' => array('^simple')
				),
				"std" => '$save_life_get_scheme_color',
				"refresh" => false,
				"type" => "color"
				),
		
			'text' => array(
				"title" => esc_html__('Text', 'save-life'),
				"desc" => wp_kses_data( __('Plain text color on single page/post', 'save-life') ),
				"dependency" => array(
					'color_settings' => array('^simple')
				),
				"std" => '$save_life_get_scheme_color',
				"refresh" => false,
				"type" => "color"
				),
			'text_light' => array(
				"title" => esc_html__('Light text', 'save-life'),
				"desc" => wp_kses_data( __('Color of the post meta: post date and author, comments number, etc.', 'save-life') ),
				"dependency" => array(
					'color_settings' => array('^simple')
				),
				"std" => '$save_life_get_scheme_color',
				"refresh" => false,
				"type" => "color"
				),
			'text_dark' => array(
				"title" => esc_html__('Dark text', 'save-life'),
				"desc" => wp_kses_data( __('Color of the headers, strong text, etc.', 'save-life') ),
				"dependency" => array(
					'color_settings' => array('^simple')
				),
				"std" => '$save_life_get_scheme_color',
				"refresh" => false,
				"type" => "color"
				),
			'text_link' => array(
				"title" => esc_html__('Links', 'save-life'),
				"desc" => wp_kses_data( __('Color of links and accented areas', 'save-life') ),
				"std" => '$save_life_get_scheme_color',
				"refresh" => false,
				"type" => "color"
				),
			'text_hover' => array(
				"title" => esc_html__('Links hover', 'save-life'),
				"desc" => wp_kses_data( __('Hover color for links and accented areas', 'save-life') ),
				"std" => '$save_life_get_scheme_color',
				"refresh" => false,
				"type" => "color"
				),
		
			'scheme_info_alter' => array(
				"title" => esc_html__('Colors for alternative blocks', 'save-life'),
				"desc" => wp_kses_data( __('Specify colors for alternative blocks - rectangular blocks with its own background color (posts in homepage, blog archive, search results, widgets on sidebar, footer, etc.)', 'save-life') ),
				"dependency" => array(
					'color_settings' => array('^simple')
				),
				"type" => "info"
				),
		
			'alter_bg_color' => array(
				"title" => esc_html__('Alter background color', 'save-life'),
				"desc" => wp_kses_data( __('Background color of the alternative blocks', 'save-life') ),
				"dependency" => array(
					'color_settings' => array('^simple')
				),
				"std" => '$save_life_get_scheme_color',
				"refresh" => false,
				"type" => "color"
				),
			'alter_bg_hover' => array(
				"title" => esc_html__('Alter hovered background color', 'save-life'),
				"desc" => wp_kses_data( __('Background color for the hovered state of the alternative blocks', 'save-life') ),
				"dependency" => array(
					'color_settings' => array('^simple')
				),
				"std" => '$save_life_get_scheme_color',
				"refresh" => false,
				"type" => "color"
				),
			'alter_bd_color' => array(
				"title" => esc_html__('Alternative border color', 'save-life'),
				"desc" => wp_kses_data( __('Border color of the alternative blocks', 'save-life') ),
				"dependency" => array(
					'color_settings' => array('^simple')
				),
				"std" => '$save_life_get_scheme_color',
				"refresh" => false,
				"type" => "color"
				),
			'alter_bd_hover' => array(
				"title" => esc_html__('Alternative hovered border color', 'save-life'),
				"desc" => wp_kses_data( __('Border color for the hovered state of the alter blocks', 'save-life') ),
				"dependency" => array(
					'color_settings' => array('^simple')
				),
				"std" => '$save_life_get_scheme_color',
				"refresh" => false,
				"type" => "color"
				),
			'alter_text' => array(
				"title" => esc_html__('Alter text', 'save-life'),
				"desc" => wp_kses_data( __('Text color of the alternative blocks', 'save-life') ),
				"dependency" => array(
					'color_settings' => array('^simple')
				),
				"std" => '$save_life_get_scheme_color',
				"refresh" => false,
				"type" => "color"
				),
			'alter_light' => array(
				"title" => esc_html__('Alter light', 'save-life'),
				"desc" => wp_kses_data( __('Color of the info blocks inside block with alternative background', 'save-life') ),
				"dependency" => array(
					'color_settings' => array('^simple')
				),
				"std" => '$save_life_get_scheme_color',
				"refresh" => false,
				"type" => "color"
				),
			'alter_dark' => array(
				"title" => esc_html__('Alter dark', 'save-life'),
				"desc" => wp_kses_data( __('Color of the headers inside block with alternative background', 'save-life') ),
				"dependency" => array(
					'color_settings' => array('^simple')
				),
				"std" => '$save_life_get_scheme_color',
				"refresh" => false,
				"type" => "color"
				),
			'alter_link' => array(
				"title" => esc_html__('Alter link', 'save-life'),
				"desc" => wp_kses_data( __('Color of the links inside block with alternative background', 'save-life') ),
				"dependency" => array(
					'color_settings' => array('^simple')
				),
				"std" => '$save_life_get_scheme_color',
				"refresh" => false,
				"type" => "color"
				),
			'alter_hover' => array(
				"title" => esc_html__('Alter hover', 'save-life'),
				"desc" => wp_kses_data( __('Color of the hovered links inside block with alternative background', 'save-life') ),
				"dependency" => array(
					'color_settings' => array('^simple')
				),
				"std" => '$save_life_get_scheme_color',
				"refresh" => false,
				"type" => "color"
				),
		
			'scheme_info_input' => array(
				"title" => esc_html__('Colors for the form fields', 'save-life'),
				"desc" => wp_kses_data( __('Specify colors for the form fields and textareas', 'save-life') ),
				"dependency" => array(
					'color_settings' => array('^simple')
				),
				"type" => "info"
				),
		
			'input_bg_color' => array(
				"title" => esc_html__('Inactive background', 'save-life'),
				"desc" => wp_kses_data( __('Background color of the inactive form fields', 'save-life') ),
				"dependency" => array(
					'color_settings' => array('^simple')
				),
				"std" => '$save_life_get_scheme_color',
				"refresh" => false,
				"type" => "color"
				),
			'input_bg_hover' => array(
				"title" => esc_html__('Active background', 'save-life'),
				"desc" => wp_kses_data( __('Background color of the focused form fields', 'save-life') ),
				"dependency" => array(
					'color_settings' => array('^simple')
				),
				"std" => '$save_life_get_scheme_color',
				"refresh" => false,
				"type" => "color"
				),
			'input_bd_color' => array(
				"title" => esc_html__('Inactive border', 'save-life'),
				"desc" => wp_kses_data( __('Color of the border in the inactive form fields', 'save-life') ),
				"dependency" => array(
					'color_settings' => array('^simple')
				),
				"std" => '$save_life_get_scheme_color',
				"refresh" => false,
				"type" => "color"
				),
			'input_bd_hover' => array(
				"title" => esc_html__('Active border', 'save-life'),
				"desc" => wp_kses_data( __('Color of the border in the focused form fields', 'save-life') ),
				"dependency" => array(
					'color_settings' => array('^simple')
				),
				"std" => '$save_life_get_scheme_color',
				"refresh" => false,
				"type" => "color"
				),
			'input_text' => array(
				"title" => esc_html__('Inactive field', 'save-life'),
				"desc" => wp_kses_data( __('Color of the text in the inactive fields', 'save-life') ),
				"dependency" => array(
					'color_settings' => array('^simple')
				),
				"std" => '$save_life_get_scheme_color',
				"refresh" => false,
				"type" => "color"
				),
			'input_light' => array(
				"title" => esc_html__('Disabled field', 'save-life'),
				"desc" => wp_kses_data( __('Color of the disabled field', 'save-life') ),
				"dependency" => array(
					'color_settings' => array('^simple')
				),
				"std" => '$save_life_get_scheme_color',
				"refresh" => false,
				"type" => "color"
				),
			'input_dark' => array(
				"title" => esc_html__('Active field', 'save-life'),
				"desc" => wp_kses_data( __('Color of the active field', 'save-life') ),
				"dependency" => array(
					'color_settings' => array('^simple')
				),
				"std" => '$save_life_get_scheme_color',
				"refresh" => false,
				"type" => "color"
				),
		
			'scheme_info_inverse' => array(
				"title" => esc_html__('Colors for inverse blocks', 'save-life'),
				"desc" => wp_kses_data( __('Specify colors for inverse blocks, rectangular blocks with background color equal to the links color or one of accented colors (if used in the current theme)', 'save-life') ),
				"dependency" => array(
					'color_settings' => array('^simple')
				),
				"type" => "info"
				),
		
			'inverse_text' => array(
				"title" => esc_html__('Inverse text', 'save-life'),
				"desc" => wp_kses_data( __('Color of the text inside block with accented background', 'save-life') ),
				"dependency" => array(
					'color_settings' => array('^simple')
				),
				"std" => '$save_life_get_scheme_color',
				"refresh" => false,
				"type" => "color"
				),
			'inverse_light' => array(
				"title" => esc_html__('Inverse light', 'save-life'),
				"desc" => wp_kses_data( __('Color of the info blocks inside block with accented background', 'save-life') ),
				"dependency" => array(
					'color_settings' => array('^simple')
				),
				"std" => '$save_life_get_scheme_color',
				"refresh" => false,
				"type" => "color"
				),
			'inverse_dark' => array(
				"title" => esc_html__('Inverse dark', 'save-life'),
				"desc" => wp_kses_data( __('Color of the headers inside block with accented background', 'save-life') ),
				"dependency" => array(
					'color_settings' => array('^simple')
				),
				"std" => '$save_life_get_scheme_color',
				"refresh" => false,
				"type" => "color"
				),
			'inverse_link' => array(
				"title" => esc_html__('Inverse link', 'save-life'),
				"desc" => wp_kses_data( __('Color of the links inside block with accented background', 'save-life') ),
				"dependency" => array(
					'color_settings' => array('^simple')
				),
				"std" => '$save_life_get_scheme_color',
				"refresh" => false,
				"type" => "color"
				),
			'inverse_hover' => array(
				"title" => esc_html__('Inverse hover', 'save-life'),
				"desc" => wp_kses_data( __('Color of the hovered links inside block with accented background', 'save-life') ),
				"dependency" => array(
					'color_settings' => array('^simple')
				),
				"std" => '$save_life_get_scheme_color',
				"refresh" => false,
				"type" => "color"
				),


			// Section 'Hidden'
			'media_title' => array(
				"title" => esc_html__('Media title', 'save-life'),
				"desc" => wp_kses_data( __('Used as title for the audio and video item in this post', 'save-life') ),
				"override" => array(
					'mode' => 'post',
					'section' => esc_html__('Title', 'save-life')
				),
				"hidden" => true,
				"std" => '',
				"type" => "text"
				),
			'media_author' => array(
				"title" => esc_html__('Media author', 'save-life'),
				"desc" => wp_kses_data( __('Used as author name for the audio and video item in this post', 'save-life') ),
				"override" => array(
					'mode' => 'post',
					'section' => esc_html__('Title', 'save-life')
				),
				"hidden" => true,
				"std" => '',
				"type" => "text"
				),


			// Internal options.
			// Attention! Don't change any options in the section below!
			'reset_options' => array(
				"title" => '',
				"desc" => '',
				"std" => '0',
				"type" => "hidden",
				),

		));


		// Prepare panel 'Fonts'
		$fonts = array(
		
			// Panel 'Fonts' - manage fonts loading and set parameters of the base theme elements
			'fonts' => array(
				"title" => esc_html__('* Fonts settings', 'save-life'),
				"desc" => '',
				"priority" => 1500,
				"type" => "panel"
				),

			// Section 'Load_fonts'
			'load_fonts' => array(
				"title" => esc_html__('Load fonts', 'save-life'),
				"desc" => wp_kses_data( __('Specify fonts to load when theme start. You can use them in the base theme elements: headers, text, menu, links, input fields, etc.', 'save-life') )
						. '<br>'
						. wp_kses_data( __('<b>Attention!</b> Press "Refresh" button to reload preview area after the all fonts are changed', 'save-life') ),
				"type" => "section"
				),
			'load_fonts_subset' => array(
				"title" => esc_html__('Google fonts subsets', 'save-life'),
				"desc" => wp_kses_data( __('Specify comma separated list of the subsets which will be load from Google fonts', 'save-life') )
						. '<br>'
						. wp_kses_data( __('Available subsets are: latin,latin-ext,cyrillic,cyrillic-ext,greek,greek-ext,vietnamese', 'save-life') ),
				"refresh" => false,
				"std" => '$save_life_get_load_fonts_subset',
				"type" => "text"
				)
		);

		for ($i=1; $i<=save_life_get_theme_setting('max_load_fonts'); $i++) {
			$fonts["load_fonts-{$i}-info"] = array(
				"title" => esc_html(sprintf(esc_html__('Font %s', 'save-life'), $i)),
				"desc" => '',
				"type" => "info",
				);
			$fonts["load_fonts-{$i}-name"] = array(
				"title" => esc_html__('Font name', 'save-life'),
				"desc" => '',
				"refresh" => false,
				"std" => '$save_life_get_load_fonts_option',
				"type" => "text"
				);
			$fonts["load_fonts-{$i}-family"] = array(
				"title" => esc_html__('Font family', 'save-life'),
				"desc" => $i==1 
							? wp_kses_data( __('Select font family to use it if font above is not available', 'save-life') )
							: '',
				"refresh" => false,
				"std" => '$save_life_get_load_fonts_option',
				"options" => array(
					'inherit' => esc_html__("Inherit", 'save-life'),
					'serif' => esc_html__('serif', 'save-life'),
					'sans-serif' => esc_html__('sans-serif', 'save-life'),
					'monospace' => esc_html__('monospace', 'save-life'),
					'cursive' => esc_html__('cursive', 'save-life'),
					'fantasy' => esc_html__('fantasy', 'save-life')
				),
				"type" => "select"
				);
			$fonts["load_fonts-{$i}-styles"] = array(
				"title" => esc_html__('Font styles', 'save-life'),
				"desc" => $i==1 
							? wp_kses_data( __('Font styles used only for the Google fonts. This is a comma separated list of the font weight and styles. For example: 400,400italic,700', 'save-life') )
											. '<br>'
								. wp_kses_data( __('<b>Attention!</b> Each weight and style increase download size! Specify only used weights and styles.', 'save-life') )
							: '',
				"refresh" => false,
				"std" => '$save_life_get_load_fonts_option',
				"type" => "text"
				);
		}
		$fonts['load_fonts_end'] = array(
			"type" => "section_end"
			);

		// Sections with font's attributes for each theme element
		$theme_fonts = save_life_get_theme_fonts();
		foreach ($theme_fonts as $tag=>$v) {
			$fonts["{$tag}_section"] = array(
				"title" => !empty($v['title']) 
								? $v['title'] 
								: esc_html(sprintf(esc_html__('%s settings', 'save-life'), $tag)),
				"desc" => !empty($v['description']) 
								? $v['description'] 
								: wp_kses_post( sprintf(esc_html__('Font settings of the "%s" tag.', 'save-life'), $tag) ),
				"type" => "section",
				);
	
			foreach ($v as $css_prop=>$css_value) {
				if (in_array($css_prop, array('title', 'description'))) continue;
				$options = '';
				$type = 'text';
				$title = ucfirst(str_replace('-', ' ', $css_prop));
				if ($css_prop == 'font-family') {
					$type = 'select';
					$options = save_life_get_list_load_fonts(true);
				} else if ($css_prop == 'font-weight') {
					$type = 'select';
					$options = array(
						'inherit' => esc_html__("Inherit", 'save-life'),
						'100' => esc_html__('100 (Light)', 'save-life'), 
						'200' => esc_html__('200 (Light)', 'save-life'), 
						'300' => esc_html__('300 (Thin)',  'save-life'),
						'400' => esc_html__('400 (Normal)', 'save-life'),
						'500' => esc_html__('500 (Semibold)', 'save-life'),
						'600' => esc_html__('600 (Semibold)', 'save-life'),
						'700' => esc_html__('700 (Bold)', 'save-life'),
						'800' => esc_html__('800 (Black)', 'save-life'),
						'900' => esc_html__('900 (Black)', 'save-life')
					);
				} else if ($css_prop == 'font-style') {
					$type = 'select';
					$options = array(
						'inherit' => esc_html__("Inherit", 'save-life'),
						'normal' => esc_html__('Normal', 'save-life'), 
						'italic' => esc_html__('Italic', 'save-life')
					);
				} else if ($css_prop == 'text-decoration') {
					$type = 'select';
					$options = array(
						'inherit' => esc_html__("Inherit", 'save-life'),
						'none' => esc_html__('None', 'save-life'), 
						'underline' => esc_html__('Underline', 'save-life'),
						'overline' => esc_html__('Overline', 'save-life'),
						'line-through' => esc_html__('Line-through', 'save-life')
					);
				} else if ($css_prop == 'text-transform') {
					$type = 'select';
					$options = array(
						'inherit' => esc_html__("Inherit", 'save-life'),
						'none' => esc_html__('None', 'save-life'), 
						'uppercase' => esc_html__('Uppercase', 'save-life'),
						'lowercase' => esc_html__('Lowercase', 'save-life'),
						'capitalize' => esc_html__('Capitalize', 'save-life')
					);
				}
				$fonts["{$tag}_{$css_prop}"] = array(
					"title" => $title,
					"desc" => '',
					"refresh" => false,
					"std" => '$save_life_get_theme_fonts_option',
					"options" => $options,
					"type" => $type
				);
			}
			
			$fonts["{$tag}_section_end"] = array(
				"type" => "section_end"
				);
		}

		$fonts['fonts_end'] = array(
			"type" => "panel_end"
			);

		// Add fonts parameters into Theme Options
		save_life_storage_merge_array('options', '', $fonts);

		// Add Header Video if WP version < 4.7
		if (!function_exists('get_header_video_url')) {
			save_life_storage_set_array_after('options', 'header_image_override', 'header_video', array(
				"title" => esc_html__('Header video', 'save-life'),
				"desc" => wp_kses_data( __("Select video to use it as background for the header", 'save-life') ),
				"override" => array(
					'mode' => 'page',
					'section' => esc_html__('Header', 'save-life')
				),
				"std" => '',
				"type" => "video"
				)
			);
		}
	}
}




// -----------------------------------------------------------------
// -- Create and manage Theme Options
// -----------------------------------------------------------------

// Theme init priorities:
// 2 - create Theme Options
if (!function_exists('save_life_options_theme_setup2')) {
	add_action( 'after_setup_theme', 'save_life_options_theme_setup2', 2 );
	function save_life_options_theme_setup2() {
		save_life_options_create();
	}
}

// Step 1: Load default settings and previously saved mods
if (!function_exists('save_life_options_theme_setup5')) {
	add_action( 'after_setup_theme', 'save_life_options_theme_setup5', 5 );
	function save_life_options_theme_setup5() {
		save_life_storage_set('options_reloaded', false);
		save_life_load_theme_options();
	}
}

// Step 2: Load current theme customization mods
if (is_customize_preview()) {
	if (!function_exists('save_life_load_custom_options')) {
		add_action( 'wp_loaded', 'save_life_load_custom_options' );
		function save_life_load_custom_options() {
			if (!save_life_storage_get('options_reloaded')) {
				save_life_storage_set('options_reloaded', true);
				save_life_load_theme_options();
			}
		}
	}
}

// Load current values for each customizable option
if ( !function_exists('save_life_load_theme_options') ) {
	function save_life_load_theme_options() {
		$options = save_life_storage_get('options');
		$reset = (int) get_theme_mod('reset_options', 0);
		foreach ($options as $k=>$v) {
			if (isset($v['std'])) {
				if (strpos($v['std'], '$save_life_')!==false) {
					$func = substr($v['std'], 1);
					if (function_exists($func)) {
						$v['std'] = $func($k);
					}
				}
				$value = $v['std'];
				if (!$reset) {
					if (isset($_GET[$k]))
						$value = $_GET[$k];
					else {
						$tmp = get_theme_mod($k, -987654321);
						if ($tmp != -987654321) $value = $tmp;
					}
				}
				save_life_storage_set_array2('options', $k, 'val', $value);
				if ($reset) remove_theme_mod($k);
			}
		}
		if ($reset) {
			// Unset reset flag
			set_theme_mod('reset_options', 0);
			// Regenerate CSS with default colors and fonts
			save_life_customizer_save_css();
		} else {
			do_action('save_life_action_load_options');
		}
	}
}

// Override options with stored page/post meta
if ( !function_exists('save_life_override_theme_options') ) {
	add_action( 'wp', 'save_life_override_theme_options', 1 );
	function save_life_override_theme_options($query=null) {
		if (is_page_template('blog.php')) {
			save_life_storage_set('blog_archive', true);
			save_life_storage_set('blog_template', get_the_ID());
		}
		save_life_storage_set('blog_mode', save_life_detect_blog_mode());
		if (is_singular()) {
			save_life_storage_set('options_meta', get_post_meta(get_the_ID(), 'save_life_options', true));
		}
	}
}


// Return customizable option value
if (!function_exists('save_life_get_theme_option')) {
	function save_life_get_theme_option($name, $defa='', $strict_mode=false, $post_id=0) {
		$rez = $defa;
		$from_post_meta = false;
		if ($post_id > 0) {
			if (!save_life_storage_isset('post_options_meta', $post_id))
				save_life_storage_set_array('post_options_meta', $post_id, get_post_meta($post_id, 'save_life_options', true));
			if (save_life_storage_isset('post_options_meta', $post_id, $name)) {
				$tmp = save_life_storage_get_array('post_options_meta', $post_id, $name);
				if (!save_life_is_inherit($tmp)) {
					$rez = $tmp;
					$from_post_meta = true;
				}
			}
		}
		if (!$from_post_meta && save_life_storage_isset('options')) {
			if ( !save_life_storage_isset('options', $name) ) {
				$rez = $tmp = '_not_exists_';
				if (function_exists('trx_addons_get_option'))
					$rez = trx_addons_get_option($name, $tmp, false);
				if ($rez === $tmp) {
					if ($strict_mode) {
						$s = debug_backtrace();
						//array_shift($s);
						$s = array_shift($s);
						echo '<pre>' . sprintf(esc_html__('Undefined option "%s" called from:', 'save-life'), $name);
						if (function_exists('dco')) dco($s);
						else print_r($s);
						echo '</pre>';
                        wp_die();
					} else
						$rez = $defa;
				}
			} else {
				$blog_mode = save_life_storage_get('blog_mode');
				// Override option from GET or POST for current blog mode
				if (!empty($blog_mode) && isset($_REQUEST[$name . '_' . $blog_mode])) {
					$rez = $_REQUEST[$name . '_' . $blog_mode];
				// Override option from GET
				} else if (isset($_REQUEST[$name])) {
					$rez = $_REQUEST[$name];
				// Override option from current page settings (if exists)
				} else if (save_life_storage_isset('options_meta', $name) && !save_life_is_inherit(save_life_storage_get_array('options_meta', $name))) {
					$rez = save_life_storage_get_array('options_meta', $name);
				// Override option from current blog mode settings: 'home', 'search', 'page', 'post', 'blog', etc. (if exists)
				} else if (!empty($blog_mode) && save_life_storage_isset('options', $name . '_' . $blog_mode, 'val') && !save_life_is_inherit(save_life_storage_get_array('options', $name . '_' . $blog_mode, 'val'))) {
					$rez = save_life_storage_get_array('options', $name . '_' . $blog_mode, 'val');
				// Get saved option value
				} else if (save_life_storage_isset('options', $name, 'val')) {
					$rez = save_life_storage_get_array('options', $name, 'val');
				// Get ThemeREX Addons option value
				} else if (function_exists('trx_addons_get_option')) {
					$rez = trx_addons_get_option($name, $defa, false);
				}
			}
		}
		return $rez;
	}
}


// Check if customizable option exists
if (!function_exists('save_life_check_theme_option')) {
	function save_life_check_theme_option($name) {
		return save_life_storage_isset('options', $name);
	}
}

// Get dependencies list from the Theme Options
if ( !function_exists('save_life_get_theme_dependencies') ) {
	function save_life_get_theme_dependencies() {
		$options = save_life_storage_get('options');
		$depends = array();
		foreach ($options as $k=>$v) {
			if (isset($v['dependency'])) 
				$depends[$k] = $v['dependency'];
		}
		return $depends;
	}
}

// Return internal theme setting value
if (!function_exists('save_life_get_theme_setting')) {
	function save_life_get_theme_setting($name) {
		return save_life_storage_isset('settings', $name) ? save_life_storage_get_array('settings', $name) : false;
	}
}


// Set theme setting
if ( !function_exists( 'save_life_set_theme_setting' ) ) {
	function save_life_set_theme_setting($option_name, $value) {
		if (save_life_storage_isset('settings', $option_name))
			save_life_storage_set_array('settings', $option_name, $value);
	}
}
?>