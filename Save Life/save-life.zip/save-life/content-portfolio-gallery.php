<?php
/**
 * The Gallery template to display posts
 *
 * Used for index/archive/search.
 *
 * @package WordPress
 * @subpackage SAVE_LIFE
 * @since SAVE_LIFE 1.0
 */

$save_life_blog_style = explode('_', save_life_get_theme_option('blog_style'));
$save_life_columns = empty($save_life_blog_style[1]) ? 2 : max(2, $save_life_blog_style[1]);
$save_life_post_format = get_post_format();
$save_life_post_format = empty($save_life_post_format) ? 'standard' : str_replace('post-format-', '', $save_life_post_format);
$save_life_animation = save_life_get_theme_option('blog_animation');
$save_life_image = wp_get_attachment_image_src( get_post_thumbnail_id(get_the_ID()), 'full' );

?><article id="post-<?php the_ID(); ?>" 
	<?php post_class( 'post_item post_layout_portfolio post_layout_gallery post_layout_gallery_'.esc_attr($save_life_columns).' post_format_'.esc_attr($save_life_post_format) ); ?>
	<?php echo (!save_life_is_off($save_life_animation) ? ' data-animation="'.esc_attr(save_life_get_animation_classes($save_life_animation)).'"' : ''); ?>
	data-size="<?php if (!empty($save_life_image[1]) && !empty($save_life_image[2])) echo intval($save_life_image[1]) .'x' . intval($save_life_image[2]); ?>"
	data-src="<?php if (!empty($save_life_image[0])) echo esc_url($save_life_image[0]); ?>"
	>

	<?php
	$save_life_image_hover = 'icon';	//save_life_get_theme_option('image_hover');
	if (in_array($save_life_image_hover, array('icons', 'zoom'))) $save_life_image_hover = 'dots';
	// Featured image
	save_life_show_post_featured(array(
		'hover' => $save_life_image_hover,
		'thumb_size' => save_life_get_thumb_size( strpos(save_life_get_theme_option('body_style'), 'full')!==false || $save_life_columns < 3 ? 'masonry-big' : 'masonry' ),
		'thumb_only' => true,
		'show_no_image' => true,
		'post_info' => '<div class="post_details">'
							. '<h2 class="post_title"><a href="'.esc_url(get_permalink()).'">'. esc_html(get_the_title()) . '</a></h2>'
							. '<div class="post_description">'
								. save_life_show_post_meta(array(
									'categories' => true,
									'date' => true,
									'edit' => false,
									'seo' => false,
									'share' => true,
									'counters' => 'comments',
									'echo' => false
									))
								. '<div class="post_description_content">'
									. apply_filters('the_excerpt', get_the_excerpt())
								. '</div>'
								. '<a href="'.esc_url(get_permalink()).'" class="theme_button post_readmore"><span class="post_readmore_label">' . esc_html__('Learn more', 'save-life') . '</span></a>'
							. '</div>'
						. '</div>'
	));
	?>
</article>