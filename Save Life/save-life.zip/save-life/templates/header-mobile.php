<?php
/**
 * The template to show mobile menu
 *
 * @package WordPress
 * @subpackage SAVE_LIFE
 * @since SAVE_LIFE 1.0
 */
?>
<div class="menu_mobile_overlay"></div>
<div class="menu_mobile menu_mobile_<?php echo esc_attr(save_life_get_theme_option('menu_mobile_fullscreen') > 0 ? 'fullscreen' : 'narrow'); ?> scheme_dark">
	<div class="menu_mobile_inner">
		<a class="menu_mobile_close icon-cancel"></a><?php

		// Logo
		set_query_var('save_life_logo_args', array('type' => 'inverse'));
		get_template_part( 'templates/header-logo' );
		set_query_var('save_life_logo_args', array());

		// Mobile menu
		$save_life_menu_mobile = save_life_get_nav_menu('menu_mobile');
		if (empty($save_life_menu_mobile)) {
			$save_life_menu_mobile = apply_filters('save_life_filter_get_mobile_menu', '');
			if (empty($save_life_menu_mobile)) $save_life_menu_mobile = save_life_get_nav_menu('menu_main');
			if (empty($save_life_menu_mobile)) $save_life_menu_mobile = save_life_get_nav_menu();
		}
		if (!empty($save_life_menu_mobile)) {
			if (!empty($save_life_menu_mobile))
				$save_life_menu_mobile = str_replace(
					array('menu_main', 'id="menu-', 'sc_layouts_menu_nav', 'sc_layouts_hide_on_mobile', 'hide_on_mobile'),
					array('menu_mobile', 'id="menu_mobile-', '', '', ''),
					$save_life_menu_mobile
					);
			if (strpos($save_life_menu_mobile, '<nav ')===false)
				$save_life_menu_mobile = sprintf('<nav class="menu_mobile_nav_area">%s</nav>', $save_life_menu_mobile);
			save_life_show_layout(apply_filters('save_life_filter_menu_mobile_layout', $save_life_menu_mobile));
		}

		// Social icons
		save_life_show_layout(save_life_get_socials_links(), '<div class="socials_mobile">', '</div>');
		?>
	</div>
</div>
