<?php
/**
 * The template to display the socials in the footer
 *
 * @package WordPress
 * @subpackage SAVE_LIFE
 * @since SAVE_LIFE 1.0.10
 */


// Socials
if ( save_life_is_on(save_life_get_theme_option('socials_in_footer')) && ($save_life_output = save_life_get_socials_links()) != '') {
	?>
	<div class="footer_socials_wrap socials_wrap">
		<div class="footer_socials_inner">
			<?php save_life_show_layout($save_life_output); ?>
		</div>
	</div>
	<?php
}
?>