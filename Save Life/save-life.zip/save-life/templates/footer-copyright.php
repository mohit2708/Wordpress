<?php
/**
 * The template to display the copyright info in the footer
 *
 * @package WordPress
 * @subpackage SAVE_LIFE
 * @since SAVE_LIFE 1.0.10
 */

// Copyright area
$save_life_footer_scheme =  save_life_is_inherit(save_life_get_theme_option('footer_scheme')) ? save_life_get_theme_option('color_scheme') : save_life_get_theme_option('footer_scheme');
$save_life_copyright_scheme = save_life_is_inherit(save_life_get_theme_option('copyright_scheme')) ? $save_life_footer_scheme : save_life_get_theme_option('copyright_scheme');
?> 
<div class="footer_copyright_wrap scheme_<?php echo esc_attr($save_life_copyright_scheme); ?>">
	<div class="footer_copyright_inner">
		<div class="content_wrap">
			<div class="copyright_text"><?php
				// Replace {{...}} and [[...]] on the <i>...</i> and <b>...</b>
				$save_life_copyright = save_life_prepare_macros(save_life_get_theme_option('copyright'));
				if (!empty($save_life_copyright)) {
					// Replace {date_format} on the current date in the specified format
					if (preg_match("/(\\{[\\w\\d\\\\\\-\\:]*\\})/", $save_life_copyright, $save_life_matches)) {
						$save_life_copyright = str_replace($save_life_matches[1], date(str_replace(array('{', '}'), '', $save_life_matches[1])), $save_life_copyright);
					}
					// Display copyright
					echo wp_kses_data(nl2br($save_life_copyright));
				}
			?></div>
		</div>
	</div>
</div>
