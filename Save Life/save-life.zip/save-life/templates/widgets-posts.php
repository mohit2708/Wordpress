<?php
/**
 * The template to display posts in widgets and/or in the search results
 *
 * @package WordPress
 * @subpackage SAVE_LIFE
 * @since SAVE_LIFE 1.0
 */

$save_life_post_id    = get_the_ID();
$save_life_post_date  = save_life_get_date();
$save_life_post_title = get_the_title();
$save_life_post_link  = get_permalink();
$save_life_post_author_id   = get_the_author_meta('ID');
$save_life_post_author_name = get_the_author_meta('display_name');
$save_life_post_author_url  = get_author_posts_url($save_life_post_author_id, '');

$save_life_args = get_query_var('save_life_args_widgets_posts');
$save_life_show_date = isset($save_life_args['show_date']) ? (int) $save_life_args['show_date'] : 1;
$save_life_show_image = isset($save_life_args['show_image']) ? (int) $save_life_args['show_image'] : 1;
$save_life_show_author = isset($save_life_args['show_author']) ? (int) $save_life_args['show_author'] : 1;
$save_life_show_counters = isset($save_life_args['show_counters']) ? (int) $save_life_args['show_counters'] : 1;
$save_life_show_categories = isset($save_life_args['show_categories']) ? (int) $save_life_args['show_categories'] : 1;

$save_life_output = save_life_storage_get('save_life_output_widgets_posts');

$save_life_post_counters_output = '';
if ( $save_life_show_counters ) {
	$save_life_post_counters_output = '<span class="post_info_item post_info_counters">'
								. save_life_get_post_counters('comments')
							. '</span>';
}


$save_life_output .= '<article class="post_item with_thumb">';

if ($save_life_show_image) {
	$save_life_post_thumb = get_the_post_thumbnail($save_life_post_id, save_life_get_thumb_size('tiny'), array(
		'alt' => get_the_title()
	));
	if ($save_life_post_thumb) $save_life_output .= '<div class="post_thumb">' . ($save_life_post_link ? '<a href="' . esc_url($save_life_post_link) . '">' : '') . ($save_life_post_thumb) . ($save_life_post_link ? '</a>' : '') . '</div>';
}

$save_life_output .= '<div class="post_content">'
			. ($save_life_show_categories 
					? '<div class="post_categories">'
						. save_life_get_post_categories()
						. $save_life_post_counters_output
						. '</div>' 
					: '')
			. '<h6 class="post_title">' . ($save_life_post_link ? '<a href="' . esc_url($save_life_post_link) . '">' : '') . ($save_life_post_title) . ($save_life_post_link ? '</a>' : '') . '</h6>'
			. apply_filters('save_life_filter_get_post_info', 
								'<div class="post_info">'
									. ($save_life_show_date 
										? '<span class="post_info_item post_info_posted">'
											. ($save_life_post_link ? '<a href="' . esc_url($save_life_post_link) . '" class="post_info_date">' : '') 
											. esc_html($save_life_post_date) 
											. ($save_life_post_link ? '</a>' : '')
											. '</span>'
										: '')
									. ($save_life_show_author 
										? '<span class="post_info_item post_info_posted_by">' 
											. esc_html__('by', 'save-life') . ' ' 
											. ($save_life_post_link ? '<a href="' . esc_url($save_life_post_author_url) . '" class="post_info_author">' : '') 
											. esc_html($save_life_post_author_name) 
											. ($save_life_post_link ? '</a>' : '') 
											. '</span>'
										: '')
									. (!$save_life_show_categories && $save_life_post_counters_output
										? $save_life_post_counters_output
										: '')
								. '</div>')
		. '</div>'
	. '</article>';
save_life_storage_set('save_life_output_widgets_posts', $save_life_output);
?>