<?php
/**
 * The template to display the widgets area in the footer
 *
 * @package WordPress
 * @subpackage SAVE_LIFE
 * @since SAVE_LIFE 1.0.10
 */

// Footer sidebar
$save_life_footer_name = save_life_get_theme_option('footer_widgets');
$save_life_footer_present = !save_life_is_off($save_life_footer_name) && is_active_sidebar($save_life_footer_name);
if ($save_life_footer_present) { 
	save_life_storage_set('current_sidebar', 'footer');
	$save_life_footer_wide = save_life_get_theme_option('footer_wide');
	ob_start();
	if ( !dynamic_sidebar($save_life_footer_name) ) {
		// Put here html if user no set widgets in sidebar
	}
	$save_life_out = trim(ob_get_contents());
	ob_end_clean();
	if (trim(strip_tags($save_life_out)) != '') {
		$save_life_out = preg_replace("/<\\/aside>[\r\n\s]*<aside/", "</aside><aside", $save_life_out);
		$save_life_need_columns = true;	//or check: strpos($save_life_out, 'columns_wrap')===false;
		if ($save_life_need_columns) {
			$save_life_columns = max(0, (int) save_life_get_theme_option('footer_columns'));
			if ($save_life_columns == 0) $save_life_columns = min(6, max(1, substr_count($save_life_out, '<aside ')));
			if ($save_life_columns > 1)
				$save_life_out = preg_replace("/class=\"widget /", "class=\"column-1_".esc_attr($save_life_columns).' widget ', $save_life_out);
			else
				$save_life_need_columns = false;
		}
		?>
		<div class="footer_widgets_wrap widget_area<?php echo !empty($save_life_footer_wide) ? ' footer_fullwidth' : ''; ?>">
			<div class="footer_widgets_inner widget_area_inner">
				<?php 
				if (!$save_life_footer_wide) { 
					?><div class="content_wrap"><?php
				}
				if ($save_life_need_columns) {
					?><div class="columns_wrap"><?php
				}
				do_action( 'save_life_action_before_sidebar' );
				save_life_show_layout($save_life_out);
				do_action( 'save_life_action_after_sidebar' );
				if ($save_life_need_columns) {
					?></div><!-- /.columns_wrap --><?php
				}
				if (!$save_life_footer_wide) {
					?></div><!-- /.content_wrap --><?php
				}
				?>
			</div><!-- /.footer_widgets_inner -->
		</div><!-- /.footer_widgets_wrap -->
		<?php
	}
}
?>