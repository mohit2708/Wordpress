<?php
/**
 * The template to display the widgets area in the header
 *
 * @package WordPress
 * @subpackage SAVE_LIFE
 * @since SAVE_LIFE 1.0
 */

// Header sidebar
$save_life_header_name = save_life_get_theme_option('header_widgets');
$save_life_header_present = !save_life_is_off($save_life_header_name) && is_active_sidebar($save_life_header_name);
if ($save_life_header_present) { 
	save_life_storage_set('current_sidebar', 'header');
	$save_life_header_wide = save_life_get_theme_option('header_wide');
	ob_start();
	if ( !dynamic_sidebar($save_life_header_name) ) {
		// Put here html if user no set widgets in sidebar
	}
	$save_life_widgets_output = ob_get_contents();
	ob_end_clean();
	if (trim(strip_tags($save_life_widgets_output)) != '') {
		$save_life_widgets_output = preg_replace("/<\/aside>[\r\n\s]*<aside/", "</aside><aside", $save_life_widgets_output);
		$save_life_need_columns = strpos($save_life_widgets_output, 'columns_wrap')===false;
		if ($save_life_need_columns) {
			$save_life_columns = max(0, (int) save_life_get_theme_option('header_columns'));
			if ($save_life_columns == 0) $save_life_columns = min(6, max(1, substr_count($save_life_widgets_output, '<aside ')));
			if ($save_life_columns > 1)
				$save_life_widgets_output = preg_replace("/class=\"widget /", "class=\"column-1_".esc_attr($save_life_columns).' widget ', $save_life_widgets_output);
			else
				$save_life_need_columns = false;
		}
		?>
		<div class="header_widgets_wrap widget_area<?php echo !empty($save_life_header_wide) ? ' header_fullwidth' : ' header_boxed'; ?>">
			<div class="header_widgets_inner widget_area_inner">
				<?php 
				if (!$save_life_header_wide) { 
					?><div class="content_wrap"><?php
				}
				if ($save_life_need_columns) {
					?><div class="columns_wrap"><?php
				}
				do_action( 'save_life_action_before_sidebar' );
				save_life_show_layout($save_life_widgets_output);
				do_action( 'save_life_action_after_sidebar' );
				if ($save_life_need_columns) {
					?></div>	<!-- /.columns_wrap --><?php
				}
				if (!$save_life_header_wide) {
					?></div>	<!-- /.content_wrap --><?php
				}
				?>
			</div>	<!-- /.header_widgets_inner -->
		</div>	<!-- /.header_widgets_wrap -->
		<?php
	}
}
?>