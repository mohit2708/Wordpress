<?php
/**
 * The template to display the logo or the site name and the slogan in the Header
 *
 * @package WordPress
 * @subpackage SAVE_LIFE
 * @since SAVE_LIFE 1.0
 */

$save_life_args = get_query_var('save_life_logo_args');

// Site logo
$save_life_logo_image  = save_life_get_logo_image(isset($save_life_args['type']) ? $save_life_args['type'] : '');
$save_life_logo_text   = save_life_is_on(save_life_get_theme_option('logo_text')) ? get_bloginfo( 'name' ) : '';
$save_life_logo_slogan = get_bloginfo( 'description', 'display' );
if (!empty($save_life_logo_image) || !empty($save_life_logo_text)) {
	?><a class="sc_layouts_logo" href="<?php echo is_front_page() ? '#' : esc_url(home_url('/')); ?>"><?php
		if (!empty($save_life_logo_image)) {
			$save_life_attr = save_life_getimagesize($save_life_logo_image);
			echo '<img src="'.esc_url($save_life_logo_image).'" alt="'.esc_html(basename($save_life_logo_image)).'"'.(!empty($save_life_attr[3]) ? sprintf(' %s', $save_life_attr[3]) : '').'>' ;
		} else {
			save_life_show_layout(save_life_prepare_macros($save_life_logo_text), '<span class="logo_text">', '</span>');
			save_life_show_layout(save_life_prepare_macros($save_life_logo_slogan), '<span class="logo_slogan">', '</span>');
		}
	?></a><?php
}
?>