<?php
/**
 * The template to displaying popup with Theme Icons
 *
 * @package WordPress
 * @subpackage SAVE_LIFE
 * @since SAVE_LIFE 1.0
 */

$save_life_icons = save_life_get_list_icons();
if (is_array($save_life_icons)) {
	?>
	<div class="save_life_list_icons">
		<?php
		foreach($save_life_icons as $icon) {
			?><span class="<?php echo esc_attr($icon); ?>" title="<?php echo esc_attr($icon); ?>"></span><?php
		}
		?>
	</div>
	<?php
}
?>