<?php
/**
 * The template to display custom header from the ThemeREX Addons Layouts
 *
 * @package WordPress
 * @subpackage SAVE_LIFE
 * @since SAVE_LIFE 1.0.06
 */

$save_life_header_css = $save_life_header_image = '';
$save_life_header_video = save_life_get_header_video();
if (true || empty($save_life_header_video)) {
	$save_life_header_image = get_header_image();
	if (save_life_is_on(save_life_get_theme_option('header_image_override')) && apply_filters('save_life_filter_allow_override_header_image', true)) {
		if (is_category()) {
			if (($save_life_cat_img = save_life_get_category_image()) != '')
				$save_life_header_image = $save_life_cat_img;
		} else if (is_singular() || save_life_storage_isset('blog_archive')) {
			if (has_post_thumbnail()) {
				$save_life_header_image = wp_get_attachment_image_src( get_post_thumbnail_id(), 'full' );
				if (is_array($save_life_header_image)) $save_life_header_image = $save_life_header_image[0];
			} else
				$save_life_header_image = '';
		}
	}
}

$save_life_header_id = str_replace('header-custom-', '', save_life_get_theme_option("header_style"));

?><header class="top_panel top_panel_custom top_panel_custom_<?php echo esc_attr($save_life_header_id);
						echo !empty($save_life_header_image) || !empty($save_life_header_video) ? ' with_bg_image' : ' without_bg_image';
						if ($save_life_header_video!='') echo ' with_bg_video';
						if ($save_life_header_image!='') echo ' '.esc_attr(save_life_add_inline_style('background-image: url('.esc_url($save_life_header_image).');'));
						if (is_single() && has_post_thumbnail()) echo ' with_featured_image';
						if (save_life_is_on(save_life_get_theme_option('header_fullheight'))) echo ' header_fullheight trx-stretch-height';
						?> scheme_<?php echo esc_attr(save_life_is_inherit(save_life_get_theme_option('header_scheme')) 
														? save_life_get_theme_option('color_scheme') 
														: save_life_get_theme_option('header_scheme'));
						?>"><?php

	// Background video
	if (!empty($save_life_header_video)) {
		get_template_part( 'templates/header-video' );
	}
		
	// Custom header's layout
	do_action('save_life_action_show_layout', $save_life_header_id);

	// Header widgets area
	get_template_part( 'templates/header-widgets' );

		
?></header>