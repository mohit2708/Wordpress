<?php
/**
 * The template to display the page title and breadcrumbs
 *
 * @package WordPress
 * @subpackage SAVE_LIFE
 * @since SAVE_LIFE 1.0
 */

// Page (category, tag, archive, author) title
if ( save_life_need_page_title() ) {
	save_life_sc_layouts_showed('title', true);
	?>
	<div class="top_panel_title sc_layouts_row sc_layouts_row_type_normal">

		<div class="sc_layouts_breadcrumbs">
			<div class="content_wrap"><?php
				// Breadcrumbs
				?><div class="sc_layouts_title_breadcrumbs"><?php
					do_action( 'save_life_action_breadcrumbs');
					?></div>
			</div>
		</div>

		<div class="sc_layouts_title">
			<div class="content_wrap">
			<?php
			// Post meta on the single post
			if ( is_single() )  {
				?><div class="sc_layouts_title_meta"><?php
					save_life_show_post_meta(array(
						'date' => true,
						'categories' => true,
						'seo' => true,
						'share' => false,
						'counters' => 'views,comments,likes'
						)
					);
				?></div><?php
			}

			// Blog/Post title
			?><div class="sc_layouts_title_title"><?php
				$save_life_blog_title = save_life_get_blog_title();
				$save_life_blog_title_text = $save_life_blog_title_class = $save_life_blog_title_link = $save_life_blog_title_link_text = '';
				if (is_array($save_life_blog_title)) {
					$save_life_blog_title_text = $save_life_blog_title['text'];
					$save_life_blog_title_class = !empty($save_life_blog_title['class']) ? ' '.$save_life_blog_title['class'] : '';
					$save_life_blog_title_link = !empty($save_life_blog_title['link']) ? $save_life_blog_title['link'] : '';
					$save_life_blog_title_link_text = !empty($save_life_blog_title['link_text']) ? $save_life_blog_title['link_text'] : '';
				} else
					$save_life_blog_title_text = $save_life_blog_title;
				?>
				<h1 class="sc_layouts_title_caption<?php echo esc_attr($save_life_blog_title_class); ?>"><?php
					$save_life_top_icon = save_life_get_category_icon();
					if (!empty($save_life_top_icon)) {
						$save_life_attr = save_life_getimagesize($save_life_top_icon);
						?><img src="<?php echo esc_url($save_life_top_icon); ?>" alt="<?php echo esc_html(basename($save_life_top_icon)); ?>" <?php if (!empty($save_life_attr[3])) save_life_show_layout($save_life_attr[3]);?>><?php
					}
					echo wp_kses_data($save_life_blog_title_text);
				?></h1>
				<?php
				if (!empty($save_life_blog_title_link) && !empty($save_life_blog_title_link_text)) {
					?><a href="<?php echo esc_url($save_life_blog_title_link); ?>" class="theme_button theme_button_small sc_layouts_title_link"><?php echo esc_html($save_life_blog_title_link_text); ?></a><?php
				}

				// Category/Tag description
				if ( is_category() || is_tag() || is_tax() )
					the_archive_description( '<div class="sc_layouts_title_description">', '</div>' );

			?></div></div>
		</div>

	</div>
	<?php
}
?>