<?php
/**
 * The template to display the background video in the header
 *
 * @package WordPress
 * @subpackage SAVE_LIFE
 * @since SAVE_LIFE 1.0.14
 */
$save_life_header_video = save_life_get_header_video();
if (!empty($save_life_header_video) && !save_life_is_from_uploads($save_life_header_video)) {
	global $wp_embed;
	if (is_object($wp_embed))
		$save_life_embed_video = do_shortcode($wp_embed->run_shortcode( '[embed]' . trim($save_life_header_video) . '[/embed]' ));
	$save_life_embed_video = save_life_make_video_autoplay($save_life_embed_video);
	?><div id="background_video"><?php save_life_show_layout($save_life_embed_video); ?></div><?php
}
?>