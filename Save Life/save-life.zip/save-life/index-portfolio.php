<?php
/**
 * The template for homepage posts with "Portfolio" style
 *
 * @package WordPress
 * @subpackage SAVE_LIFE
 * @since SAVE_LIFE 1.0
 */

save_life_storage_set('blog_archive', true);

// Load scripts for both 'Gallery' and 'Portfolio' layouts!
save_life_load_portfolio_scripts();

get_header(); 

if (have_posts()) {

	echo get_query_var('blog_archive_start');

	$save_life_stickies = is_home() ? get_option( 'sticky_posts' ) : false;
	$save_life_sticky_out = is_array($save_life_stickies) && count($save_life_stickies) > 0 && get_query_var( 'paged' ) < 1;
	
	// Show filters
	$save_life_cat = save_life_get_theme_option('parent_cat');
	$save_life_post_type = save_life_get_theme_option('post_type');
	$save_life_taxonomy = save_life_get_post_type_taxonomy($save_life_post_type);
	$save_life_show_filters = save_life_get_theme_option('show_filters');
	$save_life_tabs = array();
	if (!save_life_is_off($save_life_show_filters)) {
		$save_life_args = array(
			'type'			=> $save_life_post_type,
			'child_of'		=> $save_life_cat,
			'orderby'		=> 'name',
			'order'			=> 'ASC',
			'hide_empty'	=> 1,
			'hierarchical'	=> 0,
			'exclude'		=> '',
			'include'		=> '',
			'number'		=> '',
			'taxonomy'		=> $save_life_taxonomy,
			'pad_counts'	=> false
		);
		$save_life_portfolio_list = get_terms($save_life_args);
		if (is_array($save_life_portfolio_list) && count($save_life_portfolio_list) > 0) {
			$save_life_tabs[$save_life_cat] = esc_html__('All', 'save-life');
			foreach ($save_life_portfolio_list as $save_life_term) {
				if (isset($save_life_term->term_id)) $save_life_tabs[$save_life_term->term_id] = $save_life_term->name;
			}
		}
	}
	if (count($save_life_tabs) > 0) {
		$save_life_portfolio_filters_ajax = true;
		$save_life_portfolio_filters_active = $save_life_cat;
		$save_life_portfolio_filters_id = 'portfolio_filters';
		if (!is_customize_preview())
			wp_enqueue_script('jquery-ui-tabs', false, array('jquery', 'jquery-ui-core'), null, true);
		?>
		<div class="portfolio_filters save_life_tabs save_life_tabs_ajax">
			<ul class="portfolio_titles save_life_tabs_titles">
				<?php
				foreach ($save_life_tabs as $save_life_id=>$save_life_title) {
					?><li><a href="<?php echo esc_url(save_life_get_hash_link(sprintf('#%s_%s_content', $save_life_portfolio_filters_id, $save_life_id))); ?>" data-tab="<?php echo esc_attr($save_life_id); ?>"><?php echo esc_html($save_life_title); ?></a></li><?php
				}
				?>
			</ul>
			<?php
			$save_life_ppp = save_life_get_theme_option('posts_per_page');
			if (save_life_is_inherit($save_life_ppp)) $save_life_ppp = '';
			foreach ($save_life_tabs as $save_life_id=>$save_life_title) {
				$save_life_portfolio_need_content = $save_life_id==$save_life_portfolio_filters_active || !$save_life_portfolio_filters_ajax;
				?>
				<div id="<?php echo esc_attr(sprintf('%s_%s_content', $save_life_portfolio_filters_id, $save_life_id)); ?>"
					class="portfolio_content save_life_tabs_content"
					data-blog-template="<?php echo esc_attr(save_life_storage_get('blog_template')); ?>"
					data-blog-style="<?php echo esc_attr(save_life_get_theme_option('blog_style')); ?>"
					data-posts-per-page="<?php echo esc_attr($save_life_ppp); ?>"
					data-post-type="<?php echo esc_attr($save_life_post_type); ?>"
					data-taxonomy="<?php echo esc_attr($save_life_taxonomy); ?>"
					data-cat="<?php echo esc_attr($save_life_id); ?>"
					data-parent-cat="<?php echo esc_attr($save_life_cat); ?>"
					data-need-content="<?php echo (false===$save_life_portfolio_need_content ? 'true' : 'false'); ?>"
				>
					<?php
					if ($save_life_portfolio_need_content) 
						save_life_show_portfolio_posts(array(
							'cat' => $save_life_id,
							'parent_cat' => $save_life_cat,
							'taxonomy' => $save_life_taxonomy,
							'post_type' => $save_life_post_type,
							'page' => 1,
							'sticky' => $save_life_sticky_out
							)
						);
					?>
				</div>
				<?php
			}
			?>
		</div>
		<?php
	} else {
		save_life_show_portfolio_posts(array(
			'cat' => $save_life_cat,
			'parent_cat' => $save_life_cat,
			'taxonomy' => $save_life_taxonomy,
			'post_type' => $save_life_post_type,
			'page' => 1,
			'sticky' => $save_life_sticky_out
			)
		);
	}

	echo get_query_var('blog_archive_end');

} else {

	if ( is_search() )
		get_template_part( 'content', 'none-search' );
	else
		get_template_part( 'content', 'none-archive' );

}

get_footer();
?>