<?php
/**
 * The Sidebar containing the main widget areas.
 *
 * @package WordPress
 * @subpackage SAVE_LIFE
 * @since SAVE_LIFE 1.0
 */

$save_life_sidebar_position = save_life_get_theme_option('sidebar_position');
if (save_life_sidebar_present()) {
	ob_start();
	$save_life_sidebar_name = save_life_get_theme_option('sidebar_widgets');
	save_life_storage_set('current_sidebar', 'sidebar');
	if ( !dynamic_sidebar($save_life_sidebar_name) ) {
		// Put here html if user no set widgets in sidebar
	}
	$save_life_out = trim(ob_get_contents());
	ob_end_clean();
	if (trim(strip_tags($save_life_out)) != '') {
		?>
		<div class="sidebar <?php echo esc_attr($save_life_sidebar_position); ?> widget_area<?php if (!save_life_is_inherit(save_life_get_theme_option('sidebar_scheme'))) echo ' scheme_'.esc_attr(save_life_get_theme_option('sidebar_scheme')); ?>" role="complementary">
			<div class="sidebar_inner">
				<?php
				do_action( 'save_life_action_before_sidebar' );
				save_life_show_layout(preg_replace("/<\/aside>[\r\n\s]*<aside/", "</aside><aside", $save_life_out));
				do_action( 'save_life_action_after_sidebar' );
				?>
			</div><!-- /.sidebar_inner -->
		</div><!-- /.sidebar -->
		<?php
	}
}
?>