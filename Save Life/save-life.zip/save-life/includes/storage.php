<?php
/**
 * Theme storage manipulations
 *
 * @package WordPress
 * @subpackage SAVE_LIFE
 * @since SAVE_LIFE 1.0
 */

// Disable direct call
if ( ! defined( 'ABSPATH' ) ) { exit; }

// Get theme variable
if (!function_exists('save_life_storage_get')) {
	function save_life_storage_get($var_name, $default='') {
		global $SAVE_LIFE_STORAGE;
		return isset($SAVE_LIFE_STORAGE[$var_name]) ? $SAVE_LIFE_STORAGE[$var_name] : $default;
	}
}

// Set theme variable
if (!function_exists('save_life_storage_set')) {
	function save_life_storage_set($var_name, $value) {
		global $SAVE_LIFE_STORAGE;
		$SAVE_LIFE_STORAGE[$var_name] = $value;
	}
}

// Check if theme variable is empty
if (!function_exists('save_life_storage_empty')) {
	function save_life_storage_empty($var_name, $key='', $key2='') {
		global $SAVE_LIFE_STORAGE;
		if (!empty($key) && !empty($key2))
			return empty($SAVE_LIFE_STORAGE[$var_name][$key][$key2]);
		else if (!empty($key))
			return empty($SAVE_LIFE_STORAGE[$var_name][$key]);
		else
			return empty($SAVE_LIFE_STORAGE[$var_name]);
	}
}

// Check if theme variable is set
if (!function_exists('save_life_storage_isset')) {
	function save_life_storage_isset($var_name, $key='', $key2='') {
		global $SAVE_LIFE_STORAGE;
		if (!empty($key) && !empty($key2))
			return isset($SAVE_LIFE_STORAGE[$var_name][$key][$key2]);
		else if (!empty($key))
			return isset($SAVE_LIFE_STORAGE[$var_name][$key]);
		else
			return isset($SAVE_LIFE_STORAGE[$var_name]);
	}
}

// Inc/Dec theme variable with specified value
if (!function_exists('save_life_storage_inc')) {
	function save_life_storage_inc($var_name, $value=1) {
		global $SAVE_LIFE_STORAGE;
		if (empty($SAVE_LIFE_STORAGE[$var_name])) $SAVE_LIFE_STORAGE[$var_name] = 0;
		$SAVE_LIFE_STORAGE[$var_name] += $value;
	}
}

// Concatenate theme variable with specified value
if (!function_exists('save_life_storage_concat')) {
	function save_life_storage_concat($var_name, $value) {
		global $SAVE_LIFE_STORAGE;
		if (empty($SAVE_LIFE_STORAGE[$var_name])) $SAVE_LIFE_STORAGE[$var_name] = '';
		$SAVE_LIFE_STORAGE[$var_name] .= $value;
	}
}

// Get array (one or two dim) element
if (!function_exists('save_life_storage_get_array')) {
	function save_life_storage_get_array($var_name, $key, $key2='', $default='') {
		global $SAVE_LIFE_STORAGE;
		if (empty($key2))
			return !empty($var_name) && !empty($key) && isset($SAVE_LIFE_STORAGE[$var_name][$key]) ? $SAVE_LIFE_STORAGE[$var_name][$key] : $default;
		else
			return !empty($var_name) && !empty($key) && isset($SAVE_LIFE_STORAGE[$var_name][$key][$key2]) ? $SAVE_LIFE_STORAGE[$var_name][$key][$key2] : $default;
	}
}

// Set array element
if (!function_exists('save_life_storage_set_array')) {
	function save_life_storage_set_array($var_name, $key, $value) {
		global $SAVE_LIFE_STORAGE;
		if (!isset($SAVE_LIFE_STORAGE[$var_name])) $SAVE_LIFE_STORAGE[$var_name] = array();
		if ($key==='')
			$SAVE_LIFE_STORAGE[$var_name][] = $value;
		else
			$SAVE_LIFE_STORAGE[$var_name][$key] = $value;
	}
}

// Set two-dim array element
if (!function_exists('save_life_storage_set_array2')) {
	function save_life_storage_set_array2($var_name, $key, $key2, $value) {
		global $SAVE_LIFE_STORAGE;
		if (!isset($SAVE_LIFE_STORAGE[$var_name])) $SAVE_LIFE_STORAGE[$var_name] = array();
		if (!isset($SAVE_LIFE_STORAGE[$var_name][$key])) $SAVE_LIFE_STORAGE[$var_name][$key] = array();
		if ($key2==='')
			$SAVE_LIFE_STORAGE[$var_name][$key][] = $value;
		else
			$SAVE_LIFE_STORAGE[$var_name][$key][$key2] = $value;
	}
}

// Merge array elements
if (!function_exists('save_life_storage_merge_array')) {
	function save_life_storage_merge_array($var_name, $key, $value) {
		global $SAVE_LIFE_STORAGE;
		if (!isset($SAVE_LIFE_STORAGE[$var_name])) $SAVE_LIFE_STORAGE[$var_name] = array();
		if ($key==='')
			$SAVE_LIFE_STORAGE[$var_name] = array_merge($SAVE_LIFE_STORAGE[$var_name], $value);
		else
			$SAVE_LIFE_STORAGE[$var_name][$key] = array_merge($SAVE_LIFE_STORAGE[$var_name][$key], $value);
	}
}

// Add array element after the key
if (!function_exists('save_life_storage_set_array_after')) {
	function save_life_storage_set_array_after($var_name, $after, $key, $value='') {
		global $SAVE_LIFE_STORAGE;
		if (!isset($SAVE_LIFE_STORAGE[$var_name])) $SAVE_LIFE_STORAGE[$var_name] = array();
		if (is_array($key))
			save_life_array_insert_after($SAVE_LIFE_STORAGE[$var_name], $after, $key);
		else
			save_life_array_insert_after($SAVE_LIFE_STORAGE[$var_name], $after, array($key=>$value));
	}
}

// Add array element before the key
if (!function_exists('save_life_storage_set_array_before')) {
	function save_life_storage_set_array_before($var_name, $before, $key, $value='') {
		global $SAVE_LIFE_STORAGE;
		if (!isset($SAVE_LIFE_STORAGE[$var_name])) $SAVE_LIFE_STORAGE[$var_name] = array();
		if (is_array($key))
			save_life_array_insert_before($SAVE_LIFE_STORAGE[$var_name], $before, $key);
		else
			save_life_array_insert_before($SAVE_LIFE_STORAGE[$var_name], $before, array($key=>$value));
	}
}

// Push element into array
if (!function_exists('save_life_storage_push_array')) {
	function save_life_storage_push_array($var_name, $key, $value) {
		global $SAVE_LIFE_STORAGE;
		if (!isset($SAVE_LIFE_STORAGE[$var_name])) $SAVE_LIFE_STORAGE[$var_name] = array();
		if ($key==='')
			array_push($SAVE_LIFE_STORAGE[$var_name], $value);
		else {
			if (!isset($SAVE_LIFE_STORAGE[$var_name][$key])) $SAVE_LIFE_STORAGE[$var_name][$key] = array();
			array_push($SAVE_LIFE_STORAGE[$var_name][$key], $value);
		}
	}
}

// Pop element from array
if (!function_exists('save_life_storage_pop_array')) {
	function save_life_storage_pop_array($var_name, $key='', $defa='') {
		global $SAVE_LIFE_STORAGE;
		$rez = $defa;
		if ($key==='') {
			if (isset($SAVE_LIFE_STORAGE[$var_name]) && is_array($SAVE_LIFE_STORAGE[$var_name]) && count($SAVE_LIFE_STORAGE[$var_name]) > 0) 
				$rez = array_pop($SAVE_LIFE_STORAGE[$var_name]);
		} else {
			if (isset($SAVE_LIFE_STORAGE[$var_name][$key]) && is_array($SAVE_LIFE_STORAGE[$var_name][$key]) && count($SAVE_LIFE_STORAGE[$var_name][$key]) > 0) 
				$rez = array_pop($SAVE_LIFE_STORAGE[$var_name][$key]);
		}
		return $rez;
	}
}

// Inc/Dec array element with specified value
if (!function_exists('save_life_storage_inc_array')) {
	function save_life_storage_inc_array($var_name, $key, $value=1) {
		global $SAVE_LIFE_STORAGE;
		if (!isset($SAVE_LIFE_STORAGE[$var_name])) $SAVE_LIFE_STORAGE[$var_name] = array();
		if (empty($SAVE_LIFE_STORAGE[$var_name][$key])) $SAVE_LIFE_STORAGE[$var_name][$key] = 0;
		$SAVE_LIFE_STORAGE[$var_name][$key] += $value;
	}
}

// Concatenate array element with specified value
if (!function_exists('save_life_storage_concat_array')) {
	function save_life_storage_concat_array($var_name, $key, $value) {
		global $SAVE_LIFE_STORAGE;
		if (!isset($SAVE_LIFE_STORAGE[$var_name])) $SAVE_LIFE_STORAGE[$var_name] = array();
		if (empty($SAVE_LIFE_STORAGE[$var_name][$key])) $SAVE_LIFE_STORAGE[$var_name][$key] = '';
		$SAVE_LIFE_STORAGE[$var_name][$key] .= $value;
	}
}

// Call object's method
if (!function_exists('save_life_storage_call_obj_method')) {
	function save_life_storage_call_obj_method($var_name, $method, $param=null) {
		global $SAVE_LIFE_STORAGE;
		if ($param===null)
			return !empty($var_name) && !empty($method) && isset($SAVE_LIFE_STORAGE[$var_name]) ? $SAVE_LIFE_STORAGE[$var_name]->$method(): '';
		else
			return !empty($var_name) && !empty($method) && isset($SAVE_LIFE_STORAGE[$var_name]) ? $SAVE_LIFE_STORAGE[$var_name]->$method($param): '';
	}
}

// Get object's property
if (!function_exists('save_life_storage_get_obj_property')) {
	function save_life_storage_get_obj_property($var_name, $prop, $default='') {
		global $SAVE_LIFE_STORAGE;
		return !empty($var_name) && !empty($prop) && isset($SAVE_LIFE_STORAGE[$var_name]->$prop) ? $SAVE_LIFE_STORAGE[$var_name]->$prop : $default;
	}
}
?>