<?php
/**
 * The Classic template to display the content
 *
 * Used for index/archive/search.
 *
 * @package WordPress
 * @subpackage SAVE_LIFE
 * @since SAVE_LIFE 1.0
 */

$save_life_blog_style = explode('_', save_life_get_theme_option('blog_style'));
$save_life_columns = empty($save_life_blog_style[1]) ? 2 : max(2, $save_life_blog_style[1]);
$save_life_expanded = !save_life_sidebar_present() && save_life_is_on(save_life_get_theme_option('expand_content'));
$save_life_post_format = get_post_format();
$save_life_post_format = empty($save_life_post_format) ? 'standard' : str_replace('post-format-', '', $save_life_post_format);
$save_life_animation = save_life_get_theme_option('blog_animation');

?><div class="<?php echo trim($save_life_blog_style[0]) == 'classic' ? 'column' : 'masonry_item masonry_item'; ?>-1_<?php echo esc_attr($save_life_columns); ?>"><article id="post-<?php the_ID(); ?>"
	<?php post_class( 'post_item post_format_'.esc_attr($save_life_post_format)
					. ' post_layout_classic post_layout_classic_'.esc_attr($save_life_columns)
					. ' post_layout_'.esc_attr($save_life_blog_style[0]) 
					. ' post_layout_'.esc_attr($save_life_blog_style[0]).'_'.esc_attr($save_life_columns)
					); ?>
	<?php echo (!save_life_is_off($save_life_animation) ? ' data-animation="'.esc_attr(save_life_get_animation_classes($save_life_animation)).'"' : ''); ?>
	>

	<?php

	// Featured image
	save_life_show_post_featured( array( 'thumb_size' => save_life_get_thumb_size($save_life_blog_style[0] == 'classic'
													? (strpos(save_life_get_theme_option('body_style'), 'full')!==false 
															? ( $save_life_columns > 2 ? 'big' : 'huge' )
															: (	$save_life_columns > 2
																? ($save_life_expanded ? 'med' : 'small')
																: ($save_life_expanded ? 'big' : 'med')
																)
														)
													: (strpos(save_life_get_theme_option('body_style'), 'full')!==false 
															? ( $save_life_columns > 2 ? 'masonry-big' : 'full' )
															: (	$save_life_columns <= 2 && $save_life_expanded ? 'masonry-big' : 'masonry')
														)
								) ) );

	if ( !in_array($save_life_post_format, array('link', 'aside', 'status', 'quote')) ) {
		?>
		<div class="post_header entry-header">
			<?php 
			do_action('save_life_action_before_post_title'); 

			// Post title
			the_title( sprintf( '<h4 class="post_title entry-title"><a href="%s" rel="bookmark">', esc_url( get_permalink() ) ), '</a></h4>' );

			do_action('save_life_action_before_post_meta'); 

			// Post meta
			save_life_show_post_meta(array(
				'categories' => true,
				'date' => true,
				'edit' => $save_life_columns < 3,
				'seo' => false,
				'share' => false,
				'counters' => 'comments',
				)
			);
			?>
		</div><!-- .entry-header -->
		<?php
	}		
	?>

	<div class="post_content entry-content">
		<div class="post_content_inner">
			<?php
			$save_life_show_learn_more = false; //!in_array($save_life_post_format, array('link', 'aside', 'status', 'quote'));
			if (has_excerpt()) {
				the_excerpt();
			} else if (strpos(get_the_content('!--more'), '!--more')!==false) {
				the_content( '' );
			} else if (in_array($save_life_post_format, array('link', 'aside', 'status', 'quote'))) {
				the_content();
			} else if (substr(get_the_content(), 0, 1)!='[') {
				the_excerpt();
			}
			?>
		</div>
		<?php
		// Post meta
		if (in_array($save_life_post_format, array('link', 'aside', 'status', 'quote'))) {
			save_life_show_post_meta(array(
				'share' => false,
				'counters' => 'comments'
				)
			);
		}
		// More button
		if ( $save_life_show_learn_more ) {
			?><p><a class="more-link" href="<?php echo esc_url(get_permalink()); ?>"><?php esc_html_e('Read more', 'save-life'); ?></a></p><?php
		}
		?>
	</div><!-- .entry-content -->

</article></div>