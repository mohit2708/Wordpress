<?php
/**
 * The template for homepage posts with "Classic" style
 *
 * @package WordPress
 * @subpackage SAVE_LIFE
 * @since SAVE_LIFE 1.0
 */

save_life_storage_set('blog_archive', true);

// Load scripts for 'Masonry' layout
if (substr(save_life_get_theme_option('blog_style'), 0, 7) == 'masonry') {
	save_life_load_masonry_scripts();
}

get_header(); 

if (have_posts()) {

	echo get_query_var('blog_archive_start');

	$save_life_classes = 'posts_container '
						. (substr(save_life_get_theme_option('blog_style'), 0, 7) == 'classic' ? 'columns_wrap' : 'masonry_wrap');
	$save_life_stickies = is_home() ? get_option( 'sticky_posts' ) : false;
	$save_life_sticky_out = is_array($save_life_stickies) && count($save_life_stickies) > 0 && get_query_var( 'paged' ) < 1;
	if ($save_life_sticky_out) {
		?><div class="sticky_wrap columns_wrap"><?php	
	}
	if (!$save_life_sticky_out) {
		if (save_life_get_theme_option('first_post_large') && !is_paged() && !in_array(save_life_get_theme_option('body_style'), array('fullwide', 'fullscreen'))) {
			the_post();
			get_template_part( 'content', 'excerpt' );
		}
		
		?><div class="<?php echo esc_attr($save_life_classes); ?>"><?php
	}
	while ( have_posts() ) { the_post(); 
		if ($save_life_sticky_out && !is_sticky()) {
			$save_life_sticky_out = false;
			?></div><div class="<?php echo esc_attr($save_life_classes); ?>"><?php
		}
		get_template_part( 'content', $save_life_sticky_out && is_sticky() ? 'sticky' : 'classic' );
	}
	
	?></div><?php

	save_life_show_pagination();

	echo get_query_var('blog_archive_end');

} else {

	if ( is_search() )
		get_template_part( 'content', 'none-search' );
	else
		get_template_part( 'content', 'none-archive' );

}

get_footer();
?>