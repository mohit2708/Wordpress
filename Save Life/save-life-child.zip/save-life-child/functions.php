<?php
/**
 * Child-Theme functions and definitions
 */

function save_life_child_scripts() {
    wp_enqueue_style( 'save-life-parent-style', get_template_directory_uri(). '/style.css' );
}
add_action( 'wp_enqueue_scripts', 'save_life_child_scripts' );
 
?>