<div id="page-navigation" <?php Mitech::navigation_class(); ?>>
	<nav id="menu" class="menu menu--primary">
		<?php Mitech::menu_primary(); ?>
	</nav>
</div>
