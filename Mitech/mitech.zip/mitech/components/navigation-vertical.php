<div id="page-navigation" <?php Mitech::navigation_class(); ?>>
	<nav id="menu" class="menu menu--primary">
		<?php Mitech::menu_primary( array(
			'menu_class' => 'menu__container sm sm-simple sm-vertical',
		) ); ?>
	</nav>
</div>
