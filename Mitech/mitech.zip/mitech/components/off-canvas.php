<div id="page-close-main-menu" class="page-close-main-menu"></div>

<div class="page-off-canvas-main-menu">
	<div id="page-navigation" <?php Mitech::navigation_class(); ?>>
		<?php Mitech::off_canvas_menu_primary(); ?>
	</div>
</div>
