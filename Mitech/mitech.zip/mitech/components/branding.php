<div <?php Mitech::branding_class(); ?>>
	<div class="branding__logo">
		<?php Mitech::branding_logo(); ?>
	</div>
</div>
