jQuery( document ).ready( function( $ ) {
	'use strict';

	var $body = $( 'body' );
