MDTF - WordPress Meta Data Filter & Taxonomies Filter - the plugin for filtering and searching WordPress content in posts and their custom types by taxonomies and meta data fields. The plugin has very high flexibility thanks to its rich filter elements and in-built meta fields constructor!


Use this gift on any your projects/sites where it is necessary filtration with meta data and taxonomies on the same time - cars, homes, flowers, bikes . For WooCommerce use WOOF, but of course MDTF also works with Woo. See the demo as an examples: https://wp-filter.com/demo-sites/

Read More here: https://wp-filter.com/

