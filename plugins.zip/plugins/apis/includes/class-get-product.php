<?php
function getProductList(){
	$id = 3;
	global $wpdb;
	$rows = $wpdb->get_results("select * from wp_product where id = $id");
	echo json_encode($rows);
}


