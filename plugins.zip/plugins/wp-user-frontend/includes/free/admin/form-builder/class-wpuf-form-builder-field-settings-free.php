<?php
/**
 * Field Settings
 *
 * @since 2.5
 */
class WPUF_Form_Builder_Field_Settings_Free extends WPUF_Form_Builder_Field_Settings {
}
