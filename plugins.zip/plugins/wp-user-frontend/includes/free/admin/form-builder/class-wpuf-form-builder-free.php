<?php
/**
 * Form Builder framework
 */
class WPUF_Admin_Form_Builder_Free {
    /**
     * Class construction
     *
     * @since 2.5
     *
     * @return void
     */
    public function __construct() {}
}
