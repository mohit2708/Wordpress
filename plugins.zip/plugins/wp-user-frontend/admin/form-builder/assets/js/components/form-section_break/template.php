<div class="wpuf-section-wrap">
    <h2 class="wpuf-section-title">{{ field.label }}</h2>
    <div class="wpuf-section-details">{{ field.description }}</div>
</div>
