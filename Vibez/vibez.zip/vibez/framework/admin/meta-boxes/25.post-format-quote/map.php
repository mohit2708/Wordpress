<?php

if ( ! function_exists( 'vibez_elated_map_post_quote_meta' ) ) {
	function vibez_elated_map_post_quote_meta() {
		$quote_post_format_meta_box = vibez_elated_create_meta_box(
			array(
				'scope' => array( 'post' ),
				'title' => esc_html__( 'Quote Post Format', 'vibez' ),
				'name'  => 'post_format_quote_meta'
			)
		);
		
		vibez_elated_create_meta_box_field(
			array(
				'name'        => 'eltdf_post_quote_text_meta',
				'type'        => 'text',
				'label'       => esc_html__( 'Quote Text', 'vibez' ),
				'description' => esc_html__( 'Enter Quote text', 'vibez' ),
				'parent'      => $quote_post_format_meta_box,
			
			)
		);
		
		vibez_elated_create_meta_box_field(
			array(
				'name'        => 'eltdf_post_quote_author_meta',
				'type'        => 'text',
				'label'       => esc_html__( 'Quote Author', 'vibez' ),
				'description' => esc_html__( 'Enter Quote author', 'vibez' ),
				'parent'      => $quote_post_format_meta_box,
			)
		);

		vibez_elated_create_meta_box_field(
			array(
				'name'        => 'eltdf_post_quote_author_position',
				'type'        => 'text',
				'label'       => esc_html__( 'Quote Author Position', 'vibez' ),
				'description' => esc_html__( 'Enter Quote author position', 'vibez' ),
				'parent'      => $quote_post_format_meta_box,
			)
		);
	}
	
	add_action( 'vibez_elated_action_meta_boxes_map', 'vibez_elated_map_post_quote_meta', 25 );
}