<?php

if ( ! function_exists( 'vibez_elated_map_footer_meta' ) ) {
	function vibez_elated_map_footer_meta() {
		$footer_meta_box = vibez_elated_create_meta_box(
			array(
				'scope' => apply_filters( 'vibez_elated_filter_set_scope_for_meta_boxes', array( 'page', 'post' ) ),
				'title' => esc_html__( 'Footer', 'vibez' ),
				'name'  => 'footer_meta'
			)
		);
		
		vibez_elated_create_meta_box_field(
			array(
				'name'          => 'eltdf_disable_footer_meta',
				'type'          => 'yesno',
				'default_value' => 'no',
				'label'         => esc_html__( 'Disable Footer for this Page', 'vibez' ),
				'description'   => esc_html__( 'Enabling this option will hide footer on this page', 'vibez' ),
				'parent'        => $footer_meta_box
			)
		);
		
		vibez_elated_create_meta_box_field(
			array(
				'name'          => 'eltdf_show_footer_top_meta',
				'type'          => 'select',
				'default_value' => '',
				'label'         => esc_html__( 'Show Footer Top', 'vibez' ),
				'description'   => esc_html__( 'Enabling this option will show Footer Top area', 'vibez' ),
				'parent'        => $footer_meta_box,
				'options'       => vibez_elated_get_yes_no_select_array()
			)
		);
		
		vibez_elated_create_meta_box_field(
			array(
				'name'          => 'eltdf_show_footer_bottom_meta',
				'type'          => 'select',
				'default_value' => '',
				'label'         => esc_html__( 'Show Footer Bottom', 'vibez' ),
				'description'   => esc_html__( 'Enabling this option will show Footer Bottom area', 'vibez' ),
				'parent'        => $footer_meta_box,
				'options'       => vibez_elated_get_yes_no_select_array()
			)
		);
	}
	
	add_action( 'vibez_elated_action_meta_boxes_map', 'vibez_elated_map_footer_meta', 70 );
}