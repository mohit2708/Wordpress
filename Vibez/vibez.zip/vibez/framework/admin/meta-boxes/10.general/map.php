<?php

if ( ! function_exists( 'vibez_elated_map_general_meta' ) ) {
	function vibez_elated_map_general_meta() {
		
		$general_meta_box = vibez_elated_create_meta_box(
			array(
				'scope' => apply_filters( 'vibez_elated_filter_set_scope_for_meta_boxes', array( 'page', 'post' ) ),
				'title' => esc_html__( 'General', 'vibez' ),
				'name'  => 'general_meta'
			)
		);

		vibez_elated_create_meta_box_field(
			array(
				'type'          => 'select',
				'name'          => 'eltdf_page_font',
				'default_value' => 'default',
				'label'         => esc_html__( 'Page Font', 'vibez' ),
				'description'   => esc_html__( 'Select a font that will be applied to this page headings', 'vibez' ),
				'parent'        => $general_meta_box,
				'options'       => array(
					'default'           => esc_html__( 'Default', 'vibez' ),
					'quicksand'         => esc_html__( 'Quicksand', 'vibez' ),
					'worksans'          => esc_html__( 'WorkSans', 'vibez' ),
					'permanentmarker'   => esc_html__( 'PermanentMarker', 'vibez' ),
					'montserrat'        => esc_html__( 'Montserrat', 'vibez' ),
					'roboto'            => esc_html__( 'Roboto', 'vibez' ),
					'playfair'          => esc_html__( 'Playfair Display + WorkSans', 'vibez' )
				)
			)
		);
		
		vibez_elated_create_meta_box_field(
			array(
				'name'          => 'eltdf_page_content_behind_header_meta',
				'type'          => 'yesno',
				'default_value' => 'no',
				'label'         => esc_html__( 'Always put content behind header', 'vibez' ),
				'description'   => esc_html__( 'Enabling this option will put page content behind page header', 'vibez' ),
				'parent'        => $general_meta_box,
				'args'          => array(
					'suffix' => 'px'
				)
			)
		);
		
		$eltdf_content_padding_group = vibez_elated_add_admin_group(
			array(
				'name'        => 'content_padding_group',
				'title'       => esc_html__( 'Content Style', 'vibez' ),
				'description' => esc_html__( 'Define styles for Content area', 'vibez' ),
				'parent'      => $general_meta_box
			)
		);
		
		$eltdf_content_padding_row = vibez_elated_add_admin_row(
			array(
				'name'   => 'eltdf_content_padding_row',
				'next'   => true,
				'parent' => $eltdf_content_padding_group
			)
		);
		
		vibez_elated_create_meta_box_field(
			array(
				'name'   => 'eltdf_page_content_top_padding',
				'type'   => 'textsimple',
				'label'  => esc_html__( 'Content Top Padding', 'vibez' ),
				'parent' => $eltdf_content_padding_row,
				'args'   => array(
					'suffix' => 'px'
				)
			)
		);
		
		vibez_elated_create_meta_box_field(
			array(
				'name'    => 'eltdf_page_content_top_padding_mobile',
				'type'    => 'selectsimple',
				'label'   => esc_html__( 'Set this top padding for mobile header', 'vibez' ),
				'parent'  => $eltdf_content_padding_row,
				'options' => vibez_elated_get_yes_no_select_array( false )
			)
		);
		
		vibez_elated_create_meta_box_field(
			array(
				'name'        => 'eltdf_page_slider_meta',
				'type'        => 'text',
				'label'       => esc_html__( 'Slider Shortcode', 'vibez' ),
				'description' => esc_html__( 'Paste your slider shortcode here', 'vibez' ),
				'parent'      => $general_meta_box
			)
		);
		
		vibez_elated_create_meta_box_field(
			array(
				'name'        => 'eltdf_first_color_meta',
				'type'        => 'color',
				'label'       => esc_html__( 'First Main Color', 'vibez' ),
				'description' => esc_html__( 'Choose the most dominant theme color for this page', 'vibez' ),
				'parent'      => $general_meta_box
			)
		);
		
		vibez_elated_create_meta_box_field(
			array(
				'name'        => 'eltdf_page_background_color_meta',
				'type'        => 'color',
				'label'       => esc_html__( 'Page Background Color', 'vibez' ),
				'description' => esc_html__( 'Choose background color for page content', 'vibez' ),
				'parent'      => $general_meta_box
			)
		);
		
		vibez_elated_create_meta_box_field(
			array(
				'name'    => 'eltdf_boxed_meta',
				'type'    => 'select',
				'label'   => esc_html__( 'Boxed Layout', 'vibez' ),
				'parent'  => $general_meta_box,
				'options' => vibez_elated_get_yes_no_select_array(),
				'args'    => array(
					'dependence' => true,
					'hide'       => array(
						''    => '#eltdf_boxed_container_meta',
						'no'  => '#eltdf_boxed_container_meta',
						'yes' => ''
					),
					'show'       => array(
						''    => '',
						'no'  => '',
						'yes' => '#eltdf_boxed_container_meta'
					)
				)
			)
		);
		
		$boxed_container_meta = vibez_elated_add_admin_container(
			array(
				'parent'          => $general_meta_box,
				'name'            => 'boxed_container_meta',
				'hidden_property' => 'eltdf_boxed_meta',
				'hidden_values'   => array(
					'',
					'no'
				)
			)
		);
		
		vibez_elated_create_meta_box_field(
			array(
				'name'        => 'eltdf_page_background_color_in_box_meta',
				'type'        => 'color',
				'label'       => esc_html__( 'Page Background Color', 'vibez' ),
				'description' => esc_html__( 'Choose the page background color outside box', 'vibez' ),
				'parent'      => $boxed_container_meta
			)
		);
		
		vibez_elated_create_meta_box_field(
			array(
				'name'        => 'eltdf_boxed_background_image_meta',
				'type'        => 'image',
				'label'       => esc_html__( 'Background Image', 'vibez' ),
				'description' => esc_html__( 'Choose an image to be displayed in background', 'vibez' ),
				'parent'      => $boxed_container_meta
			)
		);
		
		vibez_elated_create_meta_box_field(
			array(
				'name'        => 'eltdf_boxed_pattern_background_image_meta',
				'type'        => 'image',
				'label'       => esc_html__( 'Background Pattern', 'vibez' ),
				'description' => esc_html__( 'Choose an image to be used as background pattern', 'vibez' ),
				'parent'      => $boxed_container_meta
			)
		);
		
		vibez_elated_create_meta_box_field(
			array(
				'name'          => 'eltdf_boxed_background_image_attachment_meta',
				'type'          => 'select',
				'default_value' => 'fixed',
				'label'         => esc_html__( 'Background Image Attachment', 'vibez' ),
				'description'   => esc_html__( 'Choose background image attachment', 'vibez' ),
				'parent'        => $boxed_container_meta,
				'options'       => array(
					''       => esc_html__( 'Default', 'vibez' ),
					'fixed'  => esc_html__( 'Fixed', 'vibez' ),
					'scroll' => esc_html__( 'Scroll', 'vibez' )
				)
			)
		);
		
		vibez_elated_create_meta_box_field(
			array(
				'name'          => 'eltdf_smooth_page_transitions_meta',
				'type'          => 'select',
				'default_value' => '',
				'label'         => esc_html__( 'Smooth Page Transitions', 'vibez' ),
				'description'   => esc_html__( 'Enabling this option will perform a smooth transition between pages when clicking on links', 'vibez' ),
				'parent'        => $general_meta_box,
				'options'       => vibez_elated_get_yes_no_select_array(),
				'args'          => array(
					'dependence' => true,
					'hide'       => array(
						''    => '#eltdf_page_transitions_container_meta',
						'no'  => '#eltdf_page_transitions_container_meta',
						'yes' => ''
					),
					'show'       => array(
						''    => '',
						'no'  => '',
						'yes' => '#eltdf_page_transitions_container_meta'
					)
				)
			)
		);
		
		$page_transitions_container_meta = vibez_elated_add_admin_container(
			array(
				'parent'          => $general_meta_box,
				'name'            => 'page_transitions_container_meta',
				'hidden_property' => 'eltdf_smooth_page_transitions_meta',
				'hidden_values'   => array(
					'',
					'no'
				)
			)
		);
		
		vibez_elated_create_meta_box_field(
			array(
				'name'        => 'eltdf_page_transition_preloader_meta',
				'type'        => 'select',
				'label'       => esc_html__( 'Enable Preloading Animation', 'vibez' ),
				'description' => esc_html__( 'Enabling this option will display an animated preloader while the page content is loading', 'vibez' ),
				'parent'      => $page_transitions_container_meta,
				'options'     => vibez_elated_get_yes_no_select_array(),
				'args'        => array(
					'dependence' => true,
					'hide'       => array(
						''    => '#eltdf_page_transition_preloader_container_meta',
						'no'  => '#eltdf_page_transition_preloader_container_meta',
						'yes' => ''
					),
					'show'       => array(
						''    => '',
						'no'  => '',
						'yes' => '#eltdf_page_transition_preloader_container_meta'
					)
				)
			)
		);
		
		$page_transition_preloader_container_meta = vibez_elated_add_admin_container(
			array(
				'parent'          => $page_transitions_container_meta,
				'name'            => 'page_transition_preloader_container_meta',
				'hidden_property' => 'eltdf_page_transition_preloader_meta',
				'hidden_values'   => array(
					'',
					'no'
				)
			)
		);
		
		vibez_elated_create_meta_box_field(
			array(
				'name'   => 'eltdf_smooth_pt_bgnd_color_meta',
				'type'   => 'color',
				'label'  => esc_html__( 'Page Loader Background Color', 'vibez' ),
				'parent' => $page_transition_preloader_container_meta
			)
		);
		
		$group_pt_spinner_animation_meta = vibez_elated_add_admin_group(
			array(
				'name'        => 'group_pt_spinner_animation_meta',
				'title'       => esc_html__( 'Loader Style', 'vibez' ),
				'description' => esc_html__( 'Define styles for loader spinner animation', 'vibez' ),
				'parent'      => $page_transition_preloader_container_meta
			)
		);
		
		$row_pt_spinner_animation_meta = vibez_elated_add_admin_row(
			array(
				'name'   => 'row_pt_spinner_animation_meta',
				'parent' => $group_pt_spinner_animation_meta
			)
		);
		
		vibez_elated_create_meta_box_field(
			array(
				'type'    => 'selectsimple',
				'name'    => 'eltdf_smooth_pt_spinner_type_meta',
				'label'   => esc_html__( 'Spinner Type', 'vibez' ),
				'parent'  => $row_pt_spinner_animation_meta,
				'options' => array(
					''                      => esc_html__( 'Default', 'vibez' ),
					'rotate_circles'        => esc_html__( 'Rotate Circles', 'vibez' ),
					'pulse'                 => esc_html__( 'Pulse', 'vibez' ),
					'double_pulse'          => esc_html__( 'Double Pulse', 'vibez' ),
					'cube'                  => esc_html__( 'Cube', 'vibez' ),
					'rotating_cubes'        => esc_html__( 'Rotating Cubes', 'vibez' ),
					'stripes'               => esc_html__( 'Stripes', 'vibez' ),
					'wave'                  => esc_html__( 'Wave', 'vibez' ),
					'two_rotating_circles'  => esc_html__( '2 Rotating Circles', 'vibez' ),
					'five_rotating_circles' => esc_html__( '5 Rotating Circles', 'vibez' ),
					'atom'                  => esc_html__( 'Atom', 'vibez' ),
					'clock'                 => esc_html__( 'Clock', 'vibez' ),
					'mitosis'               => esc_html__( 'Mitosis', 'vibez' ),
					'lines'                 => esc_html__( 'Lines', 'vibez' ),
					'fussion'               => esc_html__( 'Fussion', 'vibez' ),
					'wave_circles'          => esc_html__( 'Wave Circles', 'vibez' ),
					'pulse_circles'         => esc_html__( 'Pulse Circles', 'vibez' )
				)
			)
		);
		
		vibez_elated_create_meta_box_field(
			array(
				'type'   => 'colorsimple',
				'name'   => 'eltdf_smooth_pt_spinner_color_meta',
				'label'  => esc_html__( 'Spinner Color', 'vibez' ),
				'parent' => $row_pt_spinner_animation_meta
			)
		);
		
		vibez_elated_create_meta_box_field(
			array(
				'name'        => 'eltdf_page_transition_fadeout_meta',
				'type'        => 'select',
				'label'       => esc_html__( 'Enable Fade Out Animation', 'vibez' ),
				'description' => esc_html__( 'Enabling this option will turn on fade out animation when leaving page', 'vibez' ),
				'options'     => vibez_elated_get_yes_no_select_array(),
				'parent'      => $page_transitions_container_meta
			
			)
		);
		
		vibez_elated_create_meta_box_field(
			array(
				'name'        => 'eltdf_page_comments_meta',
				'type'        => 'select',
				'label'       => esc_html__( 'Show Comments', 'vibez' ),
				'description' => esc_html__( 'Enabling this option will show comments on your page', 'vibez' ),
				'parent'      => $general_meta_box,
				'options'     => vibez_elated_get_yes_no_select_array()
			)
		);
	}
	
	add_action( 'vibez_elated_action_meta_boxes_map', 'vibez_elated_map_general_meta', 10 );
}