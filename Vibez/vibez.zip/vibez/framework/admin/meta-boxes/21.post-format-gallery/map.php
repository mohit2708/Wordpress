<?php

if ( ! function_exists( 'vibez_elated_map_post_gallery_meta' ) ) {
	
	function vibez_elated_map_post_gallery_meta() {
		$gallery_post_format_meta_box = vibez_elated_create_meta_box(
			array(
				'scope' => array( 'post' ),
				'title' => esc_html__( 'Gallery Post Format', 'vibez' ),
				'name'  => 'post_format_gallery_meta'
			)
		);
		
		vibez_elated_add_multiple_images_field(
			array(
				'name'        => 'eltdf_post_gallery_images_meta',
				'label'       => esc_html__( 'Gallery Images', 'vibez' ),
				'description' => esc_html__( 'Choose your gallery images', 'vibez' ),
				'parent'      => $gallery_post_format_meta_box,
			)
		);
	}
	
	add_action( 'vibez_elated_action_meta_boxes_map', 'vibez_elated_map_post_gallery_meta', 21 );
}
