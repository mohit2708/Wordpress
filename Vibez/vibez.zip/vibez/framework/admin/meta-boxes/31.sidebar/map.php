<?php

if ( ! function_exists( 'vibez_elated_map_sidebar_meta' ) ) {
	function vibez_elated_map_sidebar_meta() {
		$eltdf_sidebar_meta_box = vibez_elated_create_meta_box(
			array(
				'scope' => apply_filters( 'vibez_elated_filter_set_scope_for_meta_boxes', array( 'page' ) ),
				'title' => esc_html__( 'Sidebar', 'vibez' ),
				'name'  => 'sidebar_meta'
			)
		);
		
		vibez_elated_create_meta_box_field(
			array(
				'name'        => 'eltdf_sidebar_layout_meta',
				'type'        => 'select',
				'label'       => esc_html__( 'Layout', 'vibez' ),
				'description' => esc_html__( 'Choose the sidebar layout', 'vibez' ),
				'parent'      => $eltdf_sidebar_meta_box,
				'options'     => array(
					''                 => esc_html__( 'Default', 'vibez' ),
					'no-sidebar'       => esc_html__( 'No Sidebar', 'vibez' ),
					'sidebar-33-right' => esc_html__( 'Sidebar 1/3 Right', 'vibez' ),
					'sidebar-25-right' => esc_html__( 'Sidebar 1/4 Right', 'vibez' ),
					'sidebar-33-left'  => esc_html__( 'Sidebar 1/3 Left', 'vibez' ),
					'sidebar-25-left'  => esc_html__( 'Sidebar 1/4 Left', 'vibez' )
				)
			)
		);
		
		$eltdf_custom_sidebars = vibez_elated_get_custom_sidebars();
		if ( count( $eltdf_custom_sidebars ) > 0 ) {
			vibez_elated_create_meta_box_field(
				array(
					'name'        => 'eltdf_custom_sidebar_area_meta',
					'type'        => 'selectblank',
					'label'       => esc_html__( 'Choose Widget Area in Sidebar', 'vibez' ),
					'description' => esc_html__( 'Choose Custom Widget area to display in Sidebar"', 'vibez' ),
					'parent'      => $eltdf_sidebar_meta_box,
					'options'     => $eltdf_custom_sidebars,
					'args'        => array(
						'select2'	=> true
					)
				)
			);
		}
	}
	
	add_action( 'vibez_elated_action_meta_boxes_map', 'vibez_elated_map_sidebar_meta', 31 );
}