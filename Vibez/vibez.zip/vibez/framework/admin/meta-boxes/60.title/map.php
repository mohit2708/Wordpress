<?php

if ( ! function_exists( 'vibez_elated_map_title_meta' ) ) {
	function vibez_elated_map_title_meta() {
		$title_meta_box = vibez_elated_create_meta_box(
			array(
				'scope' => apply_filters( 'vibez_elated_filter_set_scope_for_meta_boxes', array( 'page', 'post' ) ),
				'title' => esc_html__( 'Title', 'vibez' ),
				'name'  => 'title_meta'
			)
		);
		
		vibez_elated_create_meta_box_field(
			array(
				'name'          => 'eltdf_show_title_area_meta',
				'type'          => 'select',
				'default_value' => '',
				'label'         => esc_html__( 'Show Title Area', 'vibez' ),
				'description'   => esc_html__( 'Disabling this option will turn off page title area', 'vibez' ),
				'parent'        => $title_meta_box,
				'options'       => vibez_elated_get_yes_no_select_array(),
				'args'          => array(
					"dependence" => true,
					"hide"       => array(
						""    => "",
						"no"  => "#eltdf_eltdf_show_title_area_meta_container",
						"yes" => ""
					),
					"show"       => array(
						""    => "#eltdf_eltdf_show_title_area_meta_container",
						"no"  => "",
						"yes" => "#eltdf_eltdf_show_title_area_meta_container"
					)
				)
			)
		);
		
		$show_title_area_meta_container = vibez_elated_add_admin_container(
			array(
				'parent'          => $title_meta_box,
				'name'            => 'eltdf_show_title_area_meta_container',
				'hidden_property' => 'eltdf_show_title_area_meta',
				'hidden_value'    => 'no'
			)
		);
		
		vibez_elated_create_meta_box_field(
			array(
				'name'          => 'eltdf_title_area_type_meta',
				'type'          => 'select',
				'default_value' => '',
				'label'         => esc_html__( 'Title Area Type', 'vibez' ),
				'description'   => esc_html__( 'Choose title type', 'vibez' ),
				'parent'        => $show_title_area_meta_container,
				'options' => array(
					''           => esc_html__( 'Default', 'vibez' ),
					'standard' => esc_html__('Standard', 'vibez'),
					'split-columns' => esc_html__('Split Columns', 'vibez'),
					'breadcrumb' => esc_html__('Breadcrumb', 'vibez')
				),
				'args' => array(
					'dependence' => true,
					'hide' => array(
						''         => '#eltdf_eltdf_title_area_split_type_meta_container',
						'standard' => '#eltdf_eltdf_title_area_split_type_meta_container',
						'split-columns' => '',
						'breadcrumb' => '#eltdf_eltdf_title_area_split_type_meta_container'
					),
					'show' => array(
						''         => '',
						'standard' => '',
						'split-columns' => '#eltdf_eltdf_title_area_split_type_meta_container',
						'breadcrumb' => ''
					)
				)
			)
		);
		
		$title_area_split_type_container = vibez_elated_add_admin_container(
			array(
				'parent' => $show_title_area_meta_container,
				'name' => 'eltdf_title_area_split_type_meta_container',
				'hidden_property' => 'eltdf_title_area_type_meta',
				'hidden_values' => array(
					'standard',
					'breadcrumb'
				)
			)
		);
		
			vibez_elated_create_meta_box_field(
				array(
					'name'          => 'eltdf_title_area_title_text_position_meta',
					'type'          => 'select',
					'label'         => esc_html__( 'Title Text Position', 'vibez' ),
					'parent'        => $title_area_split_type_container,
					'options'       => array(
						''              => esc_html__( 'Default', 'vibez' ),
						'title-left'  => esc_html__( 'Title Left - Subtitle Right', 'vibez' ),
						'title-right' => esc_html__( 'Title Right - Subtitle Left', 'vibez' )
					)
				)
			);
		
			vibez_elated_create_meta_box_field(array(
				'name' => 'eltdf_title_area_title_light_words_meta',
				'type' => 'text',
				'label' => esc_html__('Words with Light Font Weight', 'vibez'),
				'description' => esc_html__('Enter the positions of the words you would like to display in a "light" font weight. Separate the positions with commas (e.g. if you would like the first, third, and fourth word to have a light font weight, you would enter "1,3,4")', 'vibez'),
				'parent' => $title_area_split_type_container,
				'args' => array(
					'col_width' => 3
				)
			));
		
			vibez_elated_create_meta_box_field(array(
				'name' => 'eltdf_title_area_title_break_words_meta',
				'type' => 'text',
				'label' => esc_html__('Position of Line Break', 'vibez'),
				'description' => esc_html__('Enter the position of the word after which you would like to create a line break (e.g. if you would like the line break after the 3rd word, you would enter "3")', 'vibez'),
				'parent' => $title_area_split_type_container,
				'args' => array(
					'col_width' => 3
				)
			));
		
			vibez_elated_create_meta_box_field(
				array(
					'name' => 'eltdf_title_area_disable_break_words_meta',
					'type' => 'select',
					'label' => esc_html__('Disable Line Break for Smaller Screens', 'vibez'),
					'parent' => $title_area_split_type_container,
					'options' => vibez_elated_get_yes_no_select_array()
				)
			);
		
		vibez_elated_create_meta_box_field(
			array(
				'name'          => 'eltdf_title_area_vertical_alignment_meta',
				'type'          => 'select',
				'default_value' => '',
				'label'         => esc_html__( 'Vertical Alignment', 'vibez' ),
				'description'   => esc_html__( 'Specify title vertical alignment', 'vibez' ),
				'parent'        => $show_title_area_meta_container,
				'options'       => array(
					''              => esc_html__( 'Default', 'vibez' ),
					'header_bottom' => esc_html__( 'From Bottom of Header', 'vibez' ),
					'window_top'    => esc_html__( 'From Window Top', 'vibez' )
				)
			)
		);
		
		vibez_elated_create_meta_box_field(
			array(
				'name'          => 'eltdf_title_area_content_alignment_meta',
				'type'          => 'select',
				'default_value' => '',
				'label'         => esc_html__( 'Horizontal Alignment', 'vibez' ),
				'description'   => esc_html__( 'Specify title horizontal alignment', 'vibez' ),
				'parent'        => $show_title_area_meta_container,
				'options'       => array(
					''       => esc_html__( 'Default', 'vibez' ),
					'left'   => esc_html__( 'Left', 'vibez' ),
					'center' => esc_html__( 'Center', 'vibez' ),
					'right'  => esc_html__( 'Right', 'vibez' )
				)
			)
		);
		
		vibez_elated_create_meta_box_field(
			array(
				'name'          => 'eltdf_title_area_enable_breadcrumbs_meta',
				'type'          => 'select',
				'default_value' => '',
				'label'         => esc_html__( 'Enable Breadcrumbs', 'vibez' ),
				'description'   => esc_html__( 'This option will display Breadcrumbs in Title Area', 'vibez' ),
				'parent'        => $show_title_area_meta_container,
				'options'       => vibez_elated_get_yes_no_select_array()
			)
		);
		
		vibez_elated_create_meta_box_field(
			array(
				'name'          => 'eltdf_title_enable_arrows_animation_meta',
				'type'          => 'select',
				'default_value' => '',
				'label'         => esc_html__( 'Enable Arrows Background Animation', 'vibez' ),
				'parent'        => $show_title_area_meta_container,
				'options'       => vibez_elated_get_yes_no_select_array(),
				'args' => array(
					'dependence' => true,
					'hide' => array(
						''    => '',
						'no'  => '#eltdf_eltdf_title_area_arrows_container',
						'yes' => ''
					),
					'show' => array(
						''    => '#eltdf_eltdf_title_area_arrows_container',
						'no'  => '',
						'yes' => '#eltdf_eltdf_title_area_arrows_container'
					)
				)
			)
		);
		
		$title_area_arrows_container = vibez_elated_add_admin_container(
			array(
				'parent'          => $show_title_area_meta_container,
				'name'            => 'eltdf_title_area_arrows_container',
				'hidden_property' => 'eltdf_title_enable_arrows_animation_meta',
				'hidden_values'   => array(
					'',
					'no'
				)
			)
		);
		
			vibez_elated_create_meta_box_field(
				array(
					'name'    => 'eltdf_title_area_arrows_skin_meta',
					'type'    => 'select',
					'label'   => esc_html__( 'Arrows Skin', 'vibez' ),
					'parent'  => $title_area_arrows_container,
					'options' => array(
						''       => esc_html__( 'Default', 'vibez' ),
						'green'  => esc_html__( 'Green', 'vibez' ),
						'white'  => esc_html__( 'White', 'vibez' ),
						'black'  => esc_html__( 'Black', 'vibez' ),
						'gray'   => esc_html__( 'Gray', 'vibez' )
					)
				)
			);
		
			vibez_elated_create_meta_box_field(
				array(
					'name'    => 'eltdf_title_area_arrows_position_meta',
					'type'    => 'select',
					'label'   => esc_html__( 'Arrows Position', 'vibez' ),
					'parent'  => $title_area_arrows_container,
					'options' => array(
						''      => esc_html__( 'Default', 'vibez' ),
						'left'  => esc_html__( 'Left', 'vibez' ),
						'right' => esc_html__( 'Right', 'vibez' )
					)
				)
			);
		
			vibez_elated_create_meta_box_field(
				array(
					'name'    => 'eltdf_title_area_disable_arrows_animation_meta',
					'type'    => 'select',
					'label'   => esc_html__( 'Disable Arrows Animation', 'vibez' ),
					'description' => esc_html__( 'Choose on which stage you hide title area arrows animation', 'vibez' ),
					'parent'  => $title_area_arrows_container,
					'options' => array(
						''      => esc_html__( 'Default', 'vibez' ),
						'never' => esc_html__( 'Never', 'vibez' ),
						'1280'  => esc_html__( 'Below 1280px', 'vibez' ),
						'1024'  => esc_html__( 'Below 1024px', 'vibez' ),
						'768'   => esc_html__( 'Below 768px', 'vibez' ),
						'680'   => esc_html__( 'Below 680px', 'vibez' ),
						'480'   => esc_html__( 'Below 480px', 'vibez' )
					)
				)
			);
		
		vibez_elated_create_meta_box_field(
			array(
				'name'          => 'eltdf_title_area_title_tag_meta',
				'type'          => 'select',
				'default_value' => '',
				'label'         => esc_html__( 'Title Tag', 'vibez' ),
				'parent'        => $show_title_area_meta_container,
				'options'       => vibez_elated_get_title_tag( true )
			)
		);
		
		vibez_elated_create_meta_box_field(
			array(
				'name'        => 'eltdf_title_text_color_meta',
				'type'        => 'color',
				'label'       => esc_html__( 'Title Color', 'vibez' ),
				'description' => esc_html__( 'Choose a color for title text', 'vibez' ),
				'parent'      => $show_title_area_meta_container
			)
		);
		
		vibez_elated_create_meta_box_field(
			array(
				'name'        => 'eltdf_title_area_background_color_meta',
				'type'        => 'color',
				'label'       => esc_html__( 'Background Color', 'vibez' ),
				'description' => esc_html__( 'Choose a background color for title area', 'vibez' ),
				'parent'      => $show_title_area_meta_container
			)
		);
		
		vibez_elated_create_meta_box_field(
			array(
				'name'          => 'eltdf_hide_background_image_meta',
				'type'          => 'yesno',
				'default_value' => 'no',
				'label'         => esc_html__( 'Hide Background Image', 'vibez' ),
				'description'   => esc_html__( 'Enable this option to hide background image in title area', 'vibez' ),
				'parent'        => $show_title_area_meta_container,
				'args'          => array(
					"dependence"             => true,
					"dependence_hide_on_yes" => "#eltdf_eltdf_hide_background_image_meta_container",
					"dependence_show_on_yes" => ""
				)
			)
		);
		
		$hide_background_image_meta_container = vibez_elated_add_admin_container(
			array(
				'parent'          => $show_title_area_meta_container,
				'name'            => 'eltdf_hide_background_image_meta_container',
				'hidden_property' => 'eltdf_hide_background_image_meta',
				'hidden_value'    => 'yes'
			)
		);
		
		vibez_elated_create_meta_box_field(
			array(
				'name'        => 'eltdf_title_area_background_image_meta',
				'type'        => 'image',
				'label'       => esc_html__( 'Background Image', 'vibez' ),
				'description' => esc_html__( 'Choose an Image for title area', 'vibez' ),
				'parent'      => $hide_background_image_meta_container
			)
		);
		
		vibez_elated_create_meta_box_field(
			array(
				'name'          => 'eltdf_title_area_background_image_responsive_meta',
				'type'          => 'select',
				'default_value' => '',
				'label'         => esc_html__( 'Background Responsive Image', 'vibez' ),
				'description'   => esc_html__( 'Enabling this option will make Title background image responsive', 'vibez' ),
				'parent'        => $hide_background_image_meta_container,
				'options'       => vibez_elated_get_yes_no_select_array(),
				'args'          => array(
					"dependence" => true,
					"hide"       => array(
						""    => "",
						"no"  => "",
						"yes" => "#eltdf_eltdf_title_area_background_image_responsive_meta_container, #eltdf_eltdf_title_area_height_meta"
					),
					"show"       => array(
						""    => "#eltdf_eltdf_title_area_background_image_responsive_meta_container, #eltdf_eltdf_title_area_height_meta",
						"no"  => "#eltdf_eltdf_title_area_background_image_responsive_meta_container, #eltdf_eltdf_title_area_height_meta",
						"yes" => ""
					)
				)
			)
		);
		
		$title_area_background_image_responsive_meta_container = vibez_elated_add_admin_container(
			array(
				'parent'          => $hide_background_image_meta_container,
				'name'            => 'eltdf_title_area_background_image_responsive_meta_container',
				'hidden_property' => 'eltdf_title_area_background_image_responsive_meta',
				'hidden_value'    => 'yes'
			)
		);
		
		vibez_elated_create_meta_box_field(
			array(
				'name'          => 'eltdf_title_area_background_image_parallax_meta',
				'type'          => 'select',
				'default_value' => '',
				'label'         => esc_html__( 'Background Image in Parallax', 'vibez' ),
				'description'   => esc_html__( 'Enabling this option will make Title background image parallax', 'vibez' ),
				'parent'        => $title_area_background_image_responsive_meta_container,
				'options'       => array(
					''         => esc_html__( 'Default', 'vibez' ),
					'no'       => esc_html__( 'No', 'vibez' ),
					'yes'      => esc_html__( 'Yes', 'vibez' ),
					'yes_zoom' => esc_html__( 'Yes, with zoom out', 'vibez' )
				)
			)
		);
		
		vibez_elated_create_meta_box_field(
			array(
				'name'        => 'eltdf_title_area_height_meta',
				'type'        => 'text',
				'label'       => esc_html__( 'Height', 'vibez' ),
				'description' => esc_html__( 'Set a height for Title Area', 'vibez' ),
				'parent'      => $show_title_area_meta_container,
				'args'        => array(
					'col_width' => 2,
					'suffix'    => 'px'
				)
			)
		);
		
		vibez_elated_create_meta_box_field(
			array(
				'name'          => 'eltdf_title_area_subtitle_meta',
				'type'          => 'text',
				'default_value' => '',
				'label'         => esc_html__( 'Subtitle Text', 'vibez' ),
				'description'   => esc_html__( 'Enter your subtitle text', 'vibez' ),
				'parent'        => $show_title_area_meta_container,
				'args'          => array(
					'col_width' => 6
				)
			)
		);
		
		vibez_elated_create_meta_box_field(
			array(
				'name'        => 'eltdf_subtitle_color_meta',
				'type'        => 'color',
				'label'       => esc_html__( 'Subtitle Color', 'vibez' ),
				'description' => esc_html__( 'Choose a color for subtitle text', 'vibez' ),
				'parent'      => $show_title_area_meta_container
			)
		);
		
		vibez_elated_create_meta_box_field(array(
			'name' => 'eltdf_subtitle_side_padding_meta',
			'type' => 'text',
			'label' => esc_html__('Subtitle Side Padding', 'vibez'),
			'description' => esc_html__('Set left/right padding for subtitle area', 'vibez'),
			'parent' => $show_title_area_meta_container,
			'args' => array(
				'col_width' => 2,
				'suffix' => '%'
			)
		));
	}
	
	add_action( 'vibez_elated_action_meta_boxes_map', 'vibez_elated_map_title_meta', 60 );
}