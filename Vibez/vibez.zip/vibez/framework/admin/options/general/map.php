<?php

if ( ! function_exists( 'vibez_elated_general_options_map' ) ) {
	/**
	 * General options page
	 */
	function vibez_elated_general_options_map() {
		
		vibez_elated_add_admin_page(
			array(
				'slug'  => '',
				'title' => esc_html__( 'General', 'vibez' ),
				'icon'  => 'fa fa-institution'
			)
		);
		
		$panel_design_style = vibez_elated_add_admin_panel(
			array(
				'page'  => '',
				'name'  => 'panel_design_style',
				'title' => esc_html__( 'Design Style', 'vibez' )
			)
		);
		
		vibez_elated_add_admin_field(
			array(
				'name'          => 'google_fonts',
				'type'          => 'font',
				'default_value' => '-1',
				'label'         => esc_html__( 'Google Font Family', 'vibez' ),
				'description'   => esc_html__( 'Choose a default Google font for your site', 'vibez' ),
				'parent'        => $panel_design_style
			)
		);
		
		vibez_elated_add_admin_field(
			array(
				'name'          => 'additional_google_fonts',
				'type'          => 'yesno',
				'default_value' => 'no',
				'label'         => esc_html__( 'Additional Google Fonts', 'vibez' ),
				'parent'        => $panel_design_style,
				'args'          => array(
					"dependence"             => true,
					"dependence_hide_on_yes" => "",
					"dependence_show_on_yes" => "#eltdf_additional_google_fonts_container"
				)
			)
		);
		
		$additional_google_fonts_container = vibez_elated_add_admin_container(
			array(
				'parent'          => $panel_design_style,
				'name'            => 'additional_google_fonts_container',
				'hidden_property' => 'additional_google_fonts',
				'hidden_value'    => 'no'
			)
		);
		
		vibez_elated_add_admin_field(
			array(
				'name'          => 'additional_google_font1',
				'type'          => 'font',
				'default_value' => '-1',
				'label'         => esc_html__( 'Font Family', 'vibez' ),
				'description'   => esc_html__( 'Choose additional Google font for your site', 'vibez' ),
				'parent'        => $additional_google_fonts_container
			)
		);
		
		vibez_elated_add_admin_field(
			array(
				'name'          => 'additional_google_font2',
				'type'          => 'font',
				'default_value' => '-1',
				'label'         => esc_html__( 'Font Family', 'vibez' ),
				'description'   => esc_html__( 'Choose additional Google font for your site', 'vibez' ),
				'parent'        => $additional_google_fonts_container
			)
		);
		
		vibez_elated_add_admin_field(
			array(
				'name'          => 'additional_google_font3',
				'type'          => 'font',
				'default_value' => '-1',
				'label'         => esc_html__( 'Font Family', 'vibez' ),
				'description'   => esc_html__( 'Choose additional Google font for your site', 'vibez' ),
				'parent'        => $additional_google_fonts_container
			)
		);
		
		vibez_elated_add_admin_field(
			array(
				'name'          => 'additional_google_font4',
				'type'          => 'font',
				'default_value' => '-1',
				'label'         => esc_html__( 'Font Family', 'vibez' ),
				'description'   => esc_html__( 'Choose additional Google font for your site', 'vibez' ),
				'parent'        => $additional_google_fonts_container
			)
		);
		
		vibez_elated_add_admin_field(
			array(
				'name'          => 'additional_google_font5',
				'type'          => 'font',
				'default_value' => '-1',
				'label'         => esc_html__( 'Font Family', 'vibez' ),
				'description'   => esc_html__( 'Choose additional Google font for your site', 'vibez' ),
				'parent'        => $additional_google_fonts_container
			)
		);
		
		vibez_elated_add_admin_field(
			array(
				'name'          => 'google_font_weight',
				'type'          => 'checkboxgroup',
				'default_value' => '',
				'label'         => esc_html__( 'Google Fonts Style & Weight', 'vibez' ),
				'description'   => esc_html__( 'Choose a default Google font weights for your site. Impact on page load time', 'vibez' ),
				'parent'        => $panel_design_style,
				'options'       => array(
					'100'       => esc_html__( '100 Thin', 'vibez' ),
					'100italic' => esc_html__( '100 Thin Italic', 'vibez' ),
					'200'       => esc_html__( '200 Extra-Light', 'vibez' ),
					'200italic' => esc_html__( '200 Extra-Light Italic', 'vibez' ),
					'300'       => esc_html__( '300 Light', 'vibez' ),
					'300italic' => esc_html__( '300 Light Italic', 'vibez' ),
					'400'       => esc_html__( '400 Regular', 'vibez' ),
					'400italic' => esc_html__( '400 Regular Italic', 'vibez' ),
					'500'       => esc_html__( '500 Medium', 'vibez' ),
					'500italic' => esc_html__( '500 Medium Italic', 'vibez' ),
					'600'       => esc_html__( '600 Semi-Bold', 'vibez' ),
					'600italic' => esc_html__( '600 Semi-Bold Italic', 'vibez' ),
					'700'       => esc_html__( '700 Bold', 'vibez' ),
					'700italic' => esc_html__( '700 Bold Italic', 'vibez' ),
					'800'       => esc_html__( '800 Extra-Bold', 'vibez' ),
					'800italic' => esc_html__( '800 Extra-Bold Italic', 'vibez' ),
					'900'       => esc_html__( '900 Ultra-Bold', 'vibez' ),
					'900italic' => esc_html__( '900 Ultra-Bold Italic', 'vibez' )
				)
			)
		);
		
		vibez_elated_add_admin_field(
			array(
				'name'          => 'google_font_subset',
				'type'          => 'checkboxgroup',
				'default_value' => '',
				'label'         => esc_html__( 'Google Fonts Subset', 'vibez' ),
				'description'   => esc_html__( 'Choose a default Google font subsets for your site', 'vibez' ),
				'parent'        => $panel_design_style,
				'options'       => array(
					'latin'        => esc_html__( 'Latin', 'vibez' ),
					'latin-ext'    => esc_html__( 'Latin Extended', 'vibez' ),
					'cyrillic'     => esc_html__( 'Cyrillic', 'vibez' ),
					'cyrillic-ext' => esc_html__( 'Cyrillic Extended', 'vibez' ),
					'greek'        => esc_html__( 'Greek', 'vibez' ),
					'greek-ext'    => esc_html__( 'Greek Extended', 'vibez' ),
					'vietnamese'   => esc_html__( 'Vietnamese', 'vibez' )
				)
			)
		);
		
		vibez_elated_add_admin_field(
			array(
				'name'        => 'first_color',
				'type'        => 'color',
				'label'       => esc_html__( 'First Main Color', 'vibez' ),
				'description' => esc_html__( 'Choose the most dominant theme color. Default color is #00bbb3', 'vibez' ),
				'parent'      => $panel_design_style
			)
		);
		
		vibez_elated_add_admin_field(
			array(
				'name'        => 'page_background_color',
				'type'        => 'color',
				'label'       => esc_html__( 'Page Background Color', 'vibez' ),
				'description' => esc_html__( 'Choose the background color for page content. Default color is #ffffff', 'vibez' ),
				'parent'      => $panel_design_style
			)
		);
		
		vibez_elated_add_admin_field(
			array(
				'name'        => 'selection_color',
				'type'        => 'color',
				'label'       => esc_html__( 'Text Selection Color', 'vibez' ),
				'description' => esc_html__( 'Choose the color users see when selecting text', 'vibez' ),
				'parent'      => $panel_design_style
			)
		);
		
		vibez_elated_add_admin_field(
			array(
				'name'          => 'boxed',
				'type'          => 'yesno',
				'default_value' => 'no',
				'label'         => esc_html__( 'Boxed Layout', 'vibez' ),
				'parent'        => $panel_design_style,
				'args'          => array(
					"dependence"             => true,
					"dependence_hide_on_yes" => "",
					"dependence_show_on_yes" => "#eltdf_boxed_container"
				)
			)
		);
		
		$boxed_container = vibez_elated_add_admin_container(
			array(
				'parent'          => $panel_design_style,
				'name'            => 'boxed_container',
				'hidden_property' => 'boxed',
				'hidden_value'    => 'no'
			)
		);
		
		vibez_elated_add_admin_field(
			array(
				'name'        => 'page_background_color_in_box',
				'type'        => 'color',
				'label'       => esc_html__( 'Page Background Color', 'vibez' ),
				'description' => esc_html__( 'Choose the page background color outside box', 'vibez' ),
				'parent'      => $boxed_container
			)
		);
		
		vibez_elated_add_admin_field(
			array(
				'name'        => 'boxed_background_image',
				'type'        => 'image',
				'label'       => esc_html__( 'Background Image', 'vibez' ),
				'description' => esc_html__( 'Choose an image to be displayed in background', 'vibez' ),
				'parent'      => $boxed_container
			)
		);
		
		vibez_elated_add_admin_field(
			array(
				'name'        => 'boxed_pattern_background_image',
				'type'        => 'image',
				'label'       => esc_html__( 'Background Pattern', 'vibez' ),
				'description' => esc_html__( 'Choose an image to be used as background pattern', 'vibez' ),
				'parent'      => $boxed_container
			)
		);
		
		vibez_elated_add_admin_field(
			array(
				'name'          => 'boxed_background_image_attachment',
				'type'          => 'select',
				'default_value' => 'fixed',
				'label'         => esc_html__( 'Background Image Attachment', 'vibez' ),
				'description'   => esc_html__( 'Choose background image attachment', 'vibez' ),
				'parent'        => $boxed_container,
				'options'       => array(
					'fixed'  => esc_html__( 'Fixed', 'vibez' ),
					'scroll' => esc_html__( 'Scroll', 'vibez' )
				)
			)
		);
		
		vibez_elated_add_admin_field(
			array(
				'name'          => 'paspartu',
				'type'          => 'yesno',
				'default_value' => 'no',
				'label'         => esc_html__( 'Passepartout', 'vibez' ),
				'description'   => esc_html__( 'Enabling this option will display passepartout around site content', 'vibez' ),
				'parent'        => $panel_design_style,
				'args'          => array(
					"dependence"             => true,
					"dependence_hide_on_yes" => "",
					"dependence_show_on_yes" => "#eltdf_paspartu_container"
				)
			)
		);
		
		$paspartu_container = vibez_elated_add_admin_container(
			array(
				'parent'          => $panel_design_style,
				'name'            => 'paspartu_container',
				'hidden_property' => 'paspartu',
				'hidden_value'    => 'no'
			)
		);
		
		vibez_elated_add_admin_field(
			array(
				'name'        => 'paspartu_color',
				'type'        => 'color',
				'label'       => esc_html__( 'Passepartout Color', 'vibez' ),
				'description' => esc_html__( 'Choose passepartout color, default value is #ffffff', 'vibez' ),
				'parent'      => $paspartu_container
			)
		);
		
		vibez_elated_add_admin_field(
			array(
				'name'        => 'paspartu_width',
				'type'        => 'text',
				'label'       => esc_html__( 'Passepartout Size', 'vibez' ),
				'description' => esc_html__( 'Enter size amount for passepartout', 'vibez' ),
				'parent'      => $paspartu_container,
				'args'        => array(
					'col_width' => 2,
					'suffix'    => '%'
				)
			)
		);
		
		vibez_elated_add_admin_field(
			array(
				'parent'        => $paspartu_container,
				'type'          => 'yesno',
				'default_value' => 'no',
				'name'          => 'disable_top_paspartu',
				'label'         => esc_html__( 'Disable Top Passepartout', 'vibez' )
			)
		);
		
		vibez_elated_add_admin_field(
			array(
				'name'          => 'initial_content_width',
				'type'          => 'select',
				'default_value' => 'eltdf-grid-1300',
				'label'         => esc_html__( 'Initial Width of Content', 'vibez' ),
				'description'   => esc_html__( 'Choose the initial width of content which is in grid (Applies to pages set to "Default Template" and rows set to "In Grid")', 'vibez' ),
				'parent'        => $panel_design_style,
				'options'       => array(
					'eltdf-grid-1300' => esc_html__( '1300px - default', 'vibez' ),
					'eltdf-grid-1200' => esc_html__( '1200px', 'vibez' ),
					'eltdf-grid-1100' => esc_html__( '1100px', 'vibez' ),
					'eltdf-grid-1000' => esc_html__( '1000px', 'vibez' ),
					'eltdf-grid-800'  => esc_html__( '800px', 'vibez' )
				)
			)
		);
		
		$panel_settings = vibez_elated_add_admin_panel(
			array(
				'page'  => '',
				'name'  => 'panel_settings',
				'title' => esc_html__( 'Settings', 'vibez' )
			)
		);
		
		vibez_elated_add_admin_field(
			array(
				'name'          => 'page_smooth_scroll',
				'type'          => 'yesno',
				'default_value' => 'no',
				'label'         => esc_html__( 'Smooth Scroll', 'vibez' ),
				'description'   => esc_html__( 'Enabling this option will perform a smooth scrolling effect on every page (except on Mac and touch devices)', 'vibez' ),
				'parent'        => $panel_settings
			)
		);
		
		vibez_elated_add_admin_field(
			array(
				'name'          => 'smooth_page_transitions',
				'type'          => 'yesno',
				'default_value' => 'no',
				'label'         => esc_html__( 'Smooth Page Transitions', 'vibez' ),
				'description'   => esc_html__( 'Enabling this option will perform a smooth transition between pages when clicking on links', 'vibez' ),
				'parent'        => $panel_settings,
				'args'          => array(
					"dependence"             => true,
					"dependence_hide_on_yes" => "",
					"dependence_show_on_yes" => "#eltdf_page_transitions_container"
				)
			)
		);
		
		$page_transitions_container = vibez_elated_add_admin_container(
			array(
				'parent'          => $panel_settings,
				'name'            => 'page_transitions_container',
				'hidden_property' => 'smooth_page_transitions',
				'hidden_value'    => 'no'
			)
		);
		
		vibez_elated_add_admin_field(
			array(
				'name'          => 'page_transition_preloader',
				'type'          => 'yesno',
				'default_value' => 'no',
				'label'         => esc_html__( 'Enable Preloading Animation', 'vibez' ),
				'description'   => esc_html__( 'Enabling this option will display an animated preloader while the page content is loading', 'vibez' ),
				'parent'        => $page_transitions_container,
				'args'          => array(
					"dependence"             => true,
					"dependence_hide_on_yes" => "",
					"dependence_show_on_yes" => "#eltdf_page_transition_preloader_container"
				)
			)
		);
		
		$page_transition_preloader_container = vibez_elated_add_admin_container(
			array(
				'parent'          => $page_transitions_container,
				'name'            => 'page_transition_preloader_container',
				'hidden_property' => 'page_transition_preloader',
				'hidden_value'    => 'no'
			)
		);
		
		
		vibez_elated_add_admin_field(
			array(
				'name'   => 'smooth_pt_bgnd_color',
				'type'   => 'color',
				'label'  => esc_html__( 'Page Loader Background Color', 'vibez' ),
				'parent' => $page_transition_preloader_container
			)
		);
		
		$group_pt_spinner_animation = vibez_elated_add_admin_group(
			array(
				'name'        => 'group_pt_spinner_animation',
				'title'       => esc_html__( 'Loader Style', 'vibez' ),
				'description' => esc_html__( 'Define styles for loader spinner animation', 'vibez' ),
				'parent'      => $page_transition_preloader_container
			)
		);
		
		$row_pt_spinner_animation = vibez_elated_add_admin_row(
			array(
				'name'   => 'row_pt_spinner_animation',
				'parent' => $group_pt_spinner_animation
			)
		);
		
		vibez_elated_add_admin_field(
			array(
				'type'          => 'selectsimple',
				'name'          => 'smooth_pt_spinner_type',
				'default_value' => '',
				'label'         => esc_html__( 'Spinner Type', 'vibez' ),
				'parent'        => $row_pt_spinner_animation,
				'options'       => array(
					'rotate_circles'        => esc_html__( 'Rotate Circles', 'vibez' ),
					'pulse'                 => esc_html__( 'Pulse', 'vibez' ),
					'double_pulse'          => esc_html__( 'Double Pulse', 'vibez' ),
					'cube'                  => esc_html__( 'Cube', 'vibez' ),
					'rotating_cubes'        => esc_html__( 'Rotating Cubes', 'vibez' ),
					'stripes'               => esc_html__( 'Stripes', 'vibez' ),
					'wave'                  => esc_html__( 'Wave', 'vibez' ),
					'two_rotating_circles'  => esc_html__( '2 Rotating Circles', 'vibez' ),
					'five_rotating_circles' => esc_html__( '5 Rotating Circles', 'vibez' ),
					'atom'                  => esc_html__( 'Atom', 'vibez' ),
					'clock'                 => esc_html__( 'Clock', 'vibez' ),
					'mitosis'               => esc_html__( 'Mitosis', 'vibez' ),
					'lines'                 => esc_html__( 'Lines', 'vibez' ),
					'fussion'               => esc_html__( 'Fussion', 'vibez' ),
					'wave_circles'          => esc_html__( 'Wave Circles', 'vibez' ),
					'pulse_circles'         => esc_html__( 'Pulse Circles', 'vibez' )
				)
			)
		);
		
		vibez_elated_add_admin_field(
			array(
				'type'          => 'colorsimple',
				'name'          => 'smooth_pt_spinner_color',
				'default_value' => '',
				'label'         => esc_html__( 'Spinner Color', 'vibez' ),
				'parent'        => $row_pt_spinner_animation
			)
		);
		
		vibez_elated_add_admin_field(
			array(
				'name'          => 'page_transition_fadeout',
				'type'          => 'yesno',
				'default_value' => 'no',
				'label'         => esc_html__( 'Enable Fade Out Animation', 'vibez' ),
				'description'   => esc_html__( 'Enabling this option will turn on fade out animation when leaving page', 'vibez' ),
				'parent'        => $page_transitions_container
			)
		);
		
		vibez_elated_add_admin_field(
			array(
				'name'          => 'show_back_button',
				'type'          => 'yesno',
				'default_value' => 'yes',
				'label'         => esc_html__( 'Show "Back To Top Button"', 'vibez' ),
				'description'   => esc_html__( 'Enabling this option will display a Back to Top button on every page', 'vibez' ),
				'parent'        => $panel_settings
			)
		);
		
		vibez_elated_add_admin_field(
			array(
				'name'          => 'responsiveness',
				'type'          => 'yesno',
				'default_value' => 'yes',
				'label'         => esc_html__( 'Responsiveness', 'vibez' ),
				'description'   => esc_html__( 'Enabling this option will make all pages responsive', 'vibez' ),
				'parent'        => $panel_settings
			)
		);
		
		$panel_custom_code = vibez_elated_add_admin_panel(
			array(
				'page'  => '',
				'name'  => 'panel_custom_code',
				'title' => esc_html__( 'Custom Code', 'vibez' )
			)
		);
		
		vibez_elated_add_admin_field(
			array(
				'name'        => 'custom_css',
				'type'        => 'textarea',
				'label'       => esc_html__( 'Custom CSS', 'vibez' ),
				'description' => esc_html__( 'Enter your custom CSS here', 'vibez' ),
				'parent'      => $panel_custom_code
			)
		);
		
		vibez_elated_add_admin_field(
			array(
				'name'        => 'custom_js',
				'type'        => 'textarea',
				'label'       => esc_html__( 'Custom JS', 'vibez' ),
				'description' => esc_html__( 'Enter your custom Javascript here', 'vibez' ),
				'parent'      => $panel_custom_code
			)
		);
		
		$panel_google_api = vibez_elated_add_admin_panel(
			array(
				'page'  => '',
				'name'  => 'panel_google_api',
				'title' => esc_html__( 'Google API', 'vibez' )
			)
		);
		
		vibez_elated_add_admin_field(
			array(
				'name'        => 'google_maps_api_key',
				'type'        => 'text',
				'label'       => esc_html__( 'Google Maps Api Key', 'vibez' ),
				'description' => esc_html__( 'Insert your Google Maps API key here. For instructions on how to create a Google Maps API key, please refer to our to our documentation.', 'vibez' ),
				'parent'      => $panel_google_api
			)
		);
	}
	
	add_action( 'vibez_elated_action_options_map', 'vibez_elated_general_options_map', 1 );
}

if ( ! function_exists( 'vibez_elated_page_general_style' ) ) {
	/**
	 * Function that prints page general inline styles
	 */
	function vibez_elated_page_general_style( $style ) {
		$current_style = '';
		$class_prefix  = vibez_elated_get_unique_page_class( vibez_elated_get_page_id() );
		
		/********** Boxed layout styles - begin **********/
		
		$boxed_background_style = array();
		
		$boxed_page_background_color = vibez_elated_get_meta_field_intersect( 'page_background_color_in_box' );
		if ( ! empty( $boxed_page_background_color ) ) {
			$boxed_background_style['background-color'] = $boxed_page_background_color;
		}
		
		$boxed_page_background_image = vibez_elated_get_meta_field_intersect( 'boxed_background_image' );
		if ( ! empty( $boxed_page_background_image ) ) {
			$boxed_background_style['background-image']    = 'url(' . esc_url( $boxed_page_background_image ) . ')';
			$boxed_background_style['background-position'] = 'center 0px';
			$boxed_background_style['background-repeat']   = 'no-repeat';
		}
		
		$boxed_page_background_pattern_image = vibez_elated_get_meta_field_intersect( 'boxed_pattern_background_image' );
		if ( ! empty( $boxed_page_background_pattern_image ) ) {
			$boxed_background_style['background-image']    = 'url(' . esc_url( $boxed_page_background_pattern_image ) . ')';
			$boxed_background_style['background-position'] = '0px 0px';
			$boxed_background_style['background-repeat']   = 'repeat';
		}
		
		$boxed_page_background_attachment = vibez_elated_get_meta_field_intersect( 'boxed_background_image_attachment' );
		if ( ! empty( $boxed_page_background_attachment ) ) {
			$boxed_background_style['background-attachment'] = $boxed_page_background_attachment;
		}
		
		$boxed_background_selector = $class_prefix . '.eltdf-boxed .eltdf-wrapper';
		
		if ( ! empty( $boxed_background_style ) ) {
			$current_style .= vibez_elated_dynamic_css( $boxed_background_selector, $boxed_background_style );
		}
		
		/********** Boxed layout styles - end **********/
		
		/********** First Main Color styles - begin **********/
		
		$class_prefix_without_space = $class_prefix;
		$class_prefix = $class_prefix . ' ';
		
		$first_main_color = vibez_elated_get_meta_field_intersect('first_color');
		if(!empty($first_main_color)) {
			$color_selector = array(
				$class_prefix . 'h1 a:hover',
				$class_prefix . 'h2 a:hover',
				$class_prefix . 'h3 a:hover',
				$class_prefix . 'h4 a:hover',
				$class_prefix . 'h5 a:hover',
				$class_prefix . 'h6 a:hover',
				$class_prefix . 'a:hover',
				$class_prefix . 'p a:hover',
				$class_prefix . 'blockquote:before',
				$class_prefix . '.eltdf-comment-holder .eltdf-comment-text .replay',
				$class_prefix . '.eltdf-comment-holder .eltdf-comment-text .comment-reply-link',
				$class_prefix . '.eltdf-comment-holder .eltdf-comment-text .comment-edit-link',
				$class_prefix . '.eltdf-comment-holder .eltdf-comment-text .eltdf-comment-date',
				$class_prefix . '.eltdf-comment-holder .eltdf-comment-text #cancel-comment-reply-link',
				$class_prefix . '.eltdf-owl-slider .owl-nav .owl-prev:hover .eltdf-prev-icon',
				$class_prefix . '.eltdf-owl-slider .owl-nav .owl-prev:hover .eltdf-next-icon',
				$class_prefix . '.eltdf-owl-slider .owl-nav .owl-next:hover .eltdf-prev-icon',
				$class_prefix . '.eltdf-owl-slider .owl-nav .owl-next:hover .eltdf-next-icon',
				$class_prefix . '.eltdf-side-menu-button-opener.opened',
				$class_prefix . '.eltdf-side-menu-button-opener:hover',
				$class_prefix . '.eltdf-search-page-holder article.sticky .eltdf-post-title a',
				$class_prefix . '.eltdf-search-cover .eltdf-search-close a:hover',
				$class_prefix . '.eltdf-blog-holder article.sticky .eltdf-post-title a',
				$class_prefix . '.eltdf-blog-holder article .eltdf-post-info-top > div a:hover',
				$class_prefix . '.eltdf-blog-holder article .eltdf-post-read-more-button a',
				$class_prefix . '.eltdf-blog-holder article.format-link .eltdf-post-text .eltdf-post-text-main .eltdf-post-link-preview',
				$class_prefix . '.eltdf-author-description .eltdf-author-description-content .eltdf-author-name a:hover',
				$class_prefix . '.eltdf-author-description .eltdf-author-description-text-holder .eltdf-author-social-icons a:hover',
				$class_prefix . '.eltdf-bl-standard-pagination ul li.eltdf-bl-pag-active a',
				$class_prefix . '.eltdf-blog-single-navigation .eltdf-blog-single-prev:hover',
				$class_prefix . '.eltdf-blog-single-navigation .eltdf-blog-single-next:hover',
				$class_prefix . '.eltdf-related-posts-holder .eltdf-related-post .eltdf-post-info > div a:hover',
				$class_prefix . '.eltdf-blog-list-holder .eltdf-bli-info > div:before',
				$class_prefix . '.eltdf-blog-list-holder .eltdf-bli-info > div a:hover',
				$class_prefix . '.eltdf-blog-list-holder .eltdf-post-read-more-button a',
				$class_prefix . '.eltdf-blog-slider-holder .eltdf-blog-slider-item .eltdf-item-info-section > div a:hover',
				$class_prefix . '.eltdf-blog-holder.eltdf-blog-single article .eltdf-post-info-top > div a:hover',
				$class_prefix . '.eltdf-blog-holder.eltdf-blog-single article .eltdf-post-info-bottom .eltdf-post-info-bottom-left .eltdf-tags a:hover',
				$class_prefix . '.eltdf-author-info-widget .eltdf-aiw-position',
				$class_prefix . '.widget.widget_rss > h4 .rsswidget:hover',
				$class_prefix . '.widget.widget_search button:hover',
				$class_prefix . '.widget.widget_tag_cloud a:hover',
				$class_prefix . '.widget.eltdf-blog-list-widget .eltdf-post-info-date a:hover',
				$class_prefix . '.eltdf-page-footer .widget a:hover',
				$class_prefix . '.eltdf-side-menu .widget a:hover',
				$class_prefix . '.eltdf-page-footer .widget.widget_search button:hover',
				$class_prefix . '.eltdf-side-menu .widget.widget_search button:hover',
				$class_prefix . '.eltdf-page-footer .widget.widget_tag_cloud a:hover',
				$class_prefix . '.eltdf-side-menu .widget.widget_tag_cloud a:hover',
				$class_prefix . '.eltdf-page-footer .widget.widget_rss .eltdf-footer-widget-title .rsswidget:hover',
				$class_prefix . '.eltdf-page-footer .widget.eltdf-blog-list-widget .eltdf-blog-list-holder.eltdf-bl-minimal .eltdf-post-info-date a',
				$class_prefix . '.eltdf-top-bar a:hover',
				$class_prefix . '.eltdf-icon-widget-holder.eltdf-link-with-href:hover .eltdf-icon-text',
				$class_prefix . '.widget.widget_eltdf_twitter_widget .eltdf-twitter-widget.eltdf-twitter-standard li .eltdf-twitter-icon',
				$class_prefix . '.widget.widget_eltdf_twitter_widget .eltdf-twitter-widget.eltdf-twitter-standard li .eltdf-tweet-text a:hover',
				$class_prefix . '.widget.widget_eltdf_twitter_widget .eltdf-twitter-widget.eltdf-twitter-slider li .eltdf-twitter-icon i',
				$class_prefix . '.widget.widget_eltdf_twitter_widget .eltdf-twitter-widget.eltdf-twitter-slider li .eltdf-tweet-text a',
				$class_prefix . '.widget.widget_eltdf_twitter_widget .eltdf-twitter-widget.eltdf-twitter-slider li .eltdf-tweet-text span',
				$class_prefix . '#tribe-events-content-wrapper #tribe-bar-views .tribe-bar-views-list .tribe-bar-views-option.tribe-bar-active a',
				$class_prefix . '#tribe-events-content-wrapper #tribe-bar-views .tribe-bar-views-list .tribe-bar-views-option a:hover',
				$class_prefix . '#tribe-events-content-wrapper #tribe-events-content table.tribe-events-calendar tbody td .tribe-events-month-event-title',
				$class_prefix . '#tribe-events-content-wrapper #tribe-events-content table.tribe-events-calendar tbody .tribe-events-tooltip .tribe-event-duration',
				$class_prefix . '#tribe-events-content-wrapper #tribe-events-content.tribe-events-list .eltdf-events-single-meta-icon',
				$class_prefix . '.eltdf-events-list-item-holder .eltdf-events-list-item-info .eltdf-events-item-info-icon',
				$class_prefix . '.eltdf-tribe-events-single .eltdf-events-single-main-info .eltdf-events-single-title-holder .eltdf-events-single-info-icon',
				$class_prefix . '.eltdf-tribe-events-single .eltdf-events-single-main-content .eltdf-events-single-meta-icon',
				$class_prefix . '.eltdf-ttevents-single .eltdf-ttevents-single-subtitle',
				$class_prefix . '.eltdf-ttevents-single .tt_event_hours li h4:nth-of-type(2)',
				$class_prefix . '.eltdf-ttevents-single .tt_event_items_list li.type_info .tt_event_text',
				$class_prefix . '.eltdf-ttevents-single .tt_event_items_list li:not(.type_info):before',
				$class_prefix . '.eltdf-main-menu ul li a:hover',
				$class_prefix . '.eltdf-drop-down .second .inner ul li.current-menu-ancestor > a',
				$class_prefix . '.eltdf-drop-down .second .inner ul li.current-menu-item > a',
				$class_prefix . '.eltdf-drop-down .wide .second .inner > ul > li.current-menu-ancestor > a',
				$class_prefix . '.eltdf-drop-down .wide .second .inner > ul > li.current-menu-item > a',
				$class_prefix . 'nav.eltdf-fullscreen-menu ul li a:hover',
				$class_prefix . 'nav.eltdf-fullscreen-menu ul li ul li.current-menu-ancestor > a',
				$class_prefix . 'nav.eltdf-fullscreen-menu ul li ul li.current-menu-item > a',
				$class_prefix . 'nav.eltdf-fullscreen-menu > ul > li.eltdf-active-item > a',
				$class_prefix . '.eltdf-mobile-header .eltdf-mobile-menu-opener.eltdf-mobile-menu-opened a',
				$class_prefix . '.eltdf-mobile-header .eltdf-mobile-nav ul li a:hover',
				$class_prefix . '.eltdf-mobile-header .eltdf-mobile-nav ul li h5:hover',
				$class_prefix . '.eltdf-mobile-header .eltdf-mobile-nav ul ul li.current-menu-ancestor > a',
				$class_prefix . '.eltdf-mobile-header .eltdf-mobile-nav ul ul li.current-menu-item > a',
				$class_prefix . '.eltdf-mobile-header .eltdf-mobile-nav .eltdf-grid > ul > li.eltdf-active-item > a',
				$class_prefix . '.eltdf-accordion-holder.eltdf-ac-simple .eltdf-title-holder.ui-state-active',
				$class_prefix . '.eltdf-accordion-holder.eltdf-ac-simple .eltdf-title-holder.ui-state-hover',
				$class_prefix . '.eltdf-accordion-holder.eltdf-ac-simple-arrows .eltdf-title-holder.ui-state-active',
				$class_prefix . '.eltdf-accordion-holder.eltdf-ac-simple-arrows .eltdf-title-holder.ui-state-hover',
				$class_prefix . '.eltdf-banner-holder .eltdf-banner-link-text .eltdf-banner-link-hover span',
				$class_prefix . '.eltdf-btn.eltdf-btn-simple.eltdf-btn-has-animation .eltdf-btn-hover',
				$class_prefix . '.eltdf-btn.eltdf-btn-outline',
				$class_prefix . '.eltdf-countdown.eltdf-light2-skin .countdown-row .countdown-section .countdown-period',
				$class_prefix . '.eltdf-item-showcase-holder .eltdf-is-item .eltdf-is-title-icon',
				$class_prefix . '.eltdf-price-table .eltdf-pt-inner ul li .eltdf-pt-value',
				$class_prefix . '.eltdf-price-table .eltdf-pt-inner ul li .eltdf-pt-price',
				$class_prefix . '.eltdf-team-holder .eltdf-team-social-holder .eltdf-team-icon .eltdf-icon-element:hover',
				$class_prefix . '.eltdf-pl-filter-holder ul li.eltdf-pl-current span',
				$class_prefix . '.eltdf-pl-filter-holder ul li:hover span',
				$class_prefix . '.eltdf-pl-standard-pagination ul li.eltdf-pl-pag-active a',
				$class_prefix . '.eltdf-portfolio-list-holder.eltdf-pl-gallery-overlay article .eltdf-pli-text .eltdf-pli-category-holder a:hover',
				$class_prefix . '.eltdf-ps-navigation .eltdf-ps-prev a:hover',
				$class_prefix . '.eltdf-ps-navigation .eltdf-ps-next a:hover',
				$class_prefix . '.eltdf-testimonials-holder.eltdf-testimonials-boxed .eltdf-testimonials-author-holder .eltdf-testimonial-author',
				$class_prefix . '.eltdf-icon-widget-holder',
				$class_prefix . '.eltdf-side-menu .eltdf-icon-widget-holder:hover'
			);
			
			$woo_color_selector = array();
			if(vibez_elated_is_woocommerce_installed()) {
				$woo_color_selector = array(
					$class_prefix . '.woocommerce-pagination .page-numbers li a:hover',
					$class_prefix . '.woocommerce-pagination .page-numbers li a.current',
					$class_prefix . '.woocommerce-pagination .page-numbers li span:hover',
					$class_prefix . '.woocommerce-pagination .page-numbers li span.current',
					$class_prefix . '.woocommerce-page .eltdf-content .eltdf-quantity-buttons .eltdf-quantity-minus:hover',
					$class_prefix . '.woocommerce-page .eltdf-content .eltdf-quantity-buttons .eltdf-quantity-plus:hover',
					$class_prefix . 'div.woocommerce .eltdf-quantity-buttons .eltdf-quantity-minus:hover',
					$class_prefix . 'div.woocommerce .eltdf-quantity-buttons .eltdf-quantity-plus:hover',
					$class_prefix . '.woocommerce.woocommerce-page .star-rating',
					$class_prefix . '.woocommerce .star-rating',
					$class_prefix . 'ul.products > .product .button:hover',
					$class_prefix . 'ul.products > .product .added_to_cart:hover',
					$class_prefix . 'ul.products > .product .eltdf-pl-category a:hover',
					$class_prefix . 'ul.products > .product .price',
					$class_prefix . '.eltdf-woo-single-page .eltdf-single-product-summary .woocommerce-product-rating .star-rating',
					$class_prefix . '.eltdf-woo-single-page .eltdf-single-product-summary .product_meta > span a:hover',
					$class_prefix . '.widget.woocommerce.widget_layered_nav ul li.chosen a',
					$class_prefix . '.widget.woocommerce.widget_product_tag_cloud .tagcloud a:hover',
					$class_prefix . '.widget.woocommerce.widget_product_search .woocommerce-product-search button:hover',
					$class_prefix . '.woocommerce-page .widget_search button[type="submit"]:hover',
					$class_prefix . '.eltdf-plc-holder .eltdf-plc-item .eltdf-plc-rating',
					$class_prefix . '.eltdf-plc-holder .eltdf-plc-item .eltdf-plc-price',
					$class_prefix . '.eltdf-plc-holder.eltdf-standard-layout .eltdf-plc-item .eltdf-plc-category a:hover',
					$class_prefix . '.eltdf-plc-holder.eltdf-standard-layout .eltdf-plc-item a.button:hover',
					$class_prefix . '.eltdf-pls-holder .eltdf-pls-text .eltdf-pls-rating',
					$class_prefix . '.eltdf-pls-holder .eltdf-pls-text .eltdf-pls-price',
					$class_prefix . '.eltdf-pl-holder .eltdf-pli .eltdf-pli-rating',
					$class_prefix . '.eltdf-pl-holder .eltdf-pli .eltdf-pli-price',
					$class_prefix . '.eltdf-pl-holder .eltdf-pli-inner .eltdf-pli-text-inner .eltdf-pli-category a:hover',
					$class_prefix . '.eltdf-pl-holder .eltdf-pli-inner .eltdf-pli-text-inner .button:hover',
					$class_prefix . '.eltdf-pl-holder .eltdf-pli-inner .eltdf-pli-text-inner .added_to_cart:hover',
					$class_prefix . '.eltdf-pl-holder.eltdf-standard-layout a.button:hover',
					$class_prefix . '.eltdf-shopping-cart-dropdown .eltdf-quantity-holder',
					$class_prefix . '.eltdf-shopping-cart-dropdown .eltdf-cart-bottom .eltdf-subtotal-holder .eltdf-total-amount',
					$class_prefix_without_space . '.eltdf-light-header .eltdf-page-header > div:not(.eltdf-sticky-header):not(.fixed) .eltdf-shopping-cart-holder .eltdf-header-cart:hover'
				);
			}
			
			$color_selector = array_merge($color_selector, $woo_color_selector);
			
			$color_important_selector = array(
				$class_prefix . '.eltdf-author-description.eltdf-author-info-light .eltdf-author-name a:hover',
				$class_prefix . '.eltdf-blog-slider-holder .eltdf-blog-slider-item .eltdf-section-button-holder a:hover',
				$class_prefix . 'table.tt_timetable .event .event_header',
				$class_prefix . 'table.tt_timetable .event a',
				$class_prefix . '.eltdf-fullscreen-menu-opener:hover',
				$class_prefix . '.eltdf-fullscreen-menu-opener.eltdf-fm-opened',
				$class_prefix_without_space . '.eltdf-light-header .eltdf-page-header > div:not(.eltdf-sticky-header):not(.fixed) .eltdf-side-menu-button-opener.opened',
				$class_prefix_without_space . '.eltdf-light-header .eltdf-page-header > div:not(.eltdf-sticky-header):not(.fixed) .eltdf-side-menu-button-opener:hover',
				$class_prefix_without_space . '.eltdf-light-header .eltdf-top-bar .eltdf-side-menu-button-opener.opened',
				$class_prefix_without_space . '.eltdf-light-header .eltdf-top-bar .eltdf-side-menu-button-opener:hover',
				$class_prefix_without_space . '.eltdf-light-header .eltdf-page-header > div:not(.eltdf-sticky-header):not(.fixed) .eltdf-search-opener:hover',
				$class_prefix_without_space . '.eltdf-light-header .eltdf-top-bar .eltdf-search-opener:hover',
				$class_prefix_without_space . '.eltdf-light-header .eltdf-page-header > div:not(.eltdf-sticky-header):not(.fixed) .eltdf-fullscreen-menu-opener:hover',
				$class_prefix_without_space . '.eltdf-light-header .eltdf-page-header > div:not(.eltdf-sticky-header):not(.fixed) .eltdf-fullscreen-menu-opener.eltdf-fm-opened',
				$class_prefix_without_space . '.eltdf-light-header .eltdf-top-bar .eltdf-fullscreen-menu-opener:hover',
				$class_prefix_without_space . '.eltdf-light-header .eltdf-top-bar .eltdf-fullscreen-menu-opener.eltdf-fm-opened'
			);
			
			$background_color_selector = array(
				$class_prefix . '.eltdf-st-loader .pulse',
				$class_prefix . '.eltdf-st-loader .double_pulse .double-bounce1',
				$class_prefix . '.eltdf-st-loader .double_pulse .double-bounce2',
				$class_prefix . '.eltdf-st-loader .cube',
				$class_prefix . '.eltdf-st-loader .rotating_cubes .cube1',
				$class_prefix . '.eltdf-st-loader .rotating_cubes .cube2',
				$class_prefix . '.eltdf-st-loader .stripes > div',
				$class_prefix . '.eltdf-st-loader .wave > div',
				$class_prefix . '.eltdf-st-loader .two_rotating_circles .dot1',
				$class_prefix . '.eltdf-st-loader .two_rotating_circles .dot2',
				$class_prefix . '.eltdf-st-loader .five_rotating_circles .container1 > div',
				$class_prefix . '.eltdf-st-loader .five_rotating_circles .container2 > div',
				$class_prefix . '.eltdf-st-loader .five_rotating_circles .container3 > div',
				$class_prefix . '.eltdf-st-loader .atom .ball-1:before',
				$class_prefix . '.eltdf-st-loader .atom .ball-2:before',
				$class_prefix . '.eltdf-st-loader .atom .ball-3:before',
				$class_prefix . '.eltdf-st-loader .atom .ball-4:before',
				$class_prefix . '.eltdf-st-loader .clock .ball:before',
				$class_prefix . '.eltdf-st-loader .mitosis .ball',
				$class_prefix . '.eltdf-st-loader .lines .line1',
				$class_prefix . '.eltdf-st-loader .lines .line2',
				$class_prefix . '.eltdf-st-loader .lines .line3',
				$class_prefix . '.eltdf-st-loader .lines .line4',
				$class_prefix . '.eltdf-st-loader .fussion .ball',
				$class_prefix . '.eltdf-st-loader .fussion .ball-1',
				$class_prefix . '.eltdf-st-loader .fussion .ball-2',
				$class_prefix . '.eltdf-st-loader .fussion .ball-3',
				$class_prefix . '.eltdf-st-loader .fussion .ball-4',
				$class_prefix . '.eltdf-st-loader .wave_circles .ball',
				$class_prefix . '.eltdf-st-loader .pulse_circles .ball',
				$class_prefix . '#submit_comment',
				$class_prefix . '.post-password-form input[type=\'submit\']',
				$class_prefix . 'input.wpcf7-form-control.wpcf7-submit',
				$class_prefix . '.eltdf-blog-holder article.format-audio .eltdf-blog-audio-holder .mejs-container .mejs-controls > .mejs-time-rail .mejs-time-total .mejs-time-current',
				$class_prefix . '.eltdf-blog-holder article.format-audio .eltdf-blog-audio-holder .mejs-container .mejs-controls > a.mejs-horizontal-volume-slider .mejs-horizontal-volume-current',
				$class_prefix . '.widget #wp-calendar td#today',
				$class_prefix . '#tribe-events-content-wrapper .tribe-bar-filters .tribe-bar-filters-inner > div input[type=submit]',
				$class_prefix . '#tribe-events-content-wrapper #tribe-events-content table.tribe-events-calendar tbody td.tribe-events-present div[id*=tribe-events-daynum-]',
				$class_prefix . '#tribe-events-content-wrapper #tribe-events-content .tribe-events-button',
				$class_prefix . '.eltdf-events-list-item-date-holder',
				$class_prefix . '.eltdf-tribe-events-single .eltdf-events-single-main-info .eltdf-events-single-date-holder',
				$class_prefix . '#tribe-events .eltdf-tribe-events-single .tribe-events-cal-links a.tribe-events-button.tribe-events-gcal',
				$class_prefix . '#tribe-events .eltdf-tribe-events-single .tribe-events-cal-links a.tribe-events-button.tribe-events-ical:hover',
				$class_prefix . '.tt_tabs .tt_tabs_navigation li a',
				$class_prefix . '.widget.upcoming_events_widget .tt_upcoming_event_controls a:hover',
				$class_prefix . '.eltdf-accordion-holder.eltdf-ac-boxed .eltdf-title-holder.ui-state-active',
				$class_prefix . '.eltdf-accordion-holder.eltdf-ac-boxed .eltdf-title-holder.ui-state-hover',
				$class_prefix . '.eltdf-btn.eltdf-btn-solid',
				$class_prefix . '.eltdf-icon-shortcode.eltdf-circle',
				$class_prefix . '.eltdf-icon-shortcode.eltdf-square',
				$class_prefix . '.eltdf-icon-shortcode.eltdf-dropcaps.eltdf-circle',
				$class_prefix . '.eltdf-progress-bar .eltdf-pb-content-holder .eltdf-pb-content',
				$class_prefix . '.eltdf-tabs.eltdf-tabs-standard .eltdf-tabs-nav li.ui-state-active a',
				$class_prefix . '.eltdf-tabs.eltdf-tabs-standard .eltdf-tabs-nav li.ui-state-hover a',
				$class_prefix . '.eltdf-tabs.eltdf-tabs-boxed .eltdf-tabs-nav li.ui-state-active a',
				$class_prefix . '.eltdf-tabs.eltdf-tabs-boxed .eltdf-tabs-nav li.ui-state-hover a'
			);
			
			$woo_background_color_selector = array();
			if(vibez_elated_is_woocommerce_installed()) {
				$woo_background_color_selector = array(
					$class_prefix . '.woocommerce-page .eltdf-content a.button',
					$class_prefix . '.woocommerce-page .eltdf-content a.added_to_cart',
					$class_prefix . '.woocommerce-page .eltdf-content input[type="submit"]',
					$class_prefix . '.woocommerce-page .eltdf-content button[type="submit"]',
					$class_prefix . '.woocommerce-page .eltdf-content .wc-forward:not(.added_to_cart):not(.checkout-button)',
					$class_prefix . 'div.woocommerce a.button',
					$class_prefix . 'div.woocommerce a.added_to_cart',
					$class_prefix . 'div.woocommerce input[type="submit"]',
					$class_prefix . 'div.woocommerce button[type="submit"]',
					$class_prefix . 'div.woocommerce .wc-forward:not(.added_to_cart):not(.checkout-button)',
					$class_prefix . '.woocommerce .eltdf-onsale',
					$class_prefix . '.eltdf-shopping-cart-dropdown .eltdf-cart-bottom .eltdf-view-cart',
					$class_prefix . '.widget.woocommerce.widget_price_filter .price_slider_wrapper .ui-widget-content .ui-slider-handle',
					$class_prefix . '.eltdf-plc-holder .eltdf-plc-item .eltdf-plc-image-outer .eltdf-plc-image .eltdf-plc-onsale',
					$class_prefix . '.eltdf-plc-holder.eltdf-simple-layout .eltdf-plc-item .eltdf-plc-add-to-cart.eltdf-default-skin .button',
					$class_prefix . '.eltdf-plc-holder.eltdf-simple-layout .eltdf-plc-item .eltdf-plc-add-to-cart.eltdf-default-skin .added_to_cart',
					$class_prefix . '.eltdf-plc-holder.eltdf-simple-layout .eltdf-plc-item .eltdf-plc-add-to-cart.eltdf-light-skin .button:hover',
					$class_prefix . '.eltdf-plc-holder.eltdf-simple-layout .eltdf-plc-item .eltdf-plc-add-to-cart.eltdf-light-skin .added_to_cart:hover',
					$class_prefix . '.eltdf-plc-holder.eltdf-simple-layout .eltdf-plc-item .eltdf-plc-add-to-cart.eltdf-dark-skin .button:hover',
					$class_prefix . '.eltdf-plc-holder.eltdf-simple-layout .eltdf-plc-item .eltdf-plc-add-to-cart.eltdf-dark-skin .added_to_cart:hover',
					$class_prefix . '.eltdf-pl-holder .eltdf-pli-inner .eltdf-pli-image .eltdf-pli-onsale',
					$class_prefix . '.eltdf-shopping-cart-holder .eltdf-header-cart .eltdf-cart-info-number'
				);
			}
			
			$background_color_selector = array_merge($background_color_selector, $woo_background_color_selector);
			
			$background_color_important_selector = array(
				$class_prefix . 'table.tt_timetable .tt_tooltip_content',
				$class_prefix . '.eltdf-btn.eltdf-btn-outline:not(.eltdf-btn-custom-hover-bg):hover',
				$class_prefix . '.eltdf-price-table.eltdf-pt-active-item .eltdf-pt-inner'
			);
			
			$border_color_selector = array(
				$class_prefix . '.eltdf-st-loader .pulse_circles .ball',
				$class_prefix . '#submit_comment',
				$class_prefix . '.post-password-form input[type=\'submit\']',
				$class_prefix . 'input.wpcf7-form-control.wpcf7-submit',
				$class_prefix . '#tribe-events-content-wrapper #tribe-events-content .tribe-events-button',
				$class_prefix . '#tribe-events .eltdf-tribe-events-single .tribe-events-cal-links a.tribe-events-button.tribe-events-gcal',
				$class_prefix . '#tribe-events .eltdf-tribe-events-single .tribe-events-cal-links a.tribe-events-button.tribe-events-ical:hover',
				$class_prefix . '.widget.upcoming_events_widget .tt_upcoming_event_controls a:hover',
				$class_prefix . '.eltdf-btn.eltdf-btn-solid',
				$class_prefix . '.eltdf-btn.eltdf-btn-outline',
				$class_prefix . '.eltdf-main-menu .eltdf-main-menu-line'
			);
			
			$woo_border_color_selector = array();
			if(vibez_elated_is_woocommerce_installed()) {
				$woo_border_color_selector = array(
					$class_prefix . '.woocommerce-page .eltdf-content a.button',
					$class_prefix . '.woocommerce-page .eltdf-content a.added_to_cart',
					$class_prefix . '.woocommerce-page .eltdf-content input[type="submit"]',
					$class_prefix . '.woocommerce-page .eltdf-content button[type="submit"]',
					$class_prefix . '.woocommerce-page .eltdf-content .wc-forward:not(.added_to_cart):not(.checkout-button)',
					$class_prefix . 'div.woocommerce a.button',
					$class_prefix . 'div.woocommerce a.added_to_cart',
					$class_prefix . 'div.woocommerce input[type="submit"]',
					$class_prefix . 'div.woocommerce button[type="submit"]',
					$class_prefix . 'div.woocommerce .wc-forward:not(.added_to_cart):not(.checkout-button)',
					$class_prefix . '.eltdf-woo-single-page .eltdf-single-product-summary .price del:before',
					$class_prefix . '.eltdf-plc-holder .eltdf-plc-item .eltdf-plc-price del:before',
					$class_prefix . '.eltdf-plc-holder.eltdf-simple-layout .eltdf-plc-item .eltdf-plc-add-to-cart.eltdf-default-skin .button',
					$class_prefix . '.eltdf-plc-holder.eltdf-simple-layout .eltdf-plc-item .eltdf-plc-add-to-cart.eltdf-default-skin .added_to_cart',
					$class_prefix . '.eltdf-pls-holder .eltdf-pls-text .eltdf-pls-price del:before',
					$class_prefix . '.eltdf-pl-holder .eltdf-pli .eltdf-pli-price del:before'
				);
			}
			
			$border_color_selector = array_merge($border_color_selector, $woo_border_color_selector);
			
			$border_color_important_selector = array(
				$class_prefix . '.eltdf-btn.eltdf-btn-outline:not(.eltdf-btn-custom-border-hover):hover'
			);

			$border_bottom_color_selector = array(
				$class_prefix . '#eltdf-back-to-top .eltdf-btt-triangle'
			);

			$current_style .= vibez_elated_dynamic_css('::selection', array('background' => $first_main_color));
			$current_style .= vibez_elated_dynamic_css('::-moz-selection', array('background' => $first_main_color));
			
			$current_style .= vibez_elated_dynamic_css($color_selector, array('color' => $first_main_color));
			$current_style .= vibez_elated_dynamic_css($color_important_selector, array('color' => $first_main_color.'!important'));
			$current_style .= vibez_elated_dynamic_css($background_color_selector, array('background-color' => $first_main_color));
			$current_style .= vibez_elated_dynamic_css($background_color_important_selector, array('background-color' => $first_main_color.'!important'));
			$current_style .= vibez_elated_dynamic_css($border_color_selector, array('border-color' => $first_main_color));
			$current_style .= vibez_elated_dynamic_css($border_color_important_selector, array('border-color' => $first_main_color.'!important'));
			$current_style .= vibez_elated_dynamic_css($border_bottom_color_selector, array('border-bottom-color' => $first_main_color));
		}
		
		/********** First Main Color styles - begin **********/
		
		$current_style = $current_style . $style;
		
		return $current_style;
	}
	
	add_filter( 'vibez_elated_filter_add_page_custom_style', 'vibez_elated_page_general_style' );
}