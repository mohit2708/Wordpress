<li class="eltdf-bl-item clearfix">
	<div class="eltdf-bli-inner">
        <?php vibez_elated_get_module_template_part('templates/parts/image', 'blog', '', $params); ?>
		
		<div class="eltdf-bli-content">
			<?php vibez_elated_get_module_template_part('templates/parts/title', 'blog', '', $params); ?>
			<?php vibez_elated_get_module_template_part('templates/parts/post-info/date', 'blog', '', $params); ?>
		</div>
	</div>
</li>