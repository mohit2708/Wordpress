<li class="eltdf-bl-item clearfix">
	<div class="eltdf-bli-inner">
		<div class="eltdf-bli-content">
			<?php vibez_elated_get_module_template_part('templates/parts/post-info/date', 'blog', '', $params); ?>
			<?php vibez_elated_get_module_template_part('templates/parts/title', 'blog', '', $params); ?>
		</div>
	</div>
</li>