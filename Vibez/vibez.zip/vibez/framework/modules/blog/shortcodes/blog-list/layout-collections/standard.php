<li class="eltdf-bl-item clearfix">
	<div class="eltdf-bli-inner">
        <?php vibez_elated_get_module_template_part('templates/parts/image', 'blog', '', $params); ?>

        <div class="eltdf-bli-content">
            <?php
            if($post_info_section == 'yes') { ?>
                <div class="eltdf-bli-info">
	                <?php
	                    if ($post_info_date == 'yes') {
	                        vibez_elated_get_module_template_part('templates/parts/post-info/date', 'blog', '', $params);
	                    }
		                if ($post_info_author == 'yes') {
			                vibez_elated_get_module_template_part('templates/parts/post-info/author', 'blog', '', $params);
		                }
		                if ($post_info_category == 'yes') {
			                vibez_elated_get_module_template_part('templates/parts/post-info/category', 'blog', '', $params);
		                }
		                if ($post_info_comments == 'yes') {
			                vibez_elated_get_module_template_part('templates/parts/post-info/comments', 'blog', '', $params);
		                }
		                if ($post_info_like == 'yes') {
			                vibez_elated_get_module_template_part('templates/parts/post-info/like', 'blog', '', $params);
		                }
	                ?>
                </div>
	            <?php vibez_elated_get_module_template_part('templates/parts/title', 'blog', '', $params); ?>
            <?php } ?>
            <div class="eltdf-bli-excerpt">
                <?php vibez_elated_get_module_template_part('templates/parts/excerpt', 'blog', '', $params); ?>
                <?php vibez_elated_get_module_template_part('templates/parts/post-info/read-more', 'blog', '', $params); ?>
            </div>
        </div>
	</div>
</li>