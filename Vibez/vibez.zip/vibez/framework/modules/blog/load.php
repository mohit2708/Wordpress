<?php

include_once ELATED_FRAMEWORK_MODULES_ROOT_DIR.'/blog/options-map/map.php';
include_once ELATED_FRAMEWORK_MODULES_ROOT_DIR.'/blog/blog-functions.php';
include_once ELATED_FRAMEWORK_MODULES_ROOT_DIR.'/blog/shortcodes/shortcodes-functions.php';