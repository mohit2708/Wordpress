<?php
if(vibez_elated_show_comments()){
    comments_template('', true);
}