<div class="eltdf-blog-like">
	<?php if( function_exists('vibez_elated_get_like') ) vibez_elated_get_like(); ?>
</div>