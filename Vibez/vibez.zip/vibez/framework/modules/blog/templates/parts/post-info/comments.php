<?php if(comments_open()) { ?>
<div class="eltdf-post-info-comments-holder">
    <a itemprop="url" class="eltdf-post-info-comments" href="<?php comments_link(); ?>" target="_self">
        <?php comments_number('0 ' . esc_html__('Comments','vibez'), '1 '.esc_html__('Comment','vibez'), '% '.esc_html__('Comments','vibez') ); ?>
    </a>
</div>
<?php } ?>