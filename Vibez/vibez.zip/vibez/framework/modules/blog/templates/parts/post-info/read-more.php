<?php if ( ! vibez_elated_post_has_read_more() ) { ?>
	<div class="eltdf-post-read-more-button">
	<?php
	    if(vibez_elated_core_plugin_installed()) {
	        echo vibez_elated_get_button_html(
	            apply_filters(
	                'vibez_elated_filter_blog_template_read_more_button',
		            array(
			            'type'         => 'simple',
			            'size'         => 'medium',
			            'icon_pack'    => 'linear_icons',
			            'linear_icon'  => 'lnr-arrow-right',
			            'link'         => get_the_permalink(),
			            'text'         => esc_html__( 'READ MORE', 'vibez' ),
			            'custom_class' => 'eltdf-blog-list-button'
		            )
	            )
	        );
	    } else { ?>
	        <a itemprop="url" href="<?php echo esc_url(get_the_permalink()); ?>" target="_self" class="eltdf-btn eltdf-btn-medium eltdf-btn-simple eltdf-blog-list-button">
	            <span class="eltdf-btn-text">
	                <?php echo esc_html__('READ MORE', 'vibez'); ?>
	            </span>
	        </a>
	<?php } ?>
	</div>
<?php } ?>