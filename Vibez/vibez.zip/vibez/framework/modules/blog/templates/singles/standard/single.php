<?php

vibez_elated_get_single_post_format_html($blog_single_type);

vibez_elated_get_module_template_part('templates/parts/single/author-info', 'blog');

vibez_elated_get_module_template_part('templates/parts/single/single-navigation', 'blog');

vibez_elated_get_module_template_part('templates/parts/single/related-posts', 'blog', '', $single_info_params);

vibez_elated_get_module_template_part('templates/parts/single/comments', 'blog');