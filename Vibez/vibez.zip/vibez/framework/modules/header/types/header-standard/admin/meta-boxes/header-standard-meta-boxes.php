<?php

if ( ! function_exists( 'vibez_elated_get_hide_dep_for_header_standard_meta_boxes' ) ) {
	function vibez_elated_get_hide_dep_for_header_standard_meta_boxes() {
		$hide_dep_options = apply_filters( 'vibez_elated_filter_header_standard_hide_meta_boxes', $hide_dep_options = array() );
		
		return $hide_dep_options;
	}
}

if ( ! function_exists( 'vibez_elated_header_standard_meta_map' ) ) {
	function vibez_elated_header_standard_meta_map( $parent ) {
		$hide_dep_options = vibez_elated_get_hide_dep_for_header_standard_meta_boxes();
		
		vibez_elated_create_meta_box_field(
			array(
				'parent'          => $parent,
				'type'            => 'select',
				'name'            => 'eltdf_set_menu_area_position_meta',
				'default_value'   => '',
				'label'           => esc_html__( 'Choose Menu Area Position', 'vibez' ),
				'description'     => esc_html__( 'Select menu area position in your header', 'vibez' ),
				'options'         => array(
					''       => esc_html__( 'Default', 'vibez' ),
					'left'   => esc_html__( 'Left', 'vibez' ),
					'right'  => esc_html__( 'Right', 'vibez' ),
					'center' => esc_html__( 'Center', 'vibez' )
				),
				'hidden_property' => 'eltdf_header_type_meta',
				'hidden_values'   => $hide_dep_options
			)
		);
	}
	
	add_action( 'vibez_elated_action_additional_header_area_meta_boxes_map', 'vibez_elated_header_standard_meta_map' );
}