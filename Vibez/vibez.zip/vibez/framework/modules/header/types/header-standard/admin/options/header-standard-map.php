<?php

if ( ! function_exists( 'vibez_elated_get_hide_dep_for_header_standard_options' ) ) {
	function vibez_elated_get_hide_dep_for_header_standard_options() {
		$hide_dep_options = apply_filters( 'vibez_elated_filter_header_standard_hide_global_option', $hide_dep_options = array() );
		
		return $hide_dep_options;
	}
}

if ( ! function_exists( 'vibez_elated_header_standard_map' ) ) {
	function vibez_elated_header_standard_map( $parent ) {
		$hide_dep_options = vibez_elated_get_hide_dep_for_header_standard_options();
		
		vibez_elated_add_admin_field(
			array(
				'parent'          => $parent,
				'type'            => 'select',
				'name'            => 'set_menu_area_position',
				'default_value'   => 'right',
				'label'           => esc_html__( 'Choose Menu Area Position', 'vibez' ),
				'description'     => esc_html__( 'Select menu area position in your header', 'vibez' ),
				'options'         => array(
					'right'  => esc_html__( 'Right', 'vibez' ),
					'left'   => esc_html__( 'Left', 'vibez' ),
					'center' => esc_html__( 'Center', 'vibez' )
				),
				'hidden_property' => 'header_type',
				'hidden_values'   => $hide_dep_options
			)
		);
	}
	
	add_action( 'vibez_elated_action_additional_header_menu_area_options_map', 'vibez_elated_header_standard_map' );
}