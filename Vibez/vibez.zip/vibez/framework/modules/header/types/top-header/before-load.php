<?php

if ( ! function_exists( 'vibez_elated_set_show_dep_options_for_top_header' ) ) {
	/**
	 * This function is used to show this header type specific containers/panels for admin options when another header type is selected
	 */
	function vibez_elated_set_show_dep_options_for_top_header( $show_dep_options ) {
		$show_dep_options[] = '#eltdf_top_header_container';
		
		return $show_dep_options;
	}
	
	// show top header container for global options
	add_filter( 'vibez_elated_filter_show_dep_options_for_header_centered', 'vibez_elated_set_show_dep_options_for_top_header' );
	add_filter( 'vibez_elated_filter_show_dep_options_for_header_minimal', 'vibez_elated_set_show_dep_options_for_top_header' );
	add_filter( 'vibez_elated_filter_show_dep_options_for_header_standard', 'vibez_elated_set_show_dep_options_for_top_header' );
	
	// show top header container for meta boxes
	add_filter( 'vibez_elated_filter_show_dep_options_for_header_centered_meta_boxes', 'vibez_elated_set_show_dep_options_for_top_header' );
	add_filter( 'vibez_elated_filter_show_dep_options_for_header_minimal_meta_boxes', 'vibez_elated_set_show_dep_options_for_top_header' );
	add_filter( 'vibez_elated_filter_show_dep_options_for_header_standard_meta_boxes', 'vibez_elated_set_show_dep_options_for_top_header' );
}