<?php

if ( ! function_exists( 'vibez_elated_logo_meta_box_map' ) ) {
	function vibez_elated_logo_meta_box_map() {
		
		$logo_meta_box = vibez_elated_create_meta_box(
			array(
				'scope' => apply_filters( 'vibez_elated_filter_set_scope_for_meta_boxes', array( 'page', 'post' ) ),
				'title' => esc_html__( 'Logo', 'vibez' ),
				'name'  => 'logo_meta'
			)
		);
		
		vibez_elated_create_meta_box_field(
			array(
				'name'        => 'eltdf_logo_image_meta',
				'type'        => 'image',
				'label'       => esc_html__( 'Logo Image - Default', 'vibez' ),
				'description' => esc_html__( 'Choose a default logo image to display ', 'vibez' ),
				'parent'      => $logo_meta_box
			)
		);
		
		vibez_elated_create_meta_box_field(
			array(
				'name'        => 'eltdf_logo_image_dark_meta',
				'type'        => 'image',
				'label'       => esc_html__( 'Logo Image - Dark', 'vibez' ),
				'description' => esc_html__( 'Choose a default logo image to display ', 'vibez' ),
				'parent'      => $logo_meta_box
			)
		);
		
		vibez_elated_create_meta_box_field(
			array(
				'name'        => 'eltdf_logo_image_light_meta',
				'type'        => 'image',
				'label'       => esc_html__( 'Logo Image - Light', 'vibez' ),
				'description' => esc_html__( 'Choose a default logo image to display ', 'vibez' ),
				'parent'      => $logo_meta_box
			)
		);
		
		vibez_elated_create_meta_box_field(
			array(
				'name'        => 'eltdf_logo_image_sticky_meta',
				'type'        => 'image',
				'label'       => esc_html__( 'Logo Image - Sticky', 'vibez' ),
				'description' => esc_html__( 'Choose a default logo image to display ', 'vibez' ),
				'parent'      => $logo_meta_box
			)
		);
		
		vibez_elated_create_meta_box_field(
			array(
				'name'        => 'eltdf_logo_image_mobile_meta',
				'type'        => 'image',
				'label'       => esc_html__( 'Logo Image - Mobile', 'vibez' ),
				'description' => esc_html__( 'Choose a default logo image to display ', 'vibez' ),
				'parent'      => $logo_meta_box
			)
		);
	}
	
	add_action( 'vibez_elated_action_meta_boxes_map', 'vibez_elated_logo_meta_box_map', 47 );
}