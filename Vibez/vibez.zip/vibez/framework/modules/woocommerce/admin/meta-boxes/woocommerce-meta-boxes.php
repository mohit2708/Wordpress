<?php

if(!function_exists('vibez_elated_map_woocommerce_meta')) {
    function vibez_elated_map_woocommerce_meta() {
        $woocommerce_meta_box = vibez_elated_create_meta_box(
            array(
                'scope' => array('product'),
                'title' => esc_html__('Product Meta', 'vibez'),
                'name' => 'woo_product_meta'
            )
        );

        vibez_elated_create_meta_box_field(array(
            'name'        => 'eltdf_product_featured_image_size',
            'type'        => 'select',
            'label'       => esc_html__('Dimensions for Product List Shortcode', 'vibez'),
            'description' => esc_html__('Choose image layout when it appears in Elated Product List - Masonry layout shortcode', 'vibez'),
            'parent'      => $woocommerce_meta_box,
            'options'     => array(
                'eltdf-woo-image-normal-width' => esc_html__('Default', 'vibez'),
                'eltdf-woo-image-large-width'  => esc_html__('Large Width', 'vibez')
            )
        ));

        vibez_elated_create_meta_box_field(
            array(
                'name'          => 'eltdf_show_title_area_woo_meta',
                'type'          => 'select',
                'default_value' => '',
                'label'         => esc_html__('Show Title Area', 'vibez'),
                'description'   => esc_html__('Disabling this option will turn off page title area', 'vibez'),
                'parent'        => $woocommerce_meta_box,
                'options'       => vibez_elated_get_yes_no_select_array()
            )
        );
    }
	
    add_action('vibez_elated_action_meta_boxes_map', 'vibez_elated_map_woocommerce_meta', 99);
}