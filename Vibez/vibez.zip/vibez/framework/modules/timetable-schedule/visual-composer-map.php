<?php

if ( vibez_elated_visual_composer_installed() ) {
	if ( ! function_exists( 'vibez_elated_ttsingle_hours_vc_map' ) ) {
		function vibez_elated_ttsingle_hours_vc_map() {
			vc_map(
				array(
					'name'                      => esc_html__( 'Elated Timetable Event Hours', 'vibez' ),
					'base'                      => 'tt_event_hours',
					'category'                  => esc_html__( 'by ELATED', 'vibez' ),
					'icon'                      => 'icon-a-wpb-timetable-events-hours extended-custom-icon',
					'allowed_container_element' => 'vc_row'
				)
			);
		}
		
		add_action( 'vc_before_init', 'vibez_elated_ttsingle_hours_vc_map' );
	}
	
	if ( ! function_exists( 'vibez_elated_ttsingle_info_holder' ) ) {
		function vibez_elated_ttsingle_info_holder() {
			vc_map(
				array(
					"name"            => esc_html__( 'Elated Timetable Event Info Holder', 'vibez' ),
					'base'            => 'tt_items_list',
					'category'        => esc_html__( 'by ELATED', 'vibez' ),
					'as_parent'       => array( 'only' => 'tt_item' ),
					'icon'            => 'icon-wpb-a-timetable-event-info-holder extended-custom-icon',
					'content_element' => true,
					'js_view'         => 'VcColumnView'
				)
			);
		}
		
		add_action( 'vc_before_init', 'vibez_elated_ttsingle_info_holder', 10 );
	}
	
	if ( ! function_exists( 'vibez_elated_ttsingle_info_table_item' ) ) {
		function vibez_elated_ttsingle_info_table_item() {
			vc_map(
				array(
					'name'      => esc_html__( 'Elated Timetable Event Info Table Item', 'vibez' ),
					'base'      => 'tt_item',
					'as_child'  => array( 'only' => 'tt_items_list' ),
					'as_parent' => array( 'except' => 'vc_row, vc_accordion' ),
					'icon'      => 'icon-wpb-a-timetable-event-info-table-item extended-custom-icon',
					'category'  => esc_html__( 'by ELATED', 'vibez' ),
					'params'    => array(
						array(
							'type'       => 'textfield',
							'param_name' => 'content',
							'heading'    => esc_html__( 'Label', 'vibez' )
						),
						array(
							'type'       => 'textfield',
							'param_name' => 'value',
							'heading'    => esc_html__( 'Value', 'vibez' )
						),
						array(
							'type'        => 'dropdown',
							'param_name'  => 'type',
							'heading'     => esc_html__( 'Type', 'vibez' ),
							'value'       => array(
								esc_html__( 'Table', 'vibez' ) => 'info'
							),
							'save_always' => true
						)
					)
				)
			);
		}
		
		add_action( 'vc_before_init', 'vibez_elated_ttsingle_info_table_item', 11 );
	}
	
	class WPBakeryShortCode_Tt_Items_List extends WPBakeryShortCodesContainer {}
}