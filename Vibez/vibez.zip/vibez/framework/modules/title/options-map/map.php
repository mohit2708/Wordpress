<?php

if ( ! function_exists('vibez_elated_title_options_map') ) {

	function vibez_elated_title_options_map() {

		vibez_elated_add_admin_page(
			array(
				'slug' => '_title_page',
				'title' => esc_html__('Title', 'vibez'),
				'icon' => 'fa fa-list-alt'
			)
		);

		$panel_title = vibez_elated_add_admin_panel(
			array(
				'page' => '_title_page',
				'name' => 'panel_title',
				'title' => esc_html__('Title Settings', 'vibez')
			)
		);

		vibez_elated_add_admin_field(
			array(
				'name' => 'show_title_area',
				'type' => 'yesno',
				'default_value' => 'yes',
				'label' => esc_html__('Show Title Area', 'vibez'),
				'description' => esc_html__('This option will enable/disable Title Area', 'vibez'),
				'parent' => $panel_title,
				'args' => array(
					"dependence" => true,
					"dependence_hide_on_yes" => "",
					"dependence_show_on_yes" => "#eltdf_show_title_area_container"
				)
			)
		);

		$show_title_area_container = vibez_elated_add_admin_container(
			array(
				'parent' => $panel_title,
				'name' => 'show_title_area_container',
				'hidden_property' => 'show_title_area',
				'hidden_value' => 'no'
			)
		);

		vibez_elated_add_admin_field(
			array(
				'name' => 'title_area_type',
				'type' => 'select',
				'default_value' => 'standard',
				'label' => esc_html__('Title Area Type', 'vibez'),
				'description' => esc_html__('Choose title type', 'vibez'),
				'parent' => $show_title_area_container,
				'options' => array(
					'standard' => esc_html__('Standard', 'vibez'),
					'split-columns' => esc_html__('Split Columns', 'vibez'),
					'breadcrumb' => esc_html__('Breadcrumb', 'vibez')
				),
				'args' => array(
					'dependence' => true,
					'hide' => array(
						'standard' => '#eltdf_title_area_split_type_container',
						'split-columns' => '#eltdf_title_area_type_container',
						'breadcrumb' => '#eltdf_title_area_type_container, #eltdf_title_area_split_type_container'
					),
					'show' => array(
						'standard' => '#eltdf_title_area_type_container',
						'split-columns' => '#eltdf_title_area_split_type_container',
						'breadcrumb' => ''
					)
				)
			)
		);

		$title_area_type_container = vibez_elated_add_admin_container(
			array(
				'parent' => $show_title_area_container,
				'name' => 'title_area_type_container',
				'hidden_property' => 'title_area_type',
				'hidden_values' => array(
					'split-columns',
					'breadcrumb'
				)
			)
		);

			vibez_elated_add_admin_field(
				array(
					'name' => 'title_area_enable_breadcrumbs',
					'type' => 'yesno',
					'default_value' => 'no',
					'label' => esc_html__('Enable Breadcrumbs', 'vibez'),
					'description' => esc_html__('This option will display Breadcrumbs in Title Area', 'vibez'),
					'parent' => $title_area_type_container,
				)
			);
		
		$title_area_split_type_container = vibez_elated_add_admin_container(
			array(
				'parent' => $show_title_area_container,
				'name' => 'title_area_split_type_container',
				'hidden_property' => 'title_area_type',
				'hidden_values' => array(
					'standard',
					'breadcrumb'
				)
			)
		);
		
			vibez_elated_add_admin_field(
				array(
					'name'          => 'title_area_title_text_position',
					'type'          => 'select',
					'default_value' => 'title-left',
					'label'         => esc_html__( 'Title Text Position', 'vibez' ),
					'parent'        => $title_area_split_type_container,
					'options'       => array(
						'title-left'  => esc_html__( 'Title Left - Subtitle Right', 'vibez' ),
						'title-right' => esc_html__( 'Title Right - Subtitle Left', 'vibez' )
					)
				)
			);
		
			vibez_elated_add_admin_field(array(
				'name' => 'title_area_title_light_words',
				'type' => 'text',
				'label' => esc_html__('Words with Light Font Weight', 'vibez'),
				'description' => esc_html__('Enter the positions of the words you would like to display in a "light" font weight. Separate the positions with commas (e.g. if you would like the first, third, and fourth word to have a light font weight, you would enter "1,3,4")', 'vibez'),
				'parent' => $title_area_split_type_container,
				'args' => array(
					'col_width' => 3
				)
			));
		
			vibez_elated_add_admin_field(array(
				'name' => 'title_area_title_break_words',
				'type' => 'text',
				'label' => esc_html__('Position of Line Break', 'vibez'),
				'description' => esc_html__('Enter the position of the word after which you would like to create a line break (e.g. if you would like the line break after the 3rd word, you would enter "3")', 'vibez'),
				'parent' => $title_area_split_type_container,
				'args' => array(
					'col_width' => 3
				)
			));
		
			vibez_elated_add_admin_field(
				array(
					'name'          => 'title_area_disable_break_words',
					'type'          => 'yesno',
					'default_value' => 'no',
					'label'         => esc_html__('Disable Line Break for Smaller Screens', 'vibez'),
					'parent'        => $title_area_split_type_container
				)
			);
		
		vibez_elated_add_admin_field(
			array(
				'name'          => 'title_enable_arrows_animation',
				'type'          => 'yesno',
				'default_value' => 'no',
				'label'         => esc_html__( 'Enable Arrows Background Animation', 'vibez' ),
				'parent'        => $show_title_area_container,
				'args' => array(
					'dependence' => true,
					'dependence_hide_on_yes' => '#eltdf_title_area_arrows_container',
					'dependence_show_on_yes' => '#eltdf_title_area_arrows_container'
				)
			)
		);
		
		$title_area_arrows_container = vibez_elated_add_admin_container(
			array(
				'parent'          => $show_title_area_container,
				'name'            => 'title_area_arrows_container',
				'hidden_property' => 'title_enable_arrows_animation',
				'hidden_value'    => 'no'
			)
		);
		
			vibez_elated_add_admin_field(
				array(
					'name'          => 'title_area_arrows_skin',
					'type'          => 'select',
					'default_value' => 'green',
					'label'         => esc_html__( 'Arrows Skin', 'vibez' ),
					'parent'        => $title_area_arrows_container,
					'options'       => array(
						'green' => esc_html__( 'Green', 'vibez' ),
						'white' => esc_html__( 'White', 'vibez' ),
						'black' => esc_html__( 'Black', 'vibez' ),
						'gray'  => esc_html__( 'Gray', 'vibez' )
					)
				)
			);
			
			vibez_elated_add_admin_field(
				array(
					'name'          => 'title_area_arrows_position',
					'type'          => 'select',
					'default_value' => 'right',
					'label'         => esc_html__( 'Arrows Position', 'vibez' ),
					'parent'        => $title_area_arrows_container,
					'options'       => array(
						'right' => esc_html__( 'Right', 'vibez' ),
						'left'  => esc_html__( 'Left', 'vibez' )
					)
				)
			);
		
			vibez_elated_add_admin_field(
				array(
					'name'    => 'title_area_disable_arrows_animation',
					'type'    => 'select',
					'default_value' => '',
					'label'   => esc_html__( 'Disable Arrows Animation', 'vibez' ),
					'description' => esc_html__( 'Choose on which stage you hide title area arrows animation', 'vibez' ),
					'parent'  => $title_area_arrows_container,
					'options' => array(
						''      => esc_html__( 'Never', 'vibez' ),
						'1280'  => esc_html__( 'Below 1280px', 'vibez' ),
						'1024'  => esc_html__( 'Below 1024px', 'vibez' ),
						'768'   => esc_html__( 'Below 768px', 'vibez' ),
						'680'   => esc_html__( 'Below 680px', 'vibez' ),
						'480'   => esc_html__( 'Below 480px', 'vibez' )
					)
				)
			);
		
		vibez_elated_add_admin_field(
			array(
				'name' => 'title_area_title_tag',
				'type' => 'select',
				'default_value' => 'h1',
				'label' => esc_html__('Title Tag', 'vibez'),
				'parent' => $show_title_area_container,
				'options' => vibez_elated_get_title_tag()
			)
		);

		vibez_elated_add_admin_field(
			array(
				'name' => 'title_area_vertical_alignment',
				'type' => 'select',
				'default_value' => 'header_bottom',
				'label' => esc_html__('Vertical Alignment', 'vibez'),
				'description' => esc_html__('Specify title vertical alignment', 'vibez'),
				'parent' => $show_title_area_container,
				'options' => array(
					'header_bottom' => esc_html__('From Bottom of Header', 'vibez'),
					'window_top' => esc_html__('From Window Top', 'vibez')
				)
			)
		);

		vibez_elated_add_admin_field(
			array(
				'name' => 'title_area_content_alignment',
				'type' => 'select',
				'default_value' => 'left',
				'label' => esc_html__('Horizontal Alignment', 'vibez'),
				'description' => esc_html__('Specify title horizontal alignment', 'vibez'),
				'parent' => $show_title_area_container,
				'options' => array(
					'left' => esc_html__('Left', 'vibez'),
					'center' => esc_html__('Center', 'vibez'),
					'right' => esc_html__('Right', 'vibez')
				)
			)
		);

		vibez_elated_add_admin_field(
			array(
				'name' => 'title_area_background_color',
				'type' => 'color',
				'label' => esc_html__('Background Color', 'vibez'),
				'description' => esc_html__('Choose a background color for Title Area', 'vibez'),
				'parent' => $show_title_area_container
			)
		);

		vibez_elated_add_admin_field(
			array(
				'name' => 'title_area_background_image',
				'type' => 'image',
				'label' => esc_html__('Background Image', 'vibez'),
				'description' => esc_html__('Choose an Image for Title Area', 'vibez'),
				'parent' => $show_title_area_container
			)
		);

		vibez_elated_add_admin_field(
			array(
				'name' => 'title_area_background_image_responsive',
				'type' => 'yesno',
				'default_value' => 'no',
				'label' => esc_html__('Background Responsive Image', 'vibez'),
				'description' => esc_html__('Enabling this option will make Title background image responsive', 'vibez'),
				'parent' => $show_title_area_container,
				'args' => array(
					"dependence" => true,
					"dependence_hide_on_yes" => "#eltdf_title_area_background_image_responsive_container",
					"dependence_show_on_yes" => ""
				)
			)
		);

		$title_area_background_image_responsive_container = vibez_elated_add_admin_container(
			array(
				'parent' => $show_title_area_container,
				'name' => 'title_area_background_image_responsive_container',
				'hidden_property' => 'title_area_background_image_responsive',
				'hidden_value' => 'yes'
			)
		);

		vibez_elated_add_admin_field(
			array(
				'name' => 'title_area_background_image_parallax',
				'type' => 'select',
				'default_value' => 'no',
				'label' => esc_html__('Background Image in Parallax', 'vibez'),
				'description' => esc_html__('Enabling this option will make Title background image parallax', 'vibez'),
				'parent' => $title_area_background_image_responsive_container,
				'options' => array(
					'no' => esc_html__('No', 'vibez'),
					'yes' => esc_html__('Yes', 'vibez'),
					'yes_zoom' => esc_html__('Yes, with zoom out', 'vibez')
				)
			)
		);

		vibez_elated_add_admin_field(array(
			'name' => 'title_area_height',
			'type' => 'text',
			'label' => esc_html__('Height', 'vibez'),
			'description' => esc_html__('Set a height for Title Area', 'vibez'),
			'parent' => $title_area_background_image_responsive_container,
			'args' => array(
				'col_width' => 2,
				'suffix' => 'px'
			)
		));

		$panel_typography = vibez_elated_add_admin_panel(
			array(
				'page' => '_title_page',
				'name' => 'panel_title_typography',
				'title' => esc_html__('Typography', 'vibez')
			)
		);

        vibez_elated_add_admin_section_title(array(
            'name' => 'type_section_title',
            'title' => esc_html__('Title', 'vibez'),
            'parent' => $panel_typography
        ));

        $group_page_title_styles = vibez_elated_add_admin_group(array(
			'name'			=> 'group_page_title_styles',
			'title'			=> esc_html__('Title', 'vibez'),
			'description'	=> esc_html__('Define styles for page title', 'vibez'),
			'parent'		=> $panel_typography
		));

		$row_page_title_styles_1 = vibez_elated_add_admin_row(array(
			'name'		=> 'row_page_title_styles_1',
			'parent'	=> $group_page_title_styles
		));

		vibez_elated_add_admin_field(array(
			'type'			=> 'colorsimple',
			'name'			=> 'page_title_color',
			'default_value'	=> '',
			'label'			=> esc_html__('Text Color', 'vibez'),
			'parent'		=> $row_page_title_styles_1
		));

		vibez_elated_add_admin_field(array(
			'type'			=> 'textsimple',
			'name'			=> 'page_title_font_size',
			'default_value'	=> '',
			'label'			=> esc_html__('Font Size', 'vibez'),
			'args'			=> array(
				'suffix'	=> 'px'
			),
			'parent'		=> $row_page_title_styles_1
		));

		vibez_elated_add_admin_field(array(
			'type'			=> 'textsimple',
			'name'			=> 'page_title_line_height',
			'default_value'	=> '',
			'label'			=> esc_html__('Line Height', 'vibez'),
			'args'			=> array(
				'suffix'	=> 'px'
			),
			'parent'		=> $row_page_title_styles_1
		));

		vibez_elated_add_admin_field(array(
			'type'			=> 'selectblanksimple',
			'name'			=> 'page_title_text_transform',
			'default_value'	=> '',
			'label'			=> esc_html__('Text Transform', 'vibez'),
			'options'		=> vibez_elated_get_text_transform_array(),
			'parent'		=> $row_page_title_styles_1
		));

		$row_page_title_styles_2 = vibez_elated_add_admin_row(array(
			'name'		=> 'row_page_title_styles_2',
			'parent'	=> $group_page_title_styles,
			'next'		=> true
		));

		vibez_elated_add_admin_field(array(
			'type'			=> 'fontsimple',
			'name'			=> 'page_title_google_fonts',
			'default_value'	=> '-1',
			'label'			=> esc_html__('Font Family', 'vibez'),
			'parent'		=> $row_page_title_styles_2
		));

		vibez_elated_add_admin_field(array(
			'type'			=> 'selectblanksimple',
			'name'			=> 'page_title_font_style',
			'default_value'	=> '',
			'label'			=> esc_html__('Font Style', 'vibez'),
			'options'		=> vibez_elated_get_font_style_array(),
			'parent'		=> $row_page_title_styles_2
		));

		vibez_elated_add_admin_field(array(
			'type'			=> 'selectblanksimple',
			'name'			=> 'page_title_font_weight',
			'default_value'	=> '',
			'label'			=> esc_html__('Font Weight', 'vibez'),
			'options'		=> vibez_elated_get_font_weight_array(),
			'parent'		=> $row_page_title_styles_2
		));

		vibez_elated_add_admin_field(array(
			'type'			=> 'textsimple',
			'name'			=> 'page_title_letter_spacing',
			'default_value'	=> '',
			'label'			=> esc_html__('Letter Spacing', 'vibez'),
			'args'			=> array(
				'suffix'	=> 'px'
			),
			'parent'		=> $row_page_title_styles_2
		));

        vibez_elated_add_admin_section_title(array(
            'name' => 'type_section_subtitle',
            'title' => esc_html__('Subtitle', 'vibez'),
            'parent' => $panel_typography
        ));

		$group_page_subtitle_styles = vibez_elated_add_admin_group(array(
			'name'			=> 'group_page_subtitle_styles',
			'title'			=> esc_html__('Subtitle', 'vibez'),
			'description'	=> esc_html__('Define styles for page subtitle', 'vibez'),
			'parent'		=> $panel_typography
		));

		$row_page_subtitle_styles_1 = vibez_elated_add_admin_row(array(
			'name'		=> 'row_page_subtitle_styles_1',
			'parent'	=> $group_page_subtitle_styles
		));

		vibez_elated_add_admin_field(array(
			'type'			=> 'colorsimple',
			'name'			=> 'page_subtitle_color',
			'default_value'	=> '',
			'label'			=> esc_html__('Text Color', 'vibez'),
			'parent'		=> $row_page_subtitle_styles_1
		));

		vibez_elated_add_admin_field(array(
			'type'			=> 'textsimple',
			'name'			=> 'page_subtitle_font_size',
			'default_value'	=> '',
			'label'			=> esc_html__('Font Size', 'vibez'),
			'args'			=> array(
				'suffix'	=> 'px'
			),
			'parent'		=> $row_page_subtitle_styles_1
		));

		vibez_elated_add_admin_field(array(
			'type'			=> 'textsimple',
			'name'			=> 'page_subtitle_line_height',
			'default_value'	=> '',
			'label'			=> esc_html__('Line Height', 'vibez'),
			'args'			=> array(
				'suffix'	=> 'px'
			),
			'parent'		=> $row_page_subtitle_styles_1
		));

		vibez_elated_add_admin_field(array(
			'type'			=> 'selectblanksimple',
			'name'			=> 'page_subtitle_text_transform',
			'default_value'	=> '',
			'label'			=> esc_html__('Text Transform', 'vibez'),
			'options'		=> vibez_elated_get_text_transform_array(),
			'parent'		=> $row_page_subtitle_styles_1
		));

		$row_page_subtitle_styles_2 = vibez_elated_add_admin_row(array(
			'name'		=> 'row_page_subtitle_styles_2',
			'parent'	=> $group_page_subtitle_styles,
			'next'		=> true
		));

		vibez_elated_add_admin_field(array(
			'type'			=> 'fontsimple',
			'name'			=> 'page_subtitle_google_fonts',
			'default_value'	=> '-1',
			'label'			=> esc_html__('Font Family', 'vibez'),
			'parent'		=> $row_page_subtitle_styles_2
		));

		vibez_elated_add_admin_field(array(
			'type'			=> 'selectblanksimple',
			'name'			=> 'page_subtitle_font_style',
			'default_value'	=> '',
			'label'			=> esc_html__('Font Style', 'vibez'),
			'options'		=> vibez_elated_get_font_style_array(),
			'parent'		=> $row_page_subtitle_styles_2
		));

		vibez_elated_add_admin_field(array(
			'type'			=> 'selectblanksimple',
			'name'			=> 'page_subtitle_font_weight',
			'default_value'	=> '',
			'label'			=> esc_html__('Font Weight', 'vibez'),
			'options'		=> vibez_elated_get_font_weight_array(),
			'parent'		=> $row_page_subtitle_styles_2
		));

		vibez_elated_add_admin_field(array(
			'type'			=> 'textsimple',
			'name'			=> 'page_subtitle_letter_spacing',
			'default_value'	=> '',
			'label'			=> esc_html__('Letter Spacing', 'vibez'),
			'args'			=> array(
				'suffix'	=> 'px'
			),
			'parent'		=> $row_page_subtitle_styles_2
		));

        vibez_elated_add_admin_section_title(array(
            'name' => 'type_section_breadcrumbs',
            'title' => esc_html__('Breadcrumbs', 'vibez'),
            'parent' => $panel_typography
        ));

		$group_page_breadcrumbs_styles = vibez_elated_add_admin_group(array(
			'name'			=> 'group_page_breadcrumbs_styles',
			'title'			=> esc_html__('Breadcrumbs', 'vibez'),
			'description'	=> esc_html__('Define styles for page breadcrumbs', 'vibez'),
			'parent'		=> $panel_typography
		));

		$row_page_breadcrumbs_styles_1 = vibez_elated_add_admin_row(array(
			'name'		=> 'row_page_breadcrumbs_styles_1',
			'parent'	=> $group_page_breadcrumbs_styles
		));

		vibez_elated_add_admin_field(array(
			'type'			=> 'colorsimple',
			'name'			=> 'page_breadcrumb_color',
			'default_value'	=> '',
			'label'			=> esc_html__('Text Color', 'vibez'),
			'parent'		=> $row_page_breadcrumbs_styles_1
		));

		vibez_elated_add_admin_field(array(
			'type'			=> 'textsimple',
			'name'			=> 'page_breadcrumb_font_size',
			'default_value'	=> '',
			'label'			=> esc_html__('Font Size', 'vibez'),
			'args'			=> array(
				'suffix'	=> 'px'
			),
			'parent'		=> $row_page_breadcrumbs_styles_1
		));

		vibez_elated_add_admin_field(array(
			'type'			=> 'textsimple',
			'name'			=> 'page_breadcrumb_line_height',
			'default_value'	=> '',
			'label'			=> esc_html__('Line Height', 'vibez'),
			'args'			=> array(
				'suffix'	=> 'px'
			),
			'parent'		=> $row_page_breadcrumbs_styles_1
		));

		vibez_elated_add_admin_field(array(
			'type'			=> 'selectblanksimple',
			'name'			=> 'page_breadcrumb_text_transform',
			'default_value'	=> '',
			'label'			=> esc_html__('Text Transform', 'vibez'),
			'options'		=> vibez_elated_get_text_transform_array(),
			'parent'		=> $row_page_breadcrumbs_styles_1
		));

		$row_page_breadcrumbs_styles_2 = vibez_elated_add_admin_row(array(
			'name'		=> 'row_page_breadcrumbs_styles_2',
			'parent'	=> $group_page_breadcrumbs_styles,
			'next'		=> true
		));

		vibez_elated_add_admin_field(array(
			'type'			=> 'fontsimple',
			'name'			=> 'page_breadcrumb_google_fonts',
			'default_value'	=> '-1',
			'label'			=> esc_html__('Font Family', 'vibez'),
			'parent'		=> $row_page_breadcrumbs_styles_2
		));

		vibez_elated_add_admin_field(array(
			'type'			=> 'selectblanksimple',
			'name'			=> 'page_breadcrumb_font_style',
			'default_value'	=> '',
			'label'			=> esc_html__('Font Style', 'vibez'),
			'options'		=> vibez_elated_get_font_style_array(),
			'parent'		=> $row_page_breadcrumbs_styles_2
		));

		vibez_elated_add_admin_field(array(
			'type'			=> 'selectblanksimple',
			'name'			=> 'page_breadcrumb_font_weight',
			'default_value'	=> '',
			'label'			=> esc_html__('Font Weight', 'vibez'),
			'options'		=> vibez_elated_get_font_weight_array(),
			'parent'		=> $row_page_breadcrumbs_styles_2
		));

		vibez_elated_add_admin_field(array(
			'type'			=> 'textsimple',
			'name'			=> 'page_breadcrumb_letter_spacing',
			'default_value'	=> '',
			'label'			=> esc_html__('Letter Spacing', 'vibez'),
			'args'			=> array(
				'suffix'	=> 'px'
			),
			'parent'		=> $row_page_breadcrumbs_styles_2
		));

		$row_page_breadcrumbs_styles_3 = vibez_elated_add_admin_row(array(
			'name'		=> 'row_page_breadcrumbs_styles_3',
			'parent'	=> $group_page_breadcrumbs_styles,
			'next'		=> true
		));

		vibez_elated_add_admin_field(array(
			'type'			=> 'colorsimple',
			'name'			=> 'page_breadcrumb_hovercolor',
			'default_value'	=> '',
			'label'			=> esc_html__('Hover/Active Text Color', 'vibez'),
			'parent'		=> $row_page_breadcrumbs_styles_3
		));
    }

	add_action( 'vibez_elated_action_options_map', 'vibez_elated_title_options_map', 4);
}