<?php

include_once ELATED_FRAMEWORK_MODULES_ROOT_DIR.'/title/options-map/map.php';
include_once ELATED_FRAMEWORK_MODULES_ROOT_DIR.'/title/filter-functions.php';
include_once ELATED_FRAMEWORK_MODULES_ROOT_DIR.'/title/title-functions.php';
include_once ELATED_FRAMEWORK_MODULES_ROOT_DIR.'/title/custom-styles/title.php';