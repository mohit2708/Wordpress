<?php

if(!function_exists('vibez_elated_title_classes')) {
    /**
     * Function that adds classes to title div.
     * All other functions are tied to it with add_filter function
     * @param array $classes array of classes
     * @param string $module name of module calling title
     */
    function vibez_elated_title_classes($classes = array()) {
        $classes = apply_filters('vibez_elated_filter_title_classes', $classes = array());

        if(is_array($classes) && count($classes)) {
            echo implode(' ', $classes);
        }
    }
}

if(!function_exists('vibez_elated_title_type_class')) {
    /**
     * Function that adds class on title based on title type option
     * @param $classes original array of classes
     * @return array changed array of classes
     */
    function vibez_elated_title_type_class($classes) {
	    $id = vibez_elated_get_page_id();
        $title_type = vibez_elated_get_meta_field_intersect('title_area_type', $id);
	    $title_type = vibez_elated_intersect_title_options_with_events(vibez_elated_options()->getOptionValue('title_events_area_type'), $title_type);
	    
	    if(!empty($title_type)) {
		    $classes[] = 'eltdf-'.$title_type.'-type';
	    }

        return $classes;
    }

    add_filter('vibez_elated_filter_title_classes', 'vibez_elated_title_type_class');
}

if(!function_exists('vibez_elated_title_area_split_columns_classes')) {
	function vibez_elated_title_area_split_columns_classes($classes) {
		$id = vibez_elated_get_page_id();
		$title_type = vibez_elated_get_meta_field_intersect('title_area_type', $id);
		$title_type = vibez_elated_intersect_title_options_with_events(vibez_elated_options()->getOptionValue('title_events_area_type'), $title_type);
		
		if($title_type === 'split-columns') {
			$title_area_title_text_position = vibez_elated_get_meta_field_intersect('title_area_title_text_position', $id);
			$title_disable_break_words      = vibez_elated_get_meta_field_intersect('title_area_disable_break_words', $id);
			
			if(!empty($title_area_title_text_position)) {
				$classes[] = 'eltdf-sc-'.$title_area_title_text_position;
			}
			
			if($title_disable_break_words === 'yes') {
				$classes[] = 'eltdf-title-break-is-disabled';
			}
		}
		
		return $classes;
	}
	
	add_filter('vibez_elated_filter_title_classes', 'vibez_elated_title_area_split_columns_classes');
}

if(!function_exists('vibez_elated_title_content_alignment_class')) {
	/**
	 * Function that adds class on title based on title content alignmnt option
	 * Could be left, centered or right
	 * @param $classes original array of classes
	 * @return array changed array of classes
	 */
	function vibez_elated_title_content_alignment_class($classes) {
		$id = vibez_elated_get_page_id();
		$title_content_alignment = vibez_elated_get_meta_field_intersect('title_area_content_alignment', $id);
		$title_content_alignment = vibez_elated_intersect_title_options_with_events(vibez_elated_options()->getOptionValue('title_events_area_content_alignment'), $title_content_alignment);
		
		if(!empty($title_content_alignment)) {
			$classes[] = 'eltdf-content-'.$title_content_alignment.'-alignment';
		}
		
		return $classes;
	}
	
	add_filter('vibez_elated_filter_title_classes', 'vibez_elated_title_content_alignment_class');
}

if(!function_exists('vibez_elated_title_background_image_classes')) {
    function vibez_elated_title_background_image_classes($classes) {
        //init variables
        $id                      = vibez_elated_get_page_id();
	    $title_img				 = apply_filters('vibez_elated_filter_title_image_exists', vibez_elated_get_meta_field_intersect('title_area_background_image', $id));
	    //check for tribe events options
	    $title_img = vibez_elated_intersect_title_options_with_events(vibez_elated_options()->getOptionValue('title_events_area_background_image'), $title_img);
	    $is_img_responsive 		 = vibez_elated_get_meta_field_intersect('title_area_background_image_responsive', $id);
	    $is_image_parallax		 = vibez_elated_get_meta_field_intersect('title_area_background_image_parallax', $id);
	    $is_image_parallax_array = array('yes', 'yes_zoom');
	    $hide_title_img			 = get_post_meta($id, "eltdf_hide_background_image_meta", true) == 'yes' ? true : false;

        // Is title image visible and responsive?
        // Removed check for is title image set because of blog single module title (featured image used as title image). Added css for container auto heihgt.
        if($title_img != '' && !$hide_title_img) {
            //is image not responsive and parallax title is set?
            $classes[] = 'eltdf-preload-background';
            $classes[] = 'eltdf-has-background';

            if($is_img_responsive == 'no' && in_array($is_image_parallax, $is_image_parallax_array)) {
                $classes[] = 'eltdf-has-parallax-background';

                if($is_image_parallax == 'yes_zoom') {
                    $classes[] = 'eltdf-zoom-out';
                }
            }

            //is image not responsive
            elseif($is_img_responsive == 'yes'){
                $classes[] = 'eltdf-has-responsive-background';
            }
        }

        return $classes;
    }

    add_filter('vibez_elated_filter_title_classes', 'vibez_elated_title_background_image_classes');
}

if(!function_exists('vibez_elated_title_background_image_div_classes')) {
	function vibez_elated_title_background_image_div_classes($classes) {
		//init variables
		$id                 = vibez_elated_get_page_id();
        $title_img			= apply_filters('vibez_elated_filter_title_image_exists', vibez_elated_get_meta_field_intersect('title_area_background_image', $id));
		//check for tribe events options
		$title_img = vibez_elated_intersect_title_options_with_events(vibez_elated_options()->getOptionValue('title_events_area_background_image'), $title_img);
		$is_img_responsive 	= vibez_elated_get_meta_field_intersect('title_area_background_image_responsive', $id);
        $hide_title_img			 = get_post_meta($id, "eltdf_hide_background_image_meta", true) == 'yes' ? true : false;
		
		// Is title image visible and responsive?
        // Removed check for is title image set because of blog single module title (featured image used as title image). Added css for container auto heihgt.
        if($title_img != '' && !$hide_title_img) {
			
			//is image responsive?
			if($is_img_responsive == 'yes') {
				$classes[] = 'eltdf-title-image-responsive';
			}
			//is image not responsive?
			elseif($is_img_responsive == 'no') {
				$classes[] = 'eltdf-title-image-not-responsive';
			}
		}
		
		return $classes;
	}
	
	add_filter('vibez_elated_filter_title_classes', 'vibez_elated_title_background_image_div_classes');
}

if(!function_exists('vibez_elated_title_area_arrows_animation_classes')) {
	function vibez_elated_title_area_arrows_animation_classes($classes) {
		$id = vibez_elated_get_page_id();
		$enable_arrows = vibez_elated_get_meta_field_intersect('title_enable_arrows_animation', $id);
		
		if(!empty($enable_arrows) && $enable_arrows === 'yes') {
			$classes[] = 'eltdf-title-has-arrows';
			
			$arrows_skin     = vibez_elated_get_meta_field_intersect('title_area_arrows_skin', $id);
			$arrows_position = vibez_elated_get_meta_field_intersect('title_area_arrows_position', $id);
			$disable_arrows  = vibez_elated_get_meta_field_intersect('title_area_disable_arrows_animation', $id);
			
			if(!empty($arrows_skin)) {
				$classes[] = 'eltdf-arrows-skin-'.$arrows_skin;
			}
			
			if(!empty($arrows_position)) {
				$classes[] = 'eltdf-arrows-'.$arrows_position;
			}
			
			if(!empty($disable_arrows)) {
				$classes[] = 'eltdf-disabled-arrows-bellow-'.$disable_arrows;
			}
		}
		
		return $classes;
	}
	
	add_filter('vibez_elated_filter_title_classes', 'vibez_elated_title_area_arrows_animation_classes');
}