<?php

if(!function_exists('vibez_elated_include_events_shortcodes')) {
	function vibez_elated_include_events_shortcodes() {
		include_once ELATED_FRAMEWORK_MODULES_ROOT_DIR.'/events/shortcodes/events-list/events-list.php';
	}
	
	if(vibez_elated_core_plugin_installed()) {
		add_action('eltdf_core_action_include_shortcodes_file', 'vibez_elated_include_events_shortcodes');
	}
}

if(!function_exists('vibez_elated_add_events_shortcodes')) {
	function vibez_elated_add_events_shortcodes($shortcodes_class_name) {
		$shortcodes = array(
			'ElatedCore\CPT\Shortcodes\EventsList\EventsList',
		);
		
		$shortcodes_class_name = array_merge($shortcodes_class_name, $shortcodes);
		
		return $shortcodes_class_name;
	}
	
	if(vibez_elated_core_plugin_installed()) {
		add_filter('eltdf_core_filter_add_vc_shortcode', 'vibez_elated_add_events_shortcodes');
	}
}

if ( ! function_exists( 'vibez_elated_set_events_list_icon_class_name_for_vc_shortcodes' ) ) {
	/**
	 * Function that set custom icon class name for events shortcodes to set our icon for Visual Composer shortcodes panel
	 */
	function vibez_elated_set_events_list_icon_class_name_for_vc_shortcodes( $shortcodes_icon_class_array ) {
		$shortcodes_icon_class_array[] = '.icon-wpb-events-list';
		
		return $shortcodes_icon_class_array;
	}
	
	if ( vibez_elated_core_plugin_installed() ) {
		add_filter( 'eltdf_core_filter_add_vc_shortcodes_custom_icon_class', 'vibez_elated_set_events_list_icon_class_name_for_vc_shortcodes' );
	}
}