<div <?php post_class($item_class); ?>>
    <div class="eltdf-events-list-item-holder">
        <?php if(has_post_thumbnail()) : ?>
            <div class="eltdf-events-list-item-image-holder">
                <a href="<?php the_permalink(); ?>">
                    <?php the_post_thumbnail($image_size); ?>

                    <div class="eltdf-events-list-item-date-holder">
                        <div class="eltdf-events-list-item-date-inner">
							<span class="eltdf-events-list-item-date-day">
								<?php echo tribe_get_start_date(null, true, 'd'); ?>
							</span>

							<span class="eltdf-events-list-item-date-month">
								<?php echo tribe_get_start_date(null, true, 'M'); ?>
							</span>
                        </div>
                    </div>
                </a>
            </div>
        <?php endif; ?>
        <div class="eltdf-events-list-item-content">
	        <div class="eltdf-events-list-item-info">
		        <div class="eltdf-events-list-item-date">
					<span class="eltdf-events-item-info-icon">
						<?php echo vibez_elated_icon_collections()->renderIcon('lnr-calendar-full', 'linear_icons'); ?>
					</span>
			        <?php echo tribe_events_event_schedule_details(); ?>
		        </div>
		        <div class="eltdf-events-list-item-location-holder">
					<span class="eltdf-events-item-info-icon">
						<?php echo vibez_elated_icon_collections()->renderIcon('lnr-map-marker', 'linear_icons'); ?>
					</span>
			        <span class="qpdef-events-list-item-location"><?php echo esc_html(tribe_get_address()); ?></span>
		        </div>
	        </div>
            <div class="eltdf-events-list-item-title-holder">
                <h4 class="eltdf-events-list-item-title">
                    <a href="<?php the_permalink(); ?>"><?php the_title(); ?></a>
                </h4>
            </div>
	        <?php
	            $excerpt_text = get_the_excerpt();
	            if(!empty($excerpt_text)) { ?>
		            <div class="eltdf-events-list-item-excerpt-holder">
			            <?php
				            $excerpt_text = rtrim( implode( ' ', array_slice( explode( ' ', $excerpt_text ), 0, 16 ) ) );
				            echo esc_html( $excerpt_text );
			            ?>
		            </div>
	            <?php }
	        ?>
        </div>
    </div>
</div>