<?php
namespace ElatedCore\CPT\Shortcodes\EventsList;

use VibezElatedNamespace\Modules\Events\Lib\EventsQuery;
use ElatedCore\Lib;

class EventsList implements Lib\ShortcodeInterface {
	private $base;
	
	public function __construct() {
		$this->base = 'eltdf_events_list';
		
		add_action( 'vc_before_init', array( $this, 'vcMap' ) );
	}
	
	public function getBase() {
		return $this->base;
	}
	
	public function vcMap() {
		vc_map(
			array(
				'name'                      => esc_html__( 'Elated Events List', 'vibez' ),
				'base'                      => $this->getBase(),
				'category'                  => esc_html__( 'by ELATED', 'vibez' ),
				'icon'                      => 'icon-wpb-events-list extended-custom-icon',
				'allowed_container_element' => 'vc_row',
				'params'                    => array_merge(
					array(
						array(
							'type'        => 'dropdown',
							'param_name'  => 'columns',
							'heading'     => esc_html__( 'Number of Columns', 'vibez' ),
							'value'       => array(
								esc_html__( 'Default', 'vibez' ) => '',
								esc_html__( 'One', 'vibez' )     => 'one',
								esc_html__( 'Two', 'vibez' )     => 'two',
								esc_html__( 'Three', 'vibez' )   => 'three',
								esc_html__( 'Four', 'vibez' )    => 'four',
								esc_html__( 'Five', 'vibez' )    => 'five',
								esc_html__( 'Six', 'vibez' )     => 'six'
							),
							'description' => esc_html__( 'Default value is Three', 'vibez' ),
							'group'       => esc_html__( 'Layout Options', 'vibez' )
						),
						array(
							'type'        => 'dropdown',
							'param_name'  => 'image_size',
							'heading'     => esc_html__( 'Image Proportions', 'vibez' ),
							'value'       => array(
								esc_html__( 'Original', 'vibez' )  => 'full',
								esc_html__( 'Square', 'vibez' )    => 'square',
								esc_html__( 'Landscape', 'vibez' ) => 'landscape',
								esc_html__( 'Portrait', 'vibez' )  => 'portrait'
							),
							'save_always' => true,
							'group'       => esc_html__( 'Layout Options', 'vibez' )
						),
					),
					EventsQuery::getInstance()->queryVCParams()
				)
			)
		);
	}
	
	public function render( $atts, $content = null ) {
		$default_atts = array(
			'columns'    => '',
			'image_size' => ''
		);
		
		$eventsQuery = EventsQuery::getInstance();
		
		$default_atts = array_merge( $default_atts, $eventsQuery->getShortcodeAtts() );
		$params       = shortcode_atts( $default_atts, $atts );
		
		$queryResults = $eventsQuery->buildQueryObject( $params );
		
		$params['query']  = $queryResults;
		$params['caller'] = $this;
		
		$itemClass[] = 'eltdf-events-list-item';
		
		switch ( $params['columns'] ) {
			case 'one':
				$itemClass[] = 'eltdf-grid-col-12';
				break;
			case 'two':
				$itemClass[] = 'eltdf-grid-col-6';
				break;
			case 'three':
				$itemClass[] = 'eltdf-grid-col-4';
				break;
			case 'four':
				$itemClass[] = 'eltdf-grid-col-3';
				$itemClass[] = 'eltdf-grid-col-ipad-landscape-6';
				$itemClass[] = 'eltdf-grid-col-ipad-portrait-12';
				break;
			default:
				$itemClass[] = 'eltdf-grid-col-4';
				break;
		}

		$params['item_class'] = implode( ' ', $itemClass );
		
		$params['image_size'] = $this->getImageSize( $params );
		
		return vibez_elated_get_module_template_part( 'templates/events-list-holder', 'events/shortcodes/events-list', '', $params );
	}
	
	public function getEventItemTemplate( $params ) {
		echo vibez_elated_get_module_template_part( 'templates/events-list-item', 'events/shortcodes/events-list', '', $params );
	}
	
	private function getImageSize( $params ) {
		
		if ( ! empty( $params['image_size'] ) ) {
			$image_size = $params['image_size'];
			
			switch ( $image_size ) {
				case 'landscape':
					$thumb_size = 'vibez_elated_image_landscape';
					break;
				case 'portrait':
					$thumb_size = 'vibez_elated_image_portrait';
					break;
				case 'square':
					$thumb_size = 'vibez_elated_image_square';
					break;
				case 'full':
					$thumb_size = 'full';
					break;
				case 'custom':
					$thumb_size = 'custom';
					break;
				default:
					$thumb_size = 'full';
					break;
			}
			
			return $thumb_size;
		}
	}
}