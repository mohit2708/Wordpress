<?php

if ( ! function_exists( 'vibez_elated_events_header_menu_area_styles' ) ) {
	/**
	 * Generates styles for menu area
	 */
	function vibez_elated_events_header_menu_area_styles() {
		$background_color              = vibez_elated_options()->getOptionValue( 'events_menu_area_background_color' );
		$background_color_transparency = vibez_elated_options()->getOptionValue( 'events_menu_area_background_transparency' );
		
		$menu_area_styles = array();
		
		if ( $background_color !== '' ) {
			$menu_area_background_color        = $background_color;
			$menu_area_background_transparency = 1;
			
			if ( $background_color_transparency !== '' ) {
				$menu_area_background_transparency = $background_color_transparency;
			}
			
			$menu_area_styles['background-color'] = vibez_elated_rgba_color( $menu_area_background_color, $menu_area_background_transparency );
		}
		
		echo vibez_elated_dynamic_css( '.post-type-archive-tribe_events .eltdf-page-header .eltdf-menu-area', $menu_area_styles );
	}
	
	add_action( 'vibez_elated_action_style_dynamic', 'vibez_elated_events_header_menu_area_styles' );
}