<?php

if ( vibez_elated_is_the_events_calendar_installed() ) {
	if ( ! function_exists( 'vibez_elated_events_options_map' ) ) {
		/**
		 * Add Evetns options page
		 */
		function vibez_elated_events_options_map() {
			
			vibez_elated_add_admin_page(
				array(
					'slug'  => '_events_page',
					'title' => esc_html__( 'Events', 'vibez' ),
					'icon'  => 'fa fa-calendar'
				)
			);
			
			$panel_header = vibez_elated_add_admin_panel(
				array(
					'page'  => '_events_page',
					'name'  => 'panel_header',
					'title' => esc_html__( 'Header', 'vibez' )
				)
			);
			
			vibez_elated_add_admin_field(
				array(
					'parent'        => $panel_header,
					'type'          => 'select',
					'name'          => 'events_header_style',
					'default_value' => '',
					'label'         => esc_html__( 'Header Skin', 'vibez' ),
					'description'   => esc_html__( 'Choose a predefined header style for header elements (logo, main menu, side menu opener...)', 'vibez' ),
					'options'       => array(
						''             => esc_html__( 'Default', 'vibez' ),
						'light-header' => esc_html__( 'Light', 'vibez' ),
						'dark-header'  => esc_html__( 'Dark', 'vibez' )
					)
				)
			);
			
			vibez_elated_add_admin_field(
				array(
					'parent'        => $panel_header,
					'type'          => 'color',
					'name'          => 'events_menu_area_background_color',
					'default_value' => '',
					'label'         => esc_html__( 'Background color', 'vibez' ),
					'description'   => esc_html__( 'Set background color for menu area', 'vibez' )
				)
			);
			
			vibez_elated_add_admin_field(
				array(
					'parent'        => $panel_header,
					'type'          => 'text',
					'name'          => 'events_menu_area_background_transparency',
					'default_value' => '',
					'label'         => esc_html__( 'Background transparency', 'vibez' ),
					'description'   => esc_html__( 'Set background transparency for menu area', 'vibez' ),
					'args'          => array(
						'col_width' => 3
					)
				)
			);
			
			$panel_title = vibez_elated_add_admin_panel(
				array(
					'page'  => '_events_page',
					'name'  => 'panel_title',
					'title' => esc_html__( 'Title Settings', 'vibez' )
				)
			);
			
			$show_events_title_area_container = vibez_elated_add_admin_container(
				array(
					'parent'          => $panel_title,
					'name'            => 'show_events_title_area_container',
					'hidden_property' => 'show_title_area',
					'hidden_value'    => 'no'
				)
			);
			
			vibez_elated_add_admin_field(
				array(
					'name'          => 'title_events_area_type',
					'type'          => 'select',
					'default_value' => '',
					'label'         => esc_html__( 'Title Area Type', 'vibez' ),
					'description'   => esc_html__( 'Choose title type', 'vibez' ),
					'parent'        => $show_events_title_area_container,
					'options'       => array(
						''           => esc_html__( 'Default', 'vibez' ),
						'standard'   => esc_html__( 'Standard', 'vibez' ),
						'breadcrumb' => esc_html__( 'Breadcrumb', 'vibez' )
					)
				)
			);
			
			vibez_elated_add_admin_field(
				array(
					'name'        => 'title_events_area_background_image',
					'type'        => 'image',
					'label'       => esc_html__( 'Background Image', 'vibez' ),
					'description' => esc_html__( 'Choose an Image for Title Area', 'vibez' ),
					'parent'      => $show_events_title_area_container
				)
			);
			
			vibez_elated_add_admin_field(
				array(
					'name'        => 'title_events_area_background_color',
					'type'        => 'color',
					'label'       => esc_html__( 'Background Color', 'vibez' ),
					'description' => esc_html__( 'Choose a background color for Title Area', 'vibez' ),
					'parent'      => $show_events_title_area_container
				)
			);
			
			vibez_elated_add_admin_field(
				array(
					'name'        => 'title_events_area_height',
					'type'        => 'text',
					'label'       => esc_html__( 'Height', 'vibez' ),
					'description' => esc_html__( 'Set a height for Title Area', 'vibez' ),
					'parent'      => $show_events_title_area_container,
					'args'        => array(
						'col_width' => 2,
						'suffix'    => 'px'
					)
				)
			);
			
			vibez_elated_add_admin_field(
				array(
					'name' => 'title_events_area_vertical_alignment',
					'type' => 'select',
					'default_value' => 'header_bottom',
					'label' => esc_html__('Vertical Alignment', 'vibez'),
					'description' => esc_html__('Specify title vertical alignment', 'vibez'),
					'parent' => $show_events_title_area_container,
					'options' => array(
						''          => esc_html__( 'Default', 'vibez' ),
						'header_bottom' => esc_html__('From Bottom of Header', 'vibez'),
						'window_top' => esc_html__('From Window Top', 'vibez')
					)
				)
			);
			
			vibez_elated_add_admin_field(
				array(
					'name'          => 'title_events_area_content_alignment',
					'type'          => 'select',
					'default_value' => 'left',
					'label'         => esc_html__( 'Horizontal Alignment', 'vibez' ),
					'description'   => esc_html__( 'Specify title horizontal alignment', 'vibez' ),
					'parent'        => $show_events_title_area_container,
					'options'       => array(
						''          => esc_html__( 'Default', 'vibez' ),
						'center' => esc_html__( 'Center', 'vibez' ),
						'left'   => esc_html__( 'Left', 'vibez' ),
						'right'  => esc_html__( 'Right', 'vibez' )
					)
				)
			);
			
			vibez_elated_add_admin_field(
				array(
					'name' => 'title_events_area_title_tag',
					'type' => 'select',
					'default_value' => '',
					'label' => esc_html__('Title Tag', 'vibez'),
					'parent' => $show_events_title_area_container,
					'options' => vibez_elated_get_title_tag(true)
				)
			);
			
			vibez_elated_add_admin_field(array(
				'type'			=> 'color',
				'name'			=> 'events_page_title_color',
				'label'			=> esc_html__('Title Text Color', 'vibez'),
				'parent'		=> $show_events_title_area_container
			));
		}
		
		add_action( 'vibez_elated_action_options_map', 'vibez_elated_events_options_map', 17 );
	}
}