<?php

if (!function_exists('vibez_elated_register_sidebars')) {
    /**
     * Function that registers theme's sidebars
     */
    function vibez_elated_register_sidebars() {

        register_sidebar(array(
            'name' => esc_html__('Sidebar', 'vibez'),
            'id' => 'sidebar',
            'description' => esc_html__('Default Sidebar', 'vibez'),
            'before_widget' => '<div id="%1$s" class="widget %2$s">',
            'after_widget' => '</div>',
            'before_title' => '<div class="eltdf-widget-title-holder"><h4 class="eltdf-widget-title">',
            'after_title' => '</h4></div>'
        ));
    }

    add_action('widgets_init', 'vibez_elated_register_sidebars', 1);
}

if (!function_exists('vibez_elated_add_support_custom_sidebar')) {
    /**
     * Function that adds theme support for custom sidebars. It also creates VibezElatedClassSidebar object
     */
    function vibez_elated_add_support_custom_sidebar() {
        add_theme_support('VibezElatedClassSidebar');
        if (get_theme_support('VibezElatedClassSidebar')) new VibezElatedClassSidebar();
    }

    add_action('after_setup_theme', 'vibez_elated_add_support_custom_sidebar');
}