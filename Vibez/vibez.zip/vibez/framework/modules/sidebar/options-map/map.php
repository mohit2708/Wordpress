<?php

if ( ! function_exists('vibez_elated_sidebar_options_map') ) {

	function vibez_elated_sidebar_options_map() {

		vibez_elated_add_admin_page(
			array(
				'slug' => '_sidebar_page',
				'title' => esc_html__('Sidebar Area', 'vibez'),
				'icon' => 'fa fa-indent'
			)
		);

		$sidebar_panel = vibez_elated_add_admin_panel(
			array(
				'title' => esc_html__('Sidebar Area', 'vibez'),
				'name' => 'sidebar',
				'page' => '_sidebar_page'
			)
		);
		
		vibez_elated_add_admin_field(array(
			'name'          => 'sidebar_layout',
			'type'          => 'select',
			'label'         => esc_html__('Sidebar Layout', 'vibez'),
			'description'   => esc_html__('Choose a sidebar layout for pages', 'vibez'),
			'parent'        => $sidebar_panel,
			'default_value' => 'no-sidebar',
			'options'       => array(
				'no-sidebar'        => esc_html__('No Sidebar', 'vibez'),
				'sidebar-33-right'	=> esc_html__('Sidebar 1/3 Right', 'vibez'),
				'sidebar-25-right' 	=> esc_html__('Sidebar 1/4 Right', 'vibez'),
				'sidebar-33-left' 	=> esc_html__('Sidebar 1/3 Left', 'vibez'),
				'sidebar-25-left' 	=> esc_html__('Sidebar 1/4 Left', 'vibez')
			)
		));
		
		$vibez_custom_sidebars = vibez_elated_get_custom_sidebars();
		if(count($vibez_custom_sidebars) > 0) {
			vibez_elated_add_admin_field(array(
				'name' => 'custom_sidebar_area',
				'type' => 'selectblank',
				'label' => esc_html__('Sidebar to Display', 'vibez'),
				'description' => esc_html__('Choose a sidebar to display on pages. Default sidebar is "Sidebar"', 'vibez'),
				'parent' => $sidebar_panel,
				'options' => $vibez_custom_sidebars,
				'args'        => array(
					'select2'	=> true
				)
			));
		}
	}

	add_action('vibez_elated_action_options_map', 'vibez_elated_sidebar_options_map', 6);
}