<?php

if ( ! function_exists('vibez_elated_contact_form_map') ) {
	/**
	 * Map Contact Form 7 shortcode
	 * Hooks on vc_after_init action
	 */
	function vibez_elated_contact_form_map() {
		vc_add_param('contact-form-7', array(
			'type' => 'dropdown',
			'heading' => esc_html__('Style', 'vibez'),
			'param_name' => 'html_class',
			'value' => array(
				esc_html__('Default', 'vibez') => 'default',
				esc_html__('Custom Style 1', 'vibez') => 'cf7_custom_style_1',
				esc_html__('Custom Style 2', 'vibez') => 'cf7_custom_style_2',
				esc_html__('Custom Style 3', 'vibez') => 'cf7_custom_style_3',
				esc_html__('Custom Style 4', 'vibez') => 'cf7_custom_style_4'
			),
			'description' => esc_html__('You can style each form element individually in Elated Options > Contact Form 7', 'vibez')
		));
	}
	
	add_action('vc_after_init', 'vibez_elated_contact_form_map');
}