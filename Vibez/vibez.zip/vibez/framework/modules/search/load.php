<?php

include_once ELATED_FRAMEWORK_MODULES_ROOT_DIR.'/search/options-map/map.php';
include_once ELATED_FRAMEWORK_MODULES_ROOT_DIR.'/search/custom-styles/search.php';
include_once ELATED_FRAMEWORK_MODULES_ROOT_DIR.'/search/search-functions.php';