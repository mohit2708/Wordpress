<?php

if (vibez_elated_is_wpml_installed()) {
	include_once ELATED_FRAMEWORK_MODULES_ROOT_DIR.'/wpml/wpml-functions.php';
}