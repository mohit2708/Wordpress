<?php

if(vibez_elated_contact_form_7_installed()) {
	require_once ELATED_FRAMEWORK_MODULES_ROOT_DIR . '/widgets/contact-form-7/contact-form-7.php';
	add_filter('vibez_elated_filter_register_widgets', 'vibez_elated_register_cf7_widget');
}

if(!function_exists('vibez_elated_register_cf7_widget')) {
	/**
	 * Function that register cf7 widget
	 */
	function vibez_elated_register_cf7_widget($widgets) {
		$widgets[] = 'VibezElatedClassContactForm7Widget';
		
		return $widgets;
	}
}