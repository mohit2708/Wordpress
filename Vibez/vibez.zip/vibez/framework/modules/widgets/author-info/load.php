<?php

require_once ELATED_FRAMEWORK_MODULES_ROOT_DIR.'/widgets/author-info/author-info.php';