<?php
class VibezElatedClassAuthorInfoWidget extends VibezElatedClassWidget {
    /**
     * Set basic widget options and call parent class construct
     */
    public function __construct() {
        parent::__construct(
            'eltdf_author_info_widget',
            esc_html__('Elated Author Info Widget', 'vibez'),
            array( 'description' => esc_html__( 'Add author info element to widget areas', 'vibez'))
        );

        $this->setParams();
    }

    /**
     * Sets widget options
     */
    protected function setParams() {
        $this->params = array(
            array(
                'type' => 'textfield',
                'name' => 'extra_class',
                'title' => esc_html__('Custom CSS Class', 'vibez')
            ),
            array(
                'type' => 'textfield',
                'name' => 'author_username',
                'title' => esc_html__('Author Username', 'vibez')
            )
        );
    }

    /**
     * Generates widget's HTML
     *
     * @param array $args args from widget area
     * @param array $instance widget's options
     */
    public function widget($args, $instance) {
        extract($args);

        $extra_class = '';
        if (!empty($instance['extra_class'])) {
            $extra_class = $instance['extra_class'];
        }

        $authorID = 1;
	    if(!empty($instance['author_username'])) {
		    $author = get_user_by( 'login', $instance['author_username']);

		    if ($author) $authorID = $author->ID;
	    }

	    $author_position = get_the_author_meta('user_position', $authorID);
	    $author_info     = get_the_author_meta('description', $authorID);
        ?>

        <div class="widget eltdf-author-info-widget <?php echo esc_html($extra_class); ?>">
            <div class="eltdf-aiw-inner">
	            <a itemprop="url" class="eltdf-aiw-image" href="<?php echo esc_url(get_author_posts_url($authorID)); ?>" target="_self">
					<?php echo vibez_elated_kses_img(get_avatar($authorID, 305)); ?>
		        </a>
	            <?php if($author_position !== ''){ ?>
		            <p class="eltdf-aiw-position"><?php echo esc_attr($author_position); ?></p>
	            <?php } ?>
		        <h4 class="eltdf-aiw-name vcard author">
			        <a itemprop="url" href="<?php echo esc_url(get_author_posts_url($authorID)); ?>" target="_self">
						<span class="fn">
							<?php
							if(esc_attr(get_the_author_meta('first_name', $authorID)) != "" || esc_attr(get_the_author_meta('last_name', $authorID) != "")) {
								echo esc_attr(get_the_author_meta('first_name', $authorID)) . " " . esc_attr(get_the_author_meta('last_name', $authorID));
							} else {
								echo esc_attr(get_the_author_meta('display_name', $authorID));
							}
							?>
						</span>
			        </a>
		        </h4>
		        <?php if($author_info !== "") { ?>
			        <p itemprop="description" class="eltdf-aiw-text"><?php echo esc_attr($author_info); ?></p>
		        <?php } ?>
            </div>
        </div>
    <?php 
    }
}