<?php

class VibezElatedClassImageGalleryWidget extends VibezElatedClassWidget {
    public function __construct() {
        parent::__construct(
            'eltdf_image_gallery_widget',
            esc_html__('Elated Image Gallery Widget', 'vibez'),
            array( 'description' => esc_html__( 'Add image gallery element to widget areas', 'vibez'))
        );

        $this->setParams();
    }

    /**
     * Sets widget options
     */
    protected function setParams() {
        $this->params = array(
	        array(
		        'type'  => 'textfield',
		        'name'  => 'extra_class',
		        'title' => esc_html__( 'Custom CSS Class', 'vibez' )
	        ),
	        array(
		        'type'  => 'textfield',
		        'name'  => 'widget_title',
		        'title' => esc_html__( 'Widget Title', 'vibez' )
	        ),
	        array(
		        'type'        => 'textfield',
		        'name'        => 'images',
		        'title'       => esc_html__( 'Image ID\'s', 'vibez' ),
		        'description' => esc_html__( 'Add images id for your image gallery widget, separate id\'s with comma', 'vibez' )
	        ),
	        array(
		        'type'        => 'textfield',
		        'name'        => 'image_size',
		        'title'       => esc_html__( 'Image Size', 'vibez' ),
		        'description' => esc_html__( 'Enter image size. Example: thumbnail, medium, large, full or other sizes defined by current theme. Alternatively enter image size in pixels: 200x100 (Width x Height). Leave empty to use "thumbnail" size', 'vibez' )
	        ),
	        array(
		        'type'    => 'dropdown',
		        'name'    => 'number_of_columns',
		        'title'   => esc_html__( 'Number of Columns', 'vibez' ),
		        'options' => array(
			        'two'   => esc_html__( 'Two', 'vibez' ),
			        'three' => esc_html__( 'Three', 'vibez' ),
			        'four'  => esc_html__( 'Four', 'vibez' ),
			        'five'  => esc_html__( 'Five', 'vibez' ),
			        'six'   => esc_html__( 'Six', 'vibez' )
		        )
	        ),
	        array(
		        'type'    => 'dropdown',
		        'name'    => 'space_between_columns',
		        'title'   => esc_html__( 'Space Between items', 'vibez' ),
		        'options' => array(
			        'normal' => esc_html__( 'Normal', 'vibez' ),
			        'small'  => esc_html__( 'Small', 'vibez' ),
			        'tiny'   => esc_html__( 'Tiny', 'vibez' ),
			        'no'     => esc_html__( 'No Space', 'vibez' )
		        )
	        ),
	        array(
		        'type'    => 'dropdown',
		        'name'    => 'image_behavior',
		        'title'   => esc_html__( 'Image Behavior', 'vibez' ),
		        'options' => array(
			        ''            => esc_html__( 'None', 'vibez' ),
			        'lightbox'    => esc_html__( 'Open Lightbox', 'vibez' ),
			        'custom-link' => esc_html__( 'Open Custom Link', 'vibez' ),
			        'zoom'        => esc_html__( 'Zoom', 'vibez' ),
			        'grayscale'   => esc_html__( 'Grayscale', 'vibez' )
		        )
	        ),
	        array(
		        'type'        => 'textarea',
		        'name'        => 'custom_links',
		        'title'       => esc_html__( 'Custom Links', 'vibez' ),
		        'description' => esc_html__( 'Delimit links by comma', 'vibez' )
	        ),
	        array(
		        'type'    => 'dropdown',
		        'name'    => 'custom_link_target',
		        'title'   => esc_html__( 'Custom Link Target', 'vibez' ),
		        'options' => vibez_elated_get_link_target_array()
	        )
        );
    }

    /**
     * Generates widget's HTML
     *
     * @param array $args args from widget area
     * @param array $instance widget's options
     */
    public function widget($args, $instance) {
        $extra_class       = ! empty( $instance['extra_class'] ) ? $instance['extra_class'] : '';
	
	    //prepare variables
	    $params = '';
	    $params .= ' type="grid"';
	
	    //is instance empty?
	    if ( is_array( $instance ) && count( $instance ) ) {
		    //generate shortcode params
		    foreach ( $instance as $key => $value ) {
			    $params .= " $key='$value' ";
		    }
	    }
        ?>

        <div class="widget eltdf-image-gallery-widget <?php echo esc_html($extra_class); ?>">
            <?php
	            if ( ! empty( $instance['widget_title'] ) ) {
		            echo wp_kses_post( $args['before_title'] ) . esc_html( $instance['widget_title'] ) . wp_kses_post( $args['after_title'] );
	            }
                echo do_shortcode("[eltdf_image_gallery $params]"); // XSS OK
            ?>
        </div>
    <?php 
    }
}