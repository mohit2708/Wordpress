<?php

require_once ELATED_FRAMEWORK_MODULES_ROOT_DIR.'/widgets/image-gallery/image-gallery.php';