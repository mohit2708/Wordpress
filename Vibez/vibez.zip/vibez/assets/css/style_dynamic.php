<?php

do_action('vibez_elated_action_style_dynamic');