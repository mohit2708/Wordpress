(function($) {
    "use strict";

    var title = {};
    eltdf.modules.title = title;

    title.eltdfOnDocumentReady = eltdfOnDocumentReady;
    title.eltdfOnWindowLoad = eltdfOnWindowLoad;

    $(document).ready(eltdfOnDocumentReady);
    $(window).on('load',eltdfOnWindowLoad);
    
    /* 
        All functions to be called on $(document).ready() should be in this function
    */
    function eltdfOnDocumentReady() {
	    eltdfParallaxTitle();
    }

    /*
        All functions to be called on $(window).on('load',) should be in this function
    */
    function eltdfOnWindowLoad() {
	    eltdfInitTitleArrowsAnimation();
    }

    /*
     **	Title image with parallax effect
     */
    function eltdfParallaxTitle(){
	    var parallaxBackground = $('.eltdf-title.eltdf-has-parallax-background');
	    
        if(parallaxBackground.length > 0 && $('.touch').length === 0){
            var parallaxBackgroundWithZoomOut = $('.eltdf-title.eltdf-has-parallax-background.eltdf-zoom-out');

            var backgroundSizeWidth = parseInt(parallaxBackground.data('background-width').match(/\d+/));
            var titleHolderHeight = parallaxBackground.data('height');
            var titleRate = (titleHolderHeight / 10000) * 7;
            var titleYPos = -(eltdf.scroll * titleRate);

            //set position of background on doc ready
            parallaxBackground.css({'background-position': 'center '+ (titleYPos+eltdfGlobalVars.vars.eltdfAddForAdminBar) +'px' });
            parallaxBackgroundWithZoomOut.css({'background-size': backgroundSizeWidth-eltdf.scroll + 'px auto'});

            //set position of background on window scroll
            $(window).scroll(function() {
                titleYPos = -(eltdf.scroll * titleRate);
                parallaxBackground.css({'background-position': 'center ' + (titleYPos+eltdfGlobalVars.vars.eltdfAddForAdminBar) + 'px' });
                parallaxBackgroundWithZoomOut.css({'background-size': backgroundSizeWidth-eltdf.scroll + 'px auto'});
            });
        }
    }
	
	/*
	 ** Init title arrows animation
	 */
	function eltdfInitTitleArrowsAnimation() {
		var holder = $('.eltdf-title-has-arrows');
		
		if (holder.length) {
			
			holder.appear(function () {
				holder.find('.eltdf-title-arrows-holder').addClass('eltdf-arrows-animate');
			}, {accX: 0, accY: 0});
		}
	}

})(jQuery);
