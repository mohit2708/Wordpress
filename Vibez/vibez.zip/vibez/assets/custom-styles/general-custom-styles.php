<?php

if(!function_exists('vibez_elated_design_styles')) {
    /**
     * Generates general custom styles
     */
    function vibez_elated_design_styles() {
	    $font_family = vibez_elated_options()->getOptionValue('google_fonts');
	    if (!empty($font_family) && vibez_elated_is_font_option_valid($font_family)){
	    	$font_family_selector = array(
	    		'body',
			    'h1',
				'h2',
				'h3',
				'h4',
				'h6',
				'.eltdf-comment-holder .eltdf-comment-text .replay',
				'.eltdf-comment-holder .eltdf-comment-text .comment-reply-link',
				'.eltdf-comment-holder .eltdf-comment-text .comment-edit-link',
				'#submit_comment',
				'.post-password-form input[type=\'submit\']',
				'input.wpcf7-form-control.wpcf7-submit',
				'.eltdf-blog-holder article.format-quote .eltdf-post-text .eltdf-post-text-main .eltdf-quote-author-wrapper .eltdf-quote-author',
				'.eltdf-blog-holder article.format-quote .eltdf-post-text .eltdf-post-text-main .eltdf-quote-author-wrapper .eltdf-quote-author-position',
				'.widget.widget_tag_cloud a',
				'.eltdf-footer-bottom-holder .widget',
				'#tribe-events-content-wrapper .tribe-bar-filters .tribe-bar-filters-inner > div label',
				'#tribe-events-content-wrapper .tribe-bar-filters .tribe-bar-filters-inner > div input[type=submit]',
				'#tribe-events-content-wrapper #tribe-bar-views .tribe-bar-views-inner > label',
				'#tribe-events-content-wrapper #tribe-bar-views .tribe-bar-views-list .tribe-bar-views-option a',
				'#tribe-events-content-wrapper #tribe-events-content table.tribe-events-calendar thead th',
				'#tribe-events-content-wrapper #tribe-events-content .tribe-events-button',
				'#tribe-events-content-wrapper #tribe-mobile-container .type-tribe_events .tribe-events-read-more',
				'.eltdf-events-list-item-date-holder',
				'.eltdf-events-list-item-title-holder .eltdf-events-list-item-price',
				'.eltdf-tribe-events-single .eltdf-events-single-main-info .eltdf-events-single-date-holder',
				'.eltdf-tribe-events-single .eltdf-events-single-main-info .eltdf-events-single-title-holder .eltdf-events-single-cost',
				'#tribe-events .eltdf-tribe-events-single .tribe-events-cal-links a.tribe-events-button',
				'.eltdf-ttevents-single .tt_event_items_list li.type_info label',
				'table.tt_timetable thead th',
				'table.tt_timetable .tt_tooltip .tt_tooltip_content',
				'.tt_responsive .tt_timetable.small .box_header',
				'.tt_responsive .tt_timetable.small .tt_items_list a',
			    '.eltdf-main-menu > ul > li > a',
			    '.eltdf-drop-down .wide .second .inner > ul > li > a',
				'.eltdf-banner-holder .eltdf-banner-link-text .eltdf-banner-link-label',
				'.eltdf-btn',
				'.eltdf-countdown .countdown-row .countdown-section .countdown-amount',
				'.eltdf-counter-holder .eltdf-counter',
				'.eltdf-counter-holder span.eltdf-counter-title',
				'.eltdf-dropcaps',
				'.eltdf-price-table .eltdf-pt-inner ul li .eltdf-pt-value',
				'.eltdf-price-table .eltdf-pt-inner ul li .eltdf-pt-price',
				'.eltdf-tabs .eltdf-tabs-nav li a',
				'.eltdf-pl-filter-holder ul li span',
			    '.eltdf-fullscreen-search-holder .eltdf-search-field',
			    '.eltdf-mobile-header .eltdf-mobile-nav ul li a',
			    '.eltdf-mobile-header .eltdf-mobile-nav ul li h5'
		    );
		
		    $woo_font_family_selector = array();
		    if(vibez_elated_is_woocommerce_installed()) {
			    $woo_font_family_selector = array(
				    '.woocommerce-page .eltdf-content a.button',
					'.woocommerce-page .eltdf-content a.added_to_cart',
					'.woocommerce-page .eltdf-content input[type="submit"]',
					'.woocommerce-page .eltdf-content button[type="submit"]',
					'.woocommerce-page .eltdf-content .wc-forward:not(.added_to_cart):not(.checkout-button)',
					'div.woocommerce a.button',
					'div.woocommerce a.added_to_cart',
					'div.woocommerce input[type="submit"]',
					'div.woocommerce button[type="submit"]',
					'div.woocommerce .wc-forward:not(.added_to_cart):not(.checkout-button)',
					'.woocommerce .eltdf-onsale',
					'.woocommerce .eltdf-out-of-stock',
					'ul.products > .product a.button',
					'ul.products > .product .price',
					'.eltdf-woo-single-page .eltdf-single-product-summary .price',
					'.eltdf-woo-single-page .eltdf-single-product-summary .eltdf-quantity-buttons',
					'.widget.woocommerce.widget_product_tag_cloud .tagcloud a',
					'.eltdf-plc-holder .eltdf-plc-item .eltdf-plc-image-outer .eltdf-plc-image .eltdf-plc-onsale',
					'.eltdf-plc-holder .eltdf-plc-item .eltdf-plc-image-outer .eltdf-plc-image .eltdf-plc-out-of-stock',
					'.eltdf-plc-holder .eltdf-plc-item .eltdf-plc-price',
					'.eltdf-plc-holder .eltdf-plc-item .button',
					'.eltdf-plc-holder .eltdf-plc-item .added_to_cart',
					'.eltdf-plc-holder.eltdf-standard-layout .eltdf-plc-item a.button',
					'.eltdf-pls-holder .eltdf-pls-text .eltdf-pls-price',
					'.eltdf-pl-holder .eltdf-pli .eltdf-pli-price',
					'.eltdf-pl-holder .eltdf-pli-inner .eltdf-pli-image .eltdf-pli-onsale',
					'.eltdf-pl-holder .eltdf-pli-inner .eltdf-pli-image .eltdf-pli-out-of-stock',
					'.eltdf-pl-holder .eltdf-pli-inner .eltdf-pli-text-inner .button',
					'.eltdf-pl-holder .eltdf-pli-inner .eltdf-pli-text-inner .added_to_cart',
					'.eltdf-pl-holder.eltdf-standard-layout a.button',
				    '.eltdf-shopping-cart-dropdown .eltdf-cart-bottom .eltdf-view-cart'
			    );
		    }
		
		    $font_family_selector = array_merge($font_family_selector, $woo_font_family_selector);
	    	
		    echo vibez_elated_dynamic_css($font_family_selector, array('font-family' => vibez_elated_get_font_option_val($font_family)));
		}

        $page_background_color = vibez_elated_options()->getOptionValue('page_background_color');
		if (!empty($page_background_color)) {
			$background_color_selector = array(
				'.eltdf-wrapper-inner',
				'.eltdf-content'
			);
			echo vibez_elated_dynamic_css($background_color_selector, array('background-color' => $page_background_color));
		}

		$selection_color = vibez_elated_options()->getOptionValue('selection_color');
		if (!empty($selection_color)) {
			echo vibez_elated_dynamic_css('::selection', array('background' => $selection_color));
			echo vibez_elated_dynamic_css('::-moz-selection', array('background' => $selection_color));
		}

        $paspartu_style = array();
	    $paspartu_color = vibez_elated_options()->getOptionValue('paspartu_color');
        if (!empty($paspartu_color)) {
            $paspartu_style['background-color'] = $paspartu_color;
        }
	
	    $paspartu_width = vibez_elated_options()->getOptionValue('paspartu_width');
        if ($paspartu_width !== '') {
            $paspartu_style['padding'] = $paspartu_width.'%';
        }

        echo vibez_elated_dynamic_css('.eltdf-paspartu-enabled .eltdf-wrapper', $paspartu_style);
    }

    add_action('vibez_elated_action_style_dynamic', 'vibez_elated_design_styles');
}

if(!function_exists('vibez_elated_content_styles')) {
    /**
     * Generates content custom styles
     */
    function vibez_elated_content_styles() {
        $content_style = array();
	    
	    $padding_top = vibez_elated_options()->getOptionValue('content_top_padding');
	    if ($padding_top !== '') {
            $content_style['padding-top'] = vibez_elated_filter_px($padding_top).'px';
        }

        $content_selector = array(
            '.eltdf-content .eltdf-content-inner > .eltdf-full-width > .eltdf-full-width-inner',
        );

        echo vibez_elated_dynamic_css($content_selector, $content_style);

        $content_style_in_grid = array();
	    
	    $padding_top_in_grid = vibez_elated_options()->getOptionValue('content_top_padding_in_grid');
	    if ($padding_top_in_grid !== '') {
            $content_style_in_grid['padding-top'] = vibez_elated_filter_px($padding_top_in_grid).'px';
        }

        $content_selector_in_grid = array(
            '.eltdf-content .eltdf-content-inner > .eltdf-container > .eltdf-container-inner',
        );

        echo vibez_elated_dynamic_css($content_selector_in_grid, $content_style_in_grid);
    }

    add_action('vibez_elated_action_style_dynamic', 'vibez_elated_content_styles');
}

if (!function_exists('vibez_elated_h1_styles')) {

    function vibez_elated_h1_styles() {
	    $margin_top = vibez_elated_options()->getOptionValue('h1_margin_top');
	    $margin_bottom = vibez_elated_options()->getOptionValue('h1_margin_bottom');
	    
	    $item_styles = vibez_elated_get_typography_styles('h1');
	    
	    if($margin_top !== '') {
		    $item_styles['margin-top'] = vibez_elated_filter_px($margin_top).'px';
	    }
	    if($margin_bottom !== '') {
		    $item_styles['margin-bottom'] = vibez_elated_filter_px($margin_bottom).'px';
	    }
	    
	    $item_selector = array(
		    'h1'
	    );

	    if ( ! empty( $item_styles ) ) {
		    echo vibez_elated_dynamic_css( $item_selector, $item_styles );
	    }
    }

    add_action('vibez_elated_action_style_dynamic', 'vibez_elated_h1_styles');
}

if (!function_exists('vibez_elated_h2_styles')) {

    function vibez_elated_h2_styles() {
	    $margin_top = vibez_elated_options()->getOptionValue('h2_margin_top');
	    $margin_bottom = vibez_elated_options()->getOptionValue('h2_margin_bottom');
	
	    $item_styles = vibez_elated_get_typography_styles('h2');
	
	    if($margin_top !== '') {
		    $item_styles['margin-top'] = vibez_elated_filter_px($margin_top).'px';
	    }
	    if($margin_bottom !== '') {
		    $item_styles['margin-bottom'] = vibez_elated_filter_px($margin_bottom).'px';
	    }
	
	    $item_selector = array(
		    'h2'
	    );

	    if ( ! empty( $item_styles ) ) {
		    echo vibez_elated_dynamic_css( $item_selector, $item_styles );
	    }
    }

    add_action('vibez_elated_action_style_dynamic', 'vibez_elated_h2_styles');
}

if (!function_exists('vibez_elated_h3_styles')) {

    function vibez_elated_h3_styles() {
	    $margin_top = vibez_elated_options()->getOptionValue('h3_margin_top');
	    $margin_bottom = vibez_elated_options()->getOptionValue('h3_margin_bottom');
	
	    $item_styles = vibez_elated_get_typography_styles('h3');
	
	    if($margin_top !== '') {
		    $item_styles['margin-top'] = vibez_elated_filter_px($margin_top).'px';
	    }
	    if($margin_bottom !== '') {
		    $item_styles['margin-bottom'] = vibez_elated_filter_px($margin_bottom).'px';
	    }
	
	    $item_selector = array(
		    'h3'
	    );

	    if ( ! empty( $item_styles ) ) {
		    echo vibez_elated_dynamic_css( $item_selector, $item_styles );
	    }
    }

    add_action('vibez_elated_action_style_dynamic', 'vibez_elated_h3_styles');
}

if (!function_exists('vibez_elated_h4_styles')) {

    function vibez_elated_h4_styles() {
	    $margin_top = vibez_elated_options()->getOptionValue('h4_margin_top');
	    $margin_bottom = vibez_elated_options()->getOptionValue('h4_margin_bottom');
	
	    $item_styles = vibez_elated_get_typography_styles('h4');
	
	    if($margin_top !== '') {
		    $item_styles['margin-top'] = vibez_elated_filter_px($margin_top).'px';
	    }
	    if($margin_bottom !== '') {
		    $item_styles['margin-bottom'] = vibez_elated_filter_px($margin_bottom).'px';
	    }
	
	    $item_selector = array(
		    'h4'
	    );

	    if ( ! empty( $item_styles ) ) {
		    echo vibez_elated_dynamic_css( $item_selector, $item_styles );
	    }
    }

    add_action('vibez_elated_action_style_dynamic', 'vibez_elated_h4_styles');
}

if (!function_exists('vibez_elated_h5_styles')) {

    function vibez_elated_h5_styles() {
	    $margin_top = vibez_elated_options()->getOptionValue('h5_margin_top');
	    $margin_bottom = vibez_elated_options()->getOptionValue('h5_margin_bottom');
	
	    $item_styles = vibez_elated_get_typography_styles('h5');
	
	    if($margin_top !== '') {
		    $item_styles['margin-top'] = vibez_elated_filter_px($margin_top).'px';
	    }
	    if($margin_bottom !== '') {
		    $item_styles['margin-bottom'] = vibez_elated_filter_px($margin_bottom).'px';
	    }
	
	    $item_selector = array(
		    'h5'
	    );

	    if ( ! empty( $item_styles ) ) {
		    echo vibez_elated_dynamic_css( $item_selector, $item_styles );
	    }
    }

    add_action('vibez_elated_action_style_dynamic', 'vibez_elated_h5_styles');
}

if (!function_exists('vibez_elated_h6_styles')) {

    function vibez_elated_h6_styles() {
	    $margin_top = vibez_elated_options()->getOptionValue('h6_margin_top');
	    $margin_bottom = vibez_elated_options()->getOptionValue('h6_margin_bottom');
	
	    $item_styles = vibez_elated_get_typography_styles('h6');
	
	    if($margin_top !== '') {
		    $item_styles['margin-top'] = vibez_elated_filter_px($margin_top).'px';
	    }
	    if($margin_bottom !== '') {
		    $item_styles['margin-bottom'] = vibez_elated_filter_px($margin_bottom).'px';
	    }
	
	    $item_selector = array(
		    'h6'
	    );

	    if ( ! empty( $item_styles ) ) {
		    echo vibez_elated_dynamic_css( $item_selector, $item_styles );
	    }
    }

    add_action('vibez_elated_action_style_dynamic', 'vibez_elated_h6_styles');
}

if (!function_exists('vibez_elated_text_styles')) {

    function vibez_elated_text_styles() {
	    $item_styles = vibez_elated_get_typography_styles('text');
	
	    $item_selector = array(
		    'p'
	    );

	    if ( ! empty( $item_styles ) ) {
		    echo vibez_elated_dynamic_css( $item_selector, $item_styles );
	    }
    }

    add_action('vibez_elated_action_style_dynamic', 'vibez_elated_text_styles');
}

if (!function_exists('vibez_elated_link_styles')) {

    function vibez_elated_link_styles() {
        $link_styles = array();

        if(vibez_elated_options()->getOptionValue('link_color') !== '') {
            $link_styles['color'] = vibez_elated_options()->getOptionValue('link_color');
        }
        if(vibez_elated_options()->getOptionValue('link_fontstyle') !== '') {
            $link_styles['font-style'] = vibez_elated_options()->getOptionValue('link_fontstyle');
        }
        if(vibez_elated_options()->getOptionValue('link_fontweight') !== '') {
            $link_styles['font-weight'] = vibez_elated_options()->getOptionValue('link_fontweight');
        }
        if(vibez_elated_options()->getOptionValue('link_fontdecoration') !== '') {
            $link_styles['text-decoration'] = vibez_elated_options()->getOptionValue('link_fontdecoration');
        }

        $link_selector = array(
            'a',
            'p a'
        );

        if (!empty($link_styles)) {
            echo vibez_elated_dynamic_css($link_selector, $link_styles);
        }
    }

    add_action('vibez_elated_action_style_dynamic', 'vibez_elated_link_styles');
}

if (!function_exists('vibez_elated_link_hover_styles')) {

    function vibez_elated_link_hover_styles() {
        $link_hover_styles = array();

        if(vibez_elated_options()->getOptionValue('link_hovercolor') !== '') {
            $link_hover_styles['color'] = vibez_elated_options()->getOptionValue('link_hovercolor');
        }
        if(vibez_elated_options()->getOptionValue('link_hover_fontdecoration') !== '') {
            $link_hover_styles['text-decoration'] = vibez_elated_options()->getOptionValue('link_hover_fontdecoration');
        }

        $link_hover_selector = array(
            'a:hover',
            'p a:hover'
        );

        if (!empty($link_hover_styles)) {
            echo vibez_elated_dynamic_css($link_hover_selector, $link_hover_styles);
        }

        $link_heading_hover_styles = array();

        if(vibez_elated_options()->getOptionValue('link_hovercolor') !== '') {
            $link_heading_hover_styles['color'] = vibez_elated_options()->getOptionValue('link_hovercolor');
        }

        $link_heading_hover_selector = array(
            'h1 a:hover',
            'h2 a:hover',
            'h3 a:hover',
            'h4 a:hover',
            'h5 a:hover',
            'h6 a:hover'
        );

        if (!empty($link_heading_hover_styles)) {
            echo vibez_elated_dynamic_css($link_heading_hover_selector, $link_heading_hover_styles);
        }
    }

    add_action('vibez_elated_action_style_dynamic', 'vibez_elated_link_hover_styles');
}

if (!function_exists('vibez_elated_smooth_page_transition_styles')) {

    function vibez_elated_smooth_page_transition_styles($style) {
        $id = vibez_elated_get_page_id();
    	$loader_style = array();
		$current_style = '';

        if(vibez_elated_get_meta_field_intersect('smooth_pt_bgnd_color',$id) !== '') {
            $loader_style['background-color'] = vibez_elated_get_meta_field_intersect('smooth_pt_bgnd_color',$id);
        }

        $loader_selector = array('.eltdf-smooth-transition-loader');

        if (!empty($loader_style)) {
			$current_style .= vibez_elated_dynamic_css($loader_selector, $loader_style);
        }

        $spinner_style = array();

        if(vibez_elated_get_meta_field_intersect('smooth_pt_spinner_color',$id) !== '') {
            $spinner_style['background-color'] = vibez_elated_get_meta_field_intersect('smooth_pt_spinner_color',$id);
        }

        $spinner_selectors = array(
            '.eltdf-st-loader .eltdf-rotate-circles > div',
            '.eltdf-st-loader .pulse',
            '.eltdf-st-loader .double_pulse .double-bounce1',
            '.eltdf-st-loader .double_pulse .double-bounce2',
            '.eltdf-st-loader .cube',
            '.eltdf-st-loader .rotating_cubes .cube1',
            '.eltdf-st-loader .rotating_cubes .cube2',
            '.eltdf-st-loader .stripes > div',
            '.eltdf-st-loader .wave > div',
            '.eltdf-st-loader .two_rotating_circles .dot1',
            '.eltdf-st-loader .two_rotating_circles .dot2',
            '.eltdf-st-loader .five_rotating_circles .container1 > div',
            '.eltdf-st-loader .five_rotating_circles .container2 > div',
            '.eltdf-st-loader .five_rotating_circles .container3 > div',
            '.eltdf-st-loader .atom .ball-1:before',
            '.eltdf-st-loader .atom .ball-2:before',
            '.eltdf-st-loader .atom .ball-3:before',
            '.eltdf-st-loader .atom .ball-4:before',
            '.eltdf-st-loader .clock .ball:before',
            '.eltdf-st-loader .mitosis .ball',
            '.eltdf-st-loader .lines .line1',
            '.eltdf-st-loader .lines .line2',
            '.eltdf-st-loader .lines .line3',
            '.eltdf-st-loader .lines .line4',
            '.eltdf-st-loader .fussion .ball',
            '.eltdf-st-loader .fussion .ball-1',
            '.eltdf-st-loader .fussion .ball-2',
            '.eltdf-st-loader .fussion .ball-3',
            '.eltdf-st-loader .fussion .ball-4',
            '.eltdf-st-loader .wave_circles .ball',
            '.eltdf-st-loader .pulse_circles .ball'
        );

        if (!empty($spinner_style)) {
			$current_style .= vibez_elated_dynamic_css($spinner_selectors, $spinner_style);
        }

		$current_style = $current_style . $style;

		return $current_style;
    }

    add_filter('vibez_elated_filter_add_page_custom_style', 'vibez_elated_smooth_page_transition_styles');
}