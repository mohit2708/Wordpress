<?php
   /*
   Template Name: Recipe Add
   */ 
  if (!is_user_logged_in()){ wp_redirect( home_url('login') ); }
  get_header();
 
session_start();

$getuserid =  get_current_user_id();

   session_start();
   require_once(dirname( __FILE__ ).'/../../../wp-config.php');
$conn = new mysqli(DB_HOST, DB_USER, DB_PASSWORD, DB_NAME);
/*
Show Product Name In select box
*/ 
   $result = mysqli_query($conn,"SELECT * FROM wp_product Where delete_at IS NULL AND status = '1'");
/* 
Recipe Insert 
*/ 
if(isset($_POST['SubmitButton']))
   { 

      $recipe             = trim($_POST['recipe']);
      $recipe_description = $_POST['recipe_description'];
      $product_name       = implode(',', $_POST['product_name']);  

      $find_recipe = mysqli_query($conn, "SELECT recipe_name FROM wp_recipe where recipe_name = '$recipe' "); 
      if(mysqli_num_rows($find_recipe) > 0){
          $recipe_msg = 'Recipe Already exists!';
      }else{
        $sql = "INSERT INTO wp_recipe (recipe_name, product_list,recipe_description) 
              VALUES ('$recipe', '$product_name','$recipe_description')";
          if (mysqli_query($conn, $sql)) {             
            $_SESSION['msg1']="<strong>Success!</strong> New Recipe created successfully !";
            wp_redirect( home_url('recipe-list') );
          }
          mysqli_close($conn);  
        }           
   }
 /*
Edit recipe
*/ 
if (isset($_GET['edit'])) {
      $id = $_GET['edit'];
      $record = mysqli_query($conn, "SELECT * FROM wp_recipe WHERE id=$id");
      
         $fetch              = mysqli_fetch_array($record);
         $recipe             = $fetch['recipe_name'];
         $product_name       = $fetch['product_list']; 
         $recipe_description = $fetch['recipe_description']; 
         $product_nameexp    = explode(',',$fetch['product_list']);

   } 
/*
Edit Function
*/
if(isset($_POST['Updatebutton']))
{
  //print_r($_POST);  
  $id = $_POST['id'];
  $recipe             = trim($_POST['recipe']);
  $recipe_description = $_POST['recipe_description'];
  $product_name       = implode(',', $_POST['product_name']);
  
  
  global $wpdb;
  $recieName = $wpdb->get_var("SELECT recipe_name FROM wp_recipe where recipe_name = '$recipe' and id ='$id' ");
  $find_recipe = $wpdb->get_var("SELECT * FROM wp_recipe where recipe_name = '$recipe'");

  if($find_recipe > 0){    
    if($recieName == $recipe){
      mysqli_query($conn, "UPDATE wp_recipe SET recipe_name='$recipe', product_list='$product_name', recipe_description='$recipe_description' WHERE id=$id");
      $_SESSION['msg1'] = "Recipe updated!"; 
      wp_redirect( home_url('recipe-list') );
    }else{
        $recipe_msg = 'Recipe Already exists in you Database!';
    }  
  }else{
    mysqli_query($conn, "UPDATE wp_recipe SET recipe_name='$recipe', product_list='$product_name', recipe_description='$recipe_description' WHERE id=$id");
    $_SESSION['msg1'] = "Recipe updated!"; 
    wp_redirect( home_url('recipe-list') );
    }
}
  
   
?>


<div class="container">
<form name="productform" id="productform" action="" method="post" enctype="multipart/form-data">
   <input type="hidden" name="id" value="<?php echo $id; ?>">
   <?php if (isset($_SESSION['message'])): ?>
   <div class="msg">
      <?php echo $msg; ?>
   </div>
   <?php endif ?>   
<!--    <button type="button" id="scanbarbutton" class="btn btn-danger">Scan Barcode</button> -->
   <div class="row">
   	 <div class="col-sm-12">
	   <div class="form-group">
	      <label>Recipe Name<span style="color:red;"> *</span></label>
	      <input type="text" class="form-control" id="recipe" name="recipe" placeholder="Enter Recipe Name" value="<?php echo $recipe; ?>" required maxlength="50" minlength="3">
        <span style="color:red;"><?php echo $recipe_msg; ?></span>
	   </div>
	  </div>
    <div class="col-sm-6">
      <div class="form-group">
      <label>Product Name<span style="color:red;"> *</span></label>
       <select class="form-control" id="product_name" name="product_name[]" multiple="multiple" required="" multiple data-live-search="true">
        <?php while($row = $result->fetch_assoc()) { 
          if(isset($_GET['edit'])){
            if (in_array($row["id"], $product_nameexp))
            { ?>  
            <option value="<?php echo $row["id"]; ?>" selected="selected" ><?php echo $row["product_name"]; ?></option>
            <?php }
            else
              { ?>
              <option value="<?php echo $row["id"]; ?>"><?php echo $row["product_name"]; ?></option>
              <?php }
            }
            else{ ?>
              <option value="<?php echo $row["id"]; ?>"><?php echo $row["product_name"]; ?></option>
            <?php } }
        ?>
    </select>
   </div>
    </div>
    <div class="col-sm-6 add-prduct-btn">
      <div class="form-group">
        <a href="<?php echo home_url('add-product'); ?>" target="_blank" class="btn btn-success">Add New Product</a>        
      </div>
    </div>
    <div class="col-sm-12">
      <div class="form-group">
        <label>Recipe Description</label>
        <textarea class="form-control" id="recipe_description" name="recipe_description" rows="3" maxlength="200" minlength="3"><?php echo $recipe_description; ?></textarea>        
      </div>
    </div>
	</div>

   

      <?php if(isset($_GET['edit'])){ ?>
         <input type="submit" name="Updatebutton" id="Updatebutton" class="btn btn-success" value="Update">
         <a href="<?php echo home_url('recipe-list'); ?>"><button type="button" class="btn btn-outline-secondar btn-info">Back</button></a>
      <?php } else { ?>
         <input type="submit" class="btn btn-success" name="SubmitButton" id="SubmitButton" value="Submit">
      <?php } ?>
      
</form>
</div>

<?php get_footer(); ?>
<script type="text/javascript">
  $('#SubmitButton, #Updatebutton').click(function(){
    var value =  $('#recipe').val();
    value = value.trim();
    if(value==''){
      $('#recipe').val(null);
    }
  });
</script>